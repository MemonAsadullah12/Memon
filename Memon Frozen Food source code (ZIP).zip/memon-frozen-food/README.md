# Memon Frozen Food — Website & Business Management System

**Memon Frozen Food (Hygienic Taste)** — an online store for frozen foods in **Khairpur Mirs, Pakistan**, plus a full admin panel to run the business.

What the system does:

- **Online shop** — customers browse products, add to cart, and order as guests (no account needed). Cash on Delivery.
- **Admin panel** — manage products, categories, orders, stock, deliveries, customers, coupons, payments, expenses, reports, website pages and banners.
- Delivery is currently set to **Khairpur Mirs only**: Rs. 150 delivery fee, free delivery on orders above Rs. 3000, minimum order Rs. 500.
- Order phone / WhatsApp: **0300-3130608**.

Built with plain PHP 8.2 + MySQL (no framework), so it runs on almost any standard web hosting.

---

## Setup on your own computer (XAMPP — for testing)

1. **Install XAMPP** (choose the version with PHP 8.2 or newer) from apachefriends.org.
2. **Start Apache and MySQL** from the XAMPP Control Panel (click "Start" next to both).
3. **Copy the project folder** — put the whole `memon-frozen-food` folder inside `C:\xampp\htdocs\`, so you have `C:\xampp\htdocs\memon-frozen-food\`.
4. **Open the installer** in your browser: `http://localhost/memon-frozen-food/install.php`
5. **Step 0** checks your setup — all items should show PASS.
6. **Step 1** asks for database details. On XAMPP the defaults are fine: host `localhost`, database name `memon_frozen_food`, username `root`, password **blank**. Click "Create Database & Import".
7. **Step 2** saves the configuration file automatically.
8. **Step 3** — create your admin account (name, email, your own password, minimum 8 characters).
9. **Delete `install.php`** (or rename it) — this is important, see Security below.
10. Open the shop: `http://localhost/memon-frozen-food/`
11. Open the admin panel: `http://localhost/memon-frozen-food/admin/login.php`

## Putting it on real web hosting (shared hosting / cPanel)

1. **Upload the files** — use FTP (FileZilla) or cPanel → File Manager to upload everything inside `memon-frozen-food/` to your hosting (usually the `public_html` folder, or a subfolder like `public_html/shop`).
2. **Create a database** — in cPanel go to "MySQL Databases": create a database (e.g. `yourname_mff`), create a database user, set a strong password, and add the user to the database with ALL PRIVILEGES. Note down the database name, username and password.
3. **Run the installer** — open `https://yourdomain.com/install.php` in your browser (or `https://yourdomain.com/shop/install.php` if you used a subfolder) and follow the steps, entering the cPanel database details from step 2. Then create your admin account and **delete install.php**.
4. **Manual alternative** (if you prefer): in cPanel → phpMyAdmin, select your database, click Import, and import `database/schema.sql` first, then `database/seed.sql`. Then create the file `includes/config.local.php` yourself with this exact content (fill in your own details):

   ```php
   <?php
   define('DB_HOST', 'localhost');
   define('DB_NAME', 'yourname_mff');
   define('DB_USER', 'yourname_dbuser');
   define('DB_PASS', 'your-database-password');
   ```

   After that you can still run `install.php` — it will reuse the existing database and just walk you through creating the admin account. Then delete `install.php`.
5. Visit your site and the admin login at `https://yourdomain.com/admin/login.php`.

## Security notes (please read)

- **Always delete or rename `install.php`** after installation. Anyone who can open it could reset your shop.
- **Never share `includes/config.local.php`** — it contains your database password. Do not put it in a public Git repository.
- There are **no default admin passwords**. Your admin account is the one you created during installation. Use a strong password and only give admin access to people you trust.
- The system never stores bank card numbers. Payments are Cash on Delivery unless you enable other methods in settings.
- Take regular backups from the admin panel (Settings → Backups) and keep a copy somewhere safe.

## Troubleshooting

- **"Could not connect to MySQL" / "Access denied"** — MySQL is not running (start it in the XAMPP Control Panel), or the username/password is wrong. On XAMPP the default is user `root` with a blank password. On cPanel hosting, use the database user you created, not your cPanel login.
- **Blank white page** — a PHP error is being hidden. On XAMPP, check `C:\xampp\apache\logs\error.log` for the real message. Common cause: a wrong database password in `includes/config.local.php`.
- **Installer says it cannot write `includes/config.local.php`** — create the file manually using the content the installer shows you (same template as in the hosting section above).
- **phpMyAdmin import fails** — import `schema.sql` **before** `seed.sql`, and make sure your MySQL is version 5.7+ (or MariaDB 10.2+).
- **"Page not found" for admin login** — check the folder name in `htdocs` matches the URL exactly (e.g. `memon-frozen-food`, not `memon-frozen-food-2`).
- **Installer shows FAIL on the environment check** — install a newer XAMPP with PHP 8.2+, and make sure the `database/` folder was uploaded with the project.

---

Questions or problems? Call / WhatsApp **0300-3130608**.
