<?php
// About us — editable via `pages` table (slug 'about'), static fallback.
$page_title = 'About Us';
require_once __DIR__ . '/includes/header.php';
$content = null;
try {
    $st = db()->prepare("SELECT content FROM pages WHERE slug = 'about' LIMIT 1");
    $st->execute();
    $content = $st->fetchColumn() ?: null;
} catch (Throwable $e) {}
?>
<h1 class="page-heading">About <?= esc(SITE_NAME) ?></h1>
<?php if ($content): ?>
  <div class="page-content"><?= $content ?></div>
<?php else: ?>
  <p><strong><?= esc(SITE_NAME) ?></strong> — <em><?= esc(TAGLINE) ?></em> — brings fresh and hygienic frozen foods to families in <?= esc(CITY) ?>.</p>
  <p>We prepare our Chicken Shami Kababs, Koftas, Nuggets and Spring Rolls in small batches with clean ingredients, pack them fresh, and deliver them frozen to your doorstep — ready to cook whenever you are.</p>
  <ul>
    <li><strong>100% Hygienic:</strong> clean preparation and packing, every time.</li>
    <li><strong>Quality Frozen:</strong> sealed packs that stay fresh in your freezer.</li>
    <li><strong>Fast &amp; Reliable Delivery:</strong> within <?= esc(CITY) ?>, on time.</li>
    <li><strong>Healthy Food for Your Family:</strong> delicious, ready-to-cook meals your family will love.</li>
  </ul>
  <p>Order online or call us at <strong><?= esc(ORDER_PHONE) ?></strong>.</p>
<?php endif; ?>
<?php require_once __DIR__ . '/includes/footer.php'; ?>
