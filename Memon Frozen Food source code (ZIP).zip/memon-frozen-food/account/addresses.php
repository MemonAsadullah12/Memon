<?php
// Address book CRUD — one default address per customer.
$ROOT = '../'; $page_title = 'My Addresses';
require_once __DIR__ . '/../includes/header.php';
require_customer();
$c = current_customer();
$pdo = db();

if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST') {
    csrf_check();
    $action = $_POST['action'] ?? '';
    if ($action === 'save') {
        $label = trim($_POST['label'] ?? 'Home');
        $addr = trim($_POST['address'] ?? '');
        $area = trim($_POST['area'] ?? '');
        $city = trim($_POST['city'] ?? '');
        $lm = trim($_POST['landmark'] ?? '');
        $id = (int)($_POST['id'] ?? 0);
        if ($addr === '' || $area === '' || $city === '') {
            flash('Address, area and city are required.', 'danger');
        } else {
            // Ownership check on edit.
            if ($id) {
                $chk = $pdo->prepare("SELECT id FROM customer_addresses WHERE id = ? AND customer_id = ?");
                $chk->execute([$id, (int)$c['id']]);
                if (!$chk->fetch()) $id = 0;
            }
            if ($id) {
                $pdo->prepare("UPDATE customer_addresses SET label=?, address=?, area=?, city=?, landmark=? WHERE id=? AND customer_id=?")
                    ->execute([$label, $addr, $area, $city, $lm ?: null, $id, (int)$c['id']]);
                flash('Address updated.');
            } else {
                $pdo->prepare("INSERT INTO customer_addresses (customer_id, label, address, area, city, landmark, is_default) VALUES (?,?,?,?,?,?,0)")
                    ->execute([(int)$c['id'], $label, $addr, $area, $city, $lm ?: null]);
                flash('Address added.');
            }
        }
    } elseif ($action === 'delete') {
        $pdo->prepare("DELETE FROM customer_addresses WHERE id = ? AND customer_id = ?")
            ->execute([(int)($_POST['id'] ?? 0), (int)$c['id']]);
        flash('Address deleted.', 'info');
    } elseif ($action === 'default') {
        $id = (int)($_POST['id'] ?? 0);
        $chk = $pdo->prepare("SELECT id FROM customer_addresses WHERE id = ? AND customer_id = ? LIMIT 1");
        $chk->execute([$id, (int)$c['id']]);
        if ($chk->fetch()) {
            $pdo->beginTransaction();
            $pdo->prepare("UPDATE customer_addresses SET is_default = 0 WHERE customer_id = ?")->execute([(int)$c['id']]);
            $pdo->prepare("UPDATE customer_addresses SET is_default = 1 WHERE id = ? AND customer_id = ?")->execute([$id, (int)$c['id']]);
            $pdo->commit();
            flash('Default address set.');
        } else {
            flash('Address not found.', 'danger');
        }
    }
    redirect('addresses.php');
}

$st = $pdo->prepare("SELECT * FROM customer_addresses WHERE customer_id = ? ORDER BY is_default DESC, id DESC");
$st->execute([(int)$c['id']]);
$addrs = $st->fetchAll();
$edit = null;
if (isset($_GET['edit'])) {
    $st = $pdo->prepare("SELECT * FROM customer_addresses WHERE id = ? AND customer_id = ? LIMIT 1");
    $st->execute([(int)$_GET['edit'], (int)$c['id']]);
    $edit = $st->fetch();
}
?>
<h1 class="page-heading">My Addresses</h1>
<div class="row">
  <div class="col-md-7">
    <?php foreach ($addrs as $a): ?>
      <div class="card mb-2"><div class="card-body py-2 d-flex justify-content-between align-items-center">
        <div>
          <strong><?= esc($a['label']) ?></strong>
          <?= (int)$a['is_default'] ? '<span class="badge bg-success ms-1">Default</span>' : '' ?><br>
          <span class="small"><?= esc($a['address']) ?>, <?= esc($a['area']) ?>, <?= esc($a['city']) ?><?= $a['landmark'] ? ' (' . esc($a['landmark']) . ')' : '' ?></span>
        </div>
        <div class="d-flex gap-1">
          <?php if (!(int)$a['is_default']): ?>
            <form method="post"><?= csrf_field() ?><input type="hidden" name="action" value="default"><input type="hidden" name="id" value="<?= (int)$a['id'] ?>">
              <button class="btn btn-sm btn-outline-maroon" title="Set default">Default</button></form>
          <?php endif; ?>
          <a class="btn btn-sm btn-outline-secondary" href="addresses.php?edit=<?= (int)$a['id'] ?>">Edit</a>
          <form method="post" onsubmit="return confirm('Delete this address?')"><?= csrf_field() ?><input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?= (int)$a['id'] ?>">
            <button class="btn btn-sm btn-outline-danger">Delete</button></form>
        </div>
      </div></div>
    <?php endforeach; ?>
    <?php if (!$addrs): ?><div class="alert alert-info">No saved addresses yet — add one below.</div><?php endif; ?>
  </div>
  <div class="col-md-5">
    <div class="card"><div class="card-body">
      <h5><?= $edit ? 'Edit Address' : 'Add Address' ?></h5>
      <form method="post">
        <?= csrf_field() ?>
        <input type="hidden" name="action" value="save">
        <input type="hidden" name="id" value="<?= (int)($edit['id'] ?? 0) ?>">
        <div class="mb-2"><label class="form-label">Label</label>
          <input class="form-control" name="label" maxlength="40" value="<?= esc($edit['label'] ?? 'Home') ?>"></div>
        <div class="mb-2"><label class="form-label">Address *</label>
          <textarea class="form-control" name="address" rows="2" required><?= esc($edit['address'] ?? '') ?></textarea></div>
        <div class="mb-2"><label class="form-label">Area *</label>
          <input class="form-control" name="area" required maxlength="80" value="<?= esc($edit['area'] ?? '') ?>"></div>
        <div class="mb-2"><label class="form-label">City *</label>
          <input class="form-control" name="city" required maxlength="60" value="<?= esc($edit['city'] ?? CITY) ?>"></div>
        <div class="mb-3"><label class="form-label">Landmark</label>
          <input class="form-control" name="landmark" maxlength="100" value="<?= esc($edit['landmark'] ?? '') ?>"></div>
        <button class="btn btn-maroon" type="submit"><?= $edit ? 'Update' : 'Add' ?> Address</button>
        <?php if ($edit): ?><a class="btn btn-link" href="addresses.php">Cancel</a><?php endif; ?>
      </form>
    </div></div>
  </div>
</div>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>
