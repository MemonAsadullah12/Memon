<?php
// Customer dashboard: order counts + 5 most recent orders.
$ROOT = '../'; $page_title = 'My Account';
require_once __DIR__ . '/../includes/header.php';
require_customer();
$c = current_customer();
$pdo = db();

function order_count(PDO $pdo, int $cid, string $extra = ''): int {
    $st = $pdo->prepare("SELECT COUNT(*) FROM orders WHERE customer_id = ? $extra");
    $st->execute([$cid]);
    return (int)$st->fetchColumn();
}
$total     = order_count($pdo, (int)$c['id']);
$pending   = order_count($pdo, (int)$c['id'], "AND order_status NOT IN ('delivered','cancelled','returned')");
$delivered = order_count($pdo, (int)$c['id'], "AND order_status = 'delivered'");
$st = $pdo->prepare("SELECT * FROM orders WHERE customer_id = ? ORDER BY id DESC LIMIT 5");
$st->execute([(int)$c['id']]);
$recent = $st->fetchAll();
?>
<h1 class="page-heading">Welcome, <?= esc($c['name']) ?></h1>
<div class="row mb-3">
  <div class="col-4"><div class="card stat-card"><div class="card-body text-center"><div class="stat-n"><?= $total ?></div><div class="small">Total Orders</div></div></div></div>
  <div class="col-4"><div class="card stat-card"><div class="card-body text-center"><div class="stat-n"><?= $pending ?></div><div class="small">In Progress</div></div></div></div>
  <div class="col-4"><div class="card stat-card"><div class="card-body text-center"><div class="stat-n"><?= $delivered ?></div><div class="small">Delivered</div></div></div></div>
</div>
<div class="d-flex gap-2 flex-wrap mb-3">
  <a class="btn btn-maroon" href="<?= $ROOT ?>products.php">Shop Now</a>
  <a class="btn btn-outline-maroon" href="orders.php">My Orders</a>
  <a class="btn btn-outline-maroon" href="addresses.php">My Addresses</a>
  <a class="btn btn-outline-maroon" href="profile.php">Profile</a>
  <a class="btn btn-outline-danger" href="logout.php">Logout</a>
</div>
<h2 class="section-title">Recent Orders</h2>
<?php if (!$recent): ?>
  <div class="alert alert-info">No orders yet. <a href="<?= $ROOT ?>products.php">Start shopping</a>!</div>
<?php else: ?>
  <div class="table-responsive"><table class="table">
    <thead><tr><th>Order #</th><th>Date</th><th>Total</th><th>Status</th><th></th></tr></thead>
    <tbody>
      <?php foreach ($recent as $o): ?>
        <tr>
          <td><?= esc($o['order_number']) ?></td>
          <td class="small"><?= esc(date('d M Y', strtotime($o['created_at']))) ?></td>
          <td><?= rs((int)$o['total_amount']) ?></td>
          <td><span class="badge bg-secondary"><?= esc(status_label($o['order_status'])) ?></span></td>
          <td><a class="btn btn-sm btn-outline-maroon" href="order.php?id=<?= (int)$o['id'] ?>">View</a></td>
        </tr>
      <?php endforeach; ?>
    </tbody>
  </table></div>
<?php endif; ?>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>
