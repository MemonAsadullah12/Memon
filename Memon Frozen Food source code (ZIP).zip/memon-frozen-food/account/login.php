<?php
// Customer login: phone + password.
$ROOT = '../'; $page_title = 'Login';
require_once __DIR__ . '/../includes/header.php';

if (current_customer()) redirect('dashboard.php');

$err = '';
if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST') {
    csrf_check();
    $r = customer_login($_POST['phone'] ?? '', $_POST['password'] ?? '');
    if ($r['ok']) {
        flash('Welcome back, ' . $r['customer']['name'] . '!');
        // Only allow relative in-site destinations (prevents open redirects).
        $next = $_GET['next'] ?? 'dashboard.php';
        if (!is_string($next) || $next === '' || str_contains($next, '..')
            || preg_match('#(^/|[a-z][a-z0-9+.-]*://)#i', $next)) {
            $next = 'dashboard.php';
        }
        redirect($next);
    }
    $err = $r['msg'];
}
?>
<h1 class="page-heading">Login</h1>
<div class="row justify-content-center"><div class="col-md-5">
  <div class="card"><div class="card-body">
    <?php if ($err): ?><div class="alert alert-danger"><?= esc($err) ?></div><?php endif; ?>
    <form method="post">
      <?= csrf_field() ?>
      <div class="mb-2"><label class="form-label">Mobile Number</label>
        <input class="form-control" name="phone" required maxlength="13" placeholder="03xx-xxxxxxx" value="<?= esc($_POST['phone'] ?? '') ?>"></div>
      <div class="mb-3"><label class="form-label">Password</label>
        <input type="password" class="form-control" name="password" required></div>
      <button class="btn btn-maroon w-100" type="submit">Login</button>
    </form>
    <p class="text-center mt-2 mb-0 small">New here? <a href="register.php">Create an account</a></p>
  </div></div>
</div></div>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>
