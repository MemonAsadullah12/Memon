<?php
// Customer logout.
$ROOT = '../';
require_once __DIR__ . '/../includes/header.php';
unset($_SESSION['customer_id']);
session_regenerate_id(true);
flash('You have been logged out.', 'info');
redirect($ROOT . 'index.php');
