<?php
// Single order view — only the logged-in customer's own order.
$ROOT = '../'; $page_title = 'Order Details';
require_once __DIR__ . '/../includes/header.php';
require_customer();
$c = current_customer();
$pdo = db();

$st = $pdo->prepare("SELECT * FROM orders WHERE id = ? AND customer_id = ? LIMIT 1");
$st->execute([(int)($_GET['id'] ?? 0), (int)$c['id']]);
$o = $st->fetch();
if (!$o) { http_response_code(404); echo '<div class="alert alert-warning">Order not found.</div>'; require __DIR__.'/../includes/footer.php'; exit; }

$it = $pdo->prepare("SELECT * FROM order_items WHERE order_id = ?");
$it->execute([(int)$o['id']]);
$lines = $it->fetchAll();
$h = $pdo->prepare("SELECT * FROM order_status_history WHERE order_id = ? ORDER BY created_at ASC, id ASC");
$h->execute([(int)$o['id']]);
$history = $h->fetchAll();
?>
<h1 class="page-heading">Order <?= esc($o['order_number']) ?></h1>
<div class="row">
  <div class="col-md-7">
    <div class="card mb-3"><div class="card-body">
      <h5>Items</h5>
      <?php foreach ($lines as $l): ?>
        <p class="d-flex justify-content-between small mb-1">
          <span><?= esc($l['product_name_snapshot']) ?> × <?= (int)$l['quantity'] ?></span>
          <span><?= rs((int)$l['line_total']) ?></span>
        </p>
      <?php endforeach; ?>
      <hr>
      <p class="d-flex justify-content-between mb-1"><span>Subtotal</span><span><?= rs((int)$o['subtotal']) ?></span></p>
      <?php if ((int)$o['discount_amount'] > 0): ?>
        <p class="d-flex justify-content-between mb-1 text-success"><span>Discount</span><span>− <?= rs((int)$o['discount_amount']) ?></span></p>
      <?php endif; ?>
      <p class="d-flex justify-content-between mb-1"><span>Delivery</span><span><?= (int)$o['delivery_fee'] ? rs((int)$o['delivery_fee']) : 'FREE' ?></span></p>
      <p class="d-flex justify-content-between"><span><strong>Total</strong></span><span><strong><?= rs((int)$o['total_amount']) ?></strong></span></p>
      <p class="small text-muted mb-0">Payment: <?= esc(ucwords(str_replace('_', ' ', $o['payment_method']))) ?> (<?= esc($o['payment_status']) ?>)</p>
    </div></div>
    <div class="card mb-3"><div class="card-body">
      <h5>Delivery Address</h5>
      <p class="mb-0 small"><?= esc($o['delivery_address']) ?>, <?= esc($o['area']) ?>, <?= esc($o['city']) ?><?= $o['landmark'] ? ' (' . esc($o['landmark']) . ')' : '' ?></p>
    </div></div>
  </div>
  <div class="col-md-5">
    <div class="card"><div class="card-body">
      <h5>Status Timeline</h5>
      <ol class="timeline">
        <?php foreach ($history as $hh): ?>
          <li><strong><?= esc(status_label($hh['new_status'])) ?></strong>
            <span class="text-muted small"> — <?= esc($hh['created_at']) ?></span>
            <?php if ($hh['note']): ?><br><span class="small"><?= esc($hh['note']) ?></span><?php endif; ?>
          </li>
        <?php endforeach; ?>
      </ol>
      <a class="btn btn-outline-maroon btn-sm" href="<?= $ROOT ?>track-order.php?o=<?= urlencode($o['order_number']) ?>">Public tracking link</a>
    </div></div>
  </div>
</div>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>
