<?php
// Customer's own order list (paginated).
$ROOT = '../'; $page_title = 'My Orders';
require_once __DIR__ . '/../includes/header.php';
require_customer();
$c = current_customer();
$pdo = db();
$page = max(1, (int)($_GET['page'] ?? 1));
$per = 10;
$st = $pdo->prepare("SELECT COUNT(*) FROM orders WHERE customer_id = ?");
$st->execute([(int)$c['id']]);
$total = (int)$st->fetchColumn();
// LIMIT/OFFSET inlined as ints (safe after casting; avoids driver quirks with bound LIMIT).
$st = $pdo->prepare(
    "SELECT * FROM orders WHERE customer_id = ? ORDER BY id DESC LIMIT " . (int)$per . " OFFSET " . (int)(($page - 1) * $per)
);
$st->execute([(int)$c['id']]);
$orders = $st->fetchAll();
?>
<h1 class="page-heading">My Orders</h1>
<?php if (!$orders): ?>
  <div class="alert alert-info">You have no orders yet. <a href="<?= $ROOT ?>products.php">Browse products</a>.</div>
<?php else: ?>
  <div class="table-responsive"><table class="table align-middle">
    <thead><tr><th>Order #</th><th>Date</th><th>Items</th><th>Total</th><th>Status</th><th></th></tr></thead>
    <tbody>
      <?php foreach ($orders as $o):
        $ni = $pdo->prepare("SELECT COALESCE(SUM(quantity),0) FROM order_items WHERE order_id = ?");
        $ni->execute([(int)$o['id']]);
        $n = (int)$ni->fetchColumn();
      ?>
        <tr>
          <td><?= esc($o['order_number']) ?></td>
          <td class="small"><?= esc(date('d M Y', strtotime($o['created_at']))) ?></td>
          <td><?= $n ?></td>
          <td><?= rs((int)$o['total_amount']) ?></td>
          <td><span class="badge bg-secondary"><?= esc(status_label($o['order_status'])) ?></span></td>
          <td><a class="btn btn-sm btn-outline-maroon" href="order.php?id=<?= (int)$o['id'] ?>">View</a></td>
        </tr>
      <?php endforeach; ?>
    </tbody>
  </table></div>
  <?= paginate($total, $per, $page, 'orders.php') ?>
<?php endif; ?>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>
