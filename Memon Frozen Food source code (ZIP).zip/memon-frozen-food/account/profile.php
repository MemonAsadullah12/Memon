<?php
// Profile: edit name/whatsapp/email; change password with current-password check.
$ROOT = '../'; $page_title = 'My Profile';
require_once __DIR__ . '/../includes/header.php';
require_customer();
$c = current_customer();
$pdo = db();

if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST') {
    csrf_check();
    if (($_POST['form'] ?? '') === 'info') {
        $name = trim($_POST['name'] ?? '');
        $wa = clean_phone($_POST['whatsapp'] ?? '');
        $email = trim($_POST['email'] ?? '');
        if ($name === '' || mb_strlen($name) < 3) {
            flash('Please enter your full name.', 'danger');
        } elseif ($email !== '' && !filter_var($email, FILTER_VALIDATE_EMAIL)) {
            flash('Please enter a valid email or leave it blank.', 'danger');
        } else {
            $pdo->prepare("UPDATE customers SET name = ?, whatsapp_number = ?, email = ? WHERE id = ?")
                ->execute([$name, $wa ?: null, $email ?: null, (int)$c['id']]);
            flash('Profile updated.');
            redirect('profile.php');
        }
    } elseif (($_POST['form'] ?? '') === 'password') {
        $cur = $_POST['current_password'] ?? '';
        $new = $_POST['new_password'] ?? '';
        $new2 = $_POST['new_password2'] ?? '';
        $st = $pdo->prepare("SELECT password_hash FROM customers WHERE id = ?");
        $st->execute([(int)$c['id']]);
        $hash = $st->fetchColumn();
        if (!password_verify($cur, $hash)) {
            flash('Current password is incorrect.', 'danger');
        } elseif (mb_strlen($new) < 6) {
            flash('New password must be at least 6 characters.', 'danger');
        } elseif ($new !== $new2) {
            flash('New passwords do not match.', 'danger');
        } else {
            $pdo->prepare("UPDATE customers SET password_hash = ? WHERE id = ?")
                ->execute([password_hash($new, PASSWORD_DEFAULT), (int)$c['id']]);
            flash('Password changed.');
            redirect('profile.php');
        }
    }
}
$c = current_customer(); // refresh
?>
<h1 class="page-heading">My Profile</h1>
<div class="row">
  <div class="col-md-6 mb-3">
    <div class="card"><div class="card-body">
      <h5>Personal Details</h5>
      <form method="post">
        <?= csrf_field() ?>
        <input type="hidden" name="form" value="info">
        <div class="mb-2"><label class="form-label">Full Name</label>
          <input class="form-control" name="name" required maxlength="100" value="<?= esc($c['name']) ?>"></div>
        <div class="mb-2"><label class="form-label">Phone (login — cannot change)</label>
          <input class="form-control" value="<?= esc($c['phone']) ?>" disabled></div>
        <div class="mb-2"><label class="form-label">WhatsApp</label>
          <input class="form-control" name="whatsapp" maxlength="13" value="<?= esc($c['whatsapp_number'] ?? '') ?>"></div>
        <div class="mb-3"><label class="form-label">Email</label>
          <input type="email" class="form-control" name="email" maxlength="120" value="<?= esc($c['email'] ?? '') ?>"></div>
        <button class="btn btn-maroon" type="submit">Save Changes</button>
      </form>
    </div></div>
  </div>
  <div class="col-md-6">
    <div class="card"><div class="card-body">
      <h5>Change Password</h5>
      <form method="post">
        <?= csrf_field() ?>
        <input type="hidden" name="form" value="password">
        <div class="mb-2"><label class="form-label">Current Password</label>
          <input type="password" class="form-control" name="current_password" required></div>
        <div class="mb-2"><label class="form-label">New Password (min 6)</label>
          <input type="password" class="form-control" name="new_password" required minlength="6"></div>
        <div class="mb-3"><label class="form-label">Confirm New Password</label>
          <input type="password" class="form-control" name="new_password2" required minlength="6"></div>
        <button class="btn btn-maroon" type="submit">Change Password</button>
      </form>
    </div></div>
  </div>
</div>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>
