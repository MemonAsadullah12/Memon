<?php
// Customer registration: name, unique phone, password >= 6. Auto-login on success.
$ROOT = '../'; $page_title = 'Create Account';
require_once __DIR__ . '/../includes/header.php';

if (current_customer()) redirect('dashboard.php');

$err = '';
if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST') {
    csrf_check();
    $name = trim($_POST['name'] ?? '');
    $phone = clean_phone($_POST['phone'] ?? '');
    $wa = clean_phone($_POST['whatsapp'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $pw = $_POST['password'] ?? '';
    $pw2 = $_POST['password2'] ?? '';

    if ($name === '' || mb_strlen($name) < 3)            $err = 'Please enter your full name.';
    elseif (!valid_mobile($phone))                      $err = 'Please enter a valid 10–11 digit mobile number.';
    elseif (mb_strlen($pw) < 6)                         $err = 'Password must be at least 6 characters.';
    elseif ($pw !== $pw2)                               $err = 'Passwords do not match.';
    elseif ($email !== '' && !filter_var($email, FILTER_VALIDATE_EMAIL)) $err = 'Please enter a valid email or leave it blank.';
    else {
        $st = db()->prepare("SELECT id FROM customers WHERE phone = ? LIMIT 1");
        $st->execute([$phone]);
        if ($st->fetch()) {
            $err = 'This phone number is already registered. Please log in.';
        } else {
            $st = db()->prepare(
                "INSERT INTO customers (name, phone, whatsapp_number, email, password_hash, is_active) VALUES (?,?,?,?,?,1)"
            );
            $st->execute([$name, $phone, $wa ?: null, $email ?: null, password_hash($pw, PASSWORD_DEFAULT)]);
            session_regenerate_id(true);
            $_SESSION['customer_id'] = (int)db()->lastInsertId();
            flash('Welcome, ' . $name . '! Your account is ready.');
            redirect('dashboard.php');
        }
    }
}
?>
<h1 class="page-heading">Create Account</h1>
<div class="row justify-content-center"><div class="col-md-5">
  <div class="card"><div class="card-body">
    <?php if ($err): ?><div class="alert alert-danger"><?= esc($err) ?></div><?php endif; ?>
    <form method="post">
      <?= csrf_field() ?>
      <div class="mb-2"><label class="form-label">Full Name *</label><input class="form-control" name="name" required maxlength="100" value="<?= esc($_POST['name'] ?? '') ?>"></div>
      <div class="mb-2"><label class="form-label">Mobile Number *</label><input class="form-control" name="phone" required maxlength="13" placeholder="03xx-xxxxxxx" value="<?= esc($_POST['phone'] ?? '') ?>"></div>
      <div class="mb-2"><label class="form-label">WhatsApp (optional)</label><input class="form-control" name="whatsapp" maxlength="13" value="<?= esc($_POST['whatsapp'] ?? '') ?>"></div>
      <div class="mb-2"><label class="form-label">Email (optional)</label><input type="email" class="form-control" name="email" maxlength="120" value="<?= esc($_POST['email'] ?? '') ?>"></div>
      <div class="mb-2"><label class="form-label">Password * (min 6 characters)</label><input type="password" class="form-control" name="password" required minlength="6"></div>
      <div class="mb-3"><label class="form-label">Confirm Password *</label><input type="password" class="form-control" name="password2" required minlength="6"></div>
      <button class="btn btn-maroon w-100" type="submit">Register</button>
    </form>
    <p class="text-center mt-2 mb-0 small">Already have an account? <a href="login.php">Log in</a></p>
  </div></div>
</div></div>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>
