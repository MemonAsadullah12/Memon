<?php
// Admin shared helpers (Worker C). Complements includes/helpers.php from the shared contract.
// Every admin page requires this right after require_admin().

// Ensure a session is active (the admin panel does not load the public header).
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (!function_exists('mff_statuses')) {
    // Order status code => human label (codes match the shared contract).
    function mff_statuses(): array
    {
        return [
            'received'         => 'Received',
            'confirmed'        => 'Confirmed',
            'preparing'        => 'Preparing',
            'ready'            => 'Ready',
            'out_for_delivery' => 'Out for Delivery',
            'delivered'        => 'Delivered',
            'cancelled'        => 'Cancelled',
            'returned'         => 'Returned',
        ];
    }
}

if (!function_exists('mff_status_label')) {
    function mff_status_label(string $s): string
    {
        return mff_statuses()[$s] ?? ucfirst(str_replace('_', ' ', $s));
    }
}

if (!function_exists('mff_status_badge')) {
    function mff_status_badge(string $s): string
    {
        $map = [
            'received' => 'secondary', 'confirmed' => 'info', 'preparing' => 'warning',
            'ready' => 'primary', 'out_for_delivery' => 'dark',
            'delivered' => 'success', 'cancelled' => 'danger', 'returned' => 'danger',
        ];
        return '<span class="badge bg-' . ($map[$s] ?? 'secondary') . '">' . esc(mff_status_label($s)) . '</span>';
    }
}

if (!function_exists('mff_payment_badge')) {
    function mff_payment_badge(string $s): string
    {
        $map = ['pending' => 'warning', 'partial' => 'info', 'paid' => 'success', 'refunded' => 'secondary', 'failed' => 'danger'];
        return '<span class="badge bg-' . ($map[$s] ?? 'secondary') . '">' . esc(ucfirst($s)) . '</span>';
    }
}

if (!function_exists('mff_transitions')) {
    // Valid order status transitions (shared contract).
    function mff_transitions(): array
    {
        return [
            'received'         => ['confirmed', 'cancelled'],
            'confirmed'        => ['preparing', 'cancelled'],
            'preparing'        => ['ready', 'cancelled'],
            'ready'            => ['out_for_delivery', 'cancelled'],
            'out_for_delivery' => ['delivered', 'cancelled'],
            'delivered'        => ['returned'],
            'cancelled'        => [],
            'returned'         => [],
        ];
    }
}

if (!function_exists('mff_can_transition')) {
    // Prefer the shared helper from includes/helpers.php; fall back to the local map.
    function mff_can_transition(string $from, string $to): bool
    {
        if (function_exists('can_transition')) {
            try {
                return (bool) can_transition($from, $to);
            } catch (Throwable $e) {
            }
        }
        return in_array($to, mff_transitions()[$from] ?? [], true);
    }
}

if (!function_exists('mff_flash')) {
    // Store a flash message: use the shared flash() and our own key (reliable display).
    function mff_flash(string $msg, string $type = 'success'): void
    {
        if (function_exists('flash')) {
            try {
                flash($msg, $type);
            } catch (Throwable $e) {
            }
        }
        $_SESSION['mff_notices'][] = ['type' => $type, 'msg' => $msg];
    }
}

if (!function_exists('mff_notices_html')) {
    function mff_notices_html(): string
    {
        $out = '';
        foreach (($_SESSION['mff_notices'] ?? []) as $n) {
            $type = in_array($n['type'], ['success', 'danger', 'warning', 'info'], true) ? $n['type'] : 'info';
            $out .= '<div class="alert alert-' . $type . ' alert-dismissible fade show" role="alert">'
                . esc($n['msg'])
                . '<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button></div>';
        }
        unset($_SESSION['mff_notices']);
        return $out;
    }
}

if (!function_exists('mff_audit')) {
    // Prefer the shared audit() helper; fall back to a direct insert into audit_logs.
    // Real signature: audit(?int $adminId, string $action, ?string $type, ?int $rid, $old, $new).
    function mff_audit(string $action, string $recordType = '', $recordId = null, $old = null, $new = null): void
    {
        $admin = function_exists('current_admin') ? current_admin() : null;
        $adminId = isset($admin['id']) ? (int) $admin['id'] : null;
        if (function_exists('audit')) {
            try {
                audit($adminId, $action, $recordType !== '' ? $recordType : null,
                    $recordId === null ? null : (int) $recordId, $old, $new);
                return;
            } catch (Throwable $e) {
            }
        }
        try {
            $norm = function ($v) {
                return $v === null ? null : (is_scalar($v) ? (string) $v : json_encode($v));
            };
            $st = db()->prepare(
                'INSERT INTO audit_logs (admin_id, action, record_type, record_id, old_value, new_value, ip_address)
                 VALUES (?,?,?,?,?,?,?)'
            );
            $st->execute([
                $adminId, $action, $recordType, $recordId === null ? null : (int) $recordId,
                $norm($old), $norm($new), $_SERVER['REMOTE_ADDR'] ?? null,
            ]);
        } catch (Throwable $e) {
        }
    }
}

if (!function_exists('mff_setting')) {
    // Prefer the shared get_setting(); fall back to a direct query.
    function mff_setting(string $key, $default = '')
    {
        if (function_exists('get_setting')) {
            try {
                return get_setting($key, $default);
            } catch (Throwable $e) {
            }
        }
        try {
            $st = db()->prepare('SELECT setting_value FROM business_settings WHERE setting_key = ? LIMIT 1');
            $st->execute([$key]);
            $v = $st->fetchColumn();
            return $v === false ? $default : $v;
        } catch (Throwable $e) {
            return $default;
        }
    }
}

if (!function_exists('mff_date')) {
    function mff_date(?string $dt, bool $withTime = true): string
    {
        if (!$dt) {
            return '—';
        }
        $ts = strtotime($dt);
        if ($ts === false) {
            return esc($dt);
        }
        return date($withTime ? 'd M Y, h:i A' : 'd M Y', $ts);
    }
}

if (!function_exists('mff_pagination')) {
    // Small Bootstrap pagination renderer. $params are the preserved GET params (without page).
    function mff_pagination(int $total, int $page, int $per, string $baseUrl, array $params = []): string
    {
        $pages = max(1, (int) ceil($total / $per));
        if ($pages <= 1) {
            return '<p class="text-muted small mb-0">' . $total . ' record(s)</p>';
        }
        $page = max(1, min($page, $pages));
        unset($params['page']);
        $q = http_build_query($params);
        $sep = $q === '' ? '' : '&';
        $html = '<nav aria-label="Pagination"><ul class="pagination pagination-sm mb-0 flex-wrap">';
        $html .= '<li class="page-item' . ($page <= 1 ? ' disabled' : '') . '"><a class="page-link" href="' . $baseUrl . '?' . $q . $sep . 'page=' . ($page - 1) . '">‹</a></li>';
        $start = max(1, $page - 2);
        $end = min($pages, $page + 2);
        if ($start > 1) {
            $html .= '<li class="page-item"><a class="page-link" href="' . $baseUrl . '?' . $q . $sep . 'page=1">1</a></li>';
            if ($start > 2) {
                $html .= '<li class="page-item disabled"><span class="page-link">…</span></li>';
            }
        }
        for ($i = $start; $i <= $end; $i++) {
            $html .= '<li class="page-item' . ($i === $page ? ' active' : '') . '"><a class="page-link" href="' . $baseUrl . '?' . $q . $sep . 'page=' . $i . '">' . $i . '</a></li>';
        }
        if ($end < $pages) {
            if ($end < $pages - 1) {
                $html .= '<li class="page-item disabled"><span class="page-link">…</span></li>';
            }
            $html .= '<li class="page-item"><a class="page-link" href="' . $baseUrl . '?' . $q . $sep . 'page=' . $pages . '">' . $pages . '</a></li>';
        }
        $html .= '<li class="page-item' . ($page >= $pages ? ' disabled' : '') . '"><a class="page-link" href="' . $baseUrl . '?' . $q . $sep . 'page=' . ($page + 1) . '">›</a></li>';
        $html .= '</ul></nav><p class="text-muted small mt-1 mb-0">Page ' . $page . ' of ' . $pages . ' · ' . $total . ' record(s)</p>';
        return $html;
    }
}

if (!function_exists('mff_csv_download')) {
    // Stream a CSV download and exit. Caller must have checked permissions already.
    function mff_csv_download(string $filename, array $headers, iterable $rows): void
    {
        while (ob_get_level() > 0) {
            ob_end_clean();
        }
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename="' . $filename . '"');
        header('Pragma: no-cache');
        $out = fopen('php://output', 'w');
        fwrite($out, "\xEF\xBB\xBF"); // BOM for Excel
        fputcsv($out, $headers);
        foreach ($rows as $r) {
            fputcsv($out, array_values((array) $r));
        }
        fclose($out);
        exit;
    }
}

if (!function_exists('mff_slug')) {
    function mff_slug(string $s): string
    {
        $s = mb_strtolower(trim($s), 'UTF-8');
        $s = (string) preg_replace('/[^a-z0-9]+/', '-', $s);
        $s = trim($s, '-');
        return $s === '' ? 'item' : $s;
    }
}

if (!function_exists('mff_unique_slug')) {
    function mff_unique_slug(PDO $db, string $table, string $slug, ?int $ignoreId = null): string
    {
        $base = $slug;
        $i = 2;
        while (true) {
            $sql = "SELECT id FROM {$table} WHERE slug = ?" . ($ignoreId ? ' AND id <> ?' : '') . ' LIMIT 1';
            $st = $db->prepare($sql);
            $ignoreId ? $st->execute([$slug, $ignoreId]) : $st->execute([$slug]);
            if (!$st->fetch()) {
                return $slug;
            }
            $slug = $base . '-' . ($i++);
        }
    }
}

if (!function_exists('mff_upload_image')) {
    /**
     * Validate + store an uploaded image. Returns the web-root-relative path,
     * null when no file was uploaded, and throws RuntimeException on invalid upload.
     */
    function mff_upload_image(array $file, string $subdir = 'products'): ?string
    {
        if (($file['error'] ?? UPLOAD_ERR_NO_FILE) === UPLOAD_ERR_NO_FILE) {
            return null;
        }
        if (($file['error'] ?? 0) !== UPLOAD_ERR_OK) {
            throw new RuntimeException('Image upload failed.');
        }
        if (($file['size'] ?? 0) > 2 * 1024 * 1024) {
            throw new RuntimeException('Image must be 2 MB or smaller.');
        }
        $finfo = new finfo(FILEINFO_MIME_TYPE);
        $mime = $finfo->file($file['tmp_name']);
        $exts = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp'];
        if (!isset($exts[$mime])) {
            throw new RuntimeException('Only JPG, PNG or WebP images are allowed.');
        }
        $dir = dirname(__DIR__) . '/assets/uploads/' . $subdir . '/';
        if (!is_dir($dir) && !mkdir($dir, 0755, true)) {
            throw new RuntimeException('Could not create upload directory.');
        }
        $name = $subdir . '_' . date('YmdHis') . '_' . bin2hex(random_bytes(6)) . '.' . $exts[$mime];
        if (!move_uploaded_file($file['tmp_name'], $dir . $name)) {
            throw new RuntimeException('Could not save the uploaded image.');
        }
        return 'assets/uploads/' . $subdir . '/' . $name; // web-root-relative
    }
}

if (!function_exists('mff_order_outstanding')) {
    // Amount still unpaid on an order: total − SUM(payments received/pending).
    function mff_order_outstanding(PDO $db, int $orderId): int
    {
        $st = $db->prepare(
            "SELECT o.total_amount - COALESCE((SELECT SUM(amount) FROM payments WHERE order_id = o.id AND status IN ('received','pending')), 0)
             FROM orders o WHERE o.id = ?"
        );
        $st->execute([$orderId]);
        return (int) $st->fetchColumn();
    }
}
