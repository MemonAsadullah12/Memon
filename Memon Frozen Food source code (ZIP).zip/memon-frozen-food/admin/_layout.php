<?php
// Admin shell: sidebar + topbar. Every admin page sets $page_title and $content,
// then includes this file. require_admin() has already run on the calling page.
$admin = function_exists('current_admin') ? current_admin() : null;
$unread = 0;
try {
    $unread = (int) db()->query('SELECT COUNT(*) FROM notifications WHERE is_read = 0')->fetchColumn();
} catch (Throwable $e) {
}
$current = basename($_SERVER['SCRIPT_NAME'] ?? '');

// [label, url, permission code] — null permission = always visible.
$nav = [
    ['group' => null, 'items' => [
        ['Dashboard', 'index.php', 'dashboard.view', '📊'],
    ]],
    ['group' => 'Catalog', 'items' => [
        ['Products', 'products.php', 'products.view', '🍗'],
        ['Categories', 'categories.php', 'categories.manage', '🗂️'],
    ]],
    ['group' => 'Sales', 'items' => [
        ['Orders', 'orders.php', 'orders.view', '🧾'],
        ['Coupons', 'coupons.php', 'coupons.manage', '🎟️'],
        ['Payments', 'payments.php', 'payments.view', '💵'],
    ]],
    ['group' => 'Stock', 'items' => [
        ['Inventory', 'inventory.php', 'inventory.view', '📦'],
        ['Stock Movements', 'stock-movements.php', 'inventory.view', '🔄'],
    ]],
    ['group' => 'People', 'items' => [
        ['Customers', 'customers.php', 'customers.view', '👥'],
    ]],
    ['group' => 'Logistics', 'items' => [
        ['Delivery Zones', 'delivery-zones.php', 'deliveries.view', '🗺️'],
        ['Delivery Assignments', 'delivery-assignments.php', 'deliveries.view', '🛵'],
    ]],
    ['group' => 'Marketing', 'items' => [
        ['Content', 'content.php', 'content.edit', '🖼️'],
        ['Notifications', 'notifications.php', 'notifications.view', '🔔'],
    ]],
    ['group' => 'Insights', 'items' => [
        ['Reports', 'reports.php', 'reports.view', '📈'],
    ]],
    ['group' => 'System', 'items' => [
        ['Settings', 'settings.php', 'settings.edit', '⚙️'],
        ['Users', 'users.php', 'users.manage', '👤'],
        ['Roles', 'roles.php', 'users.manage', '🔑'],
        ['Backups', 'backups.php', 'backups.run', '💾'],
        ['Audit Logs', 'audit-logs.php', 'audit.view', '📝'],
    ]],
];
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= esc($page_title ?? 'Admin') ?> · <?= esc(defined('SITE_NAME') ? SITE_NAME : 'Memon Frozen Food') ?> Admin</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<style>
:root{
  --maroon:#970D0D; --deepred:#790808; --gold:#FFD54A; --cream:#FFF8E9;
  --ink:#222222; --success:#228B52; --warning:#E9A23B;
}
body{background:#f6f1e7;color:var(--ink);font-size:.92rem;}
/* Sidebar */
#adminSidebar{background:linear-gradient(180deg,var(--maroon),var(--deepred));color:#fff;}
#adminSidebar .brand{border-bottom:1px solid rgba(255,255,255,.15);}
#adminSidebar .brand-name{font-weight:800;letter-spacing:.5px;}
#adminSidebar .brand-tag{color:var(--gold);font-size:.72rem;letter-spacing:2px;font-weight:700;}
#adminSidebar .nav-group{color:var(--gold);font-size:.68rem;font-weight:700;letter-spacing:1.5px;text-transform:uppercase;opacity:.9;}
#adminSidebar .nav-link{color:#f7e9d2;border-radius:.4rem;margin:1px 0;padding:.45rem .7rem;}
#adminSidebar .nav-link:hover{background:rgba(255,255,255,.12);color:#fff;}
#adminSidebar .nav-link.active{background:var(--gold);color:var(--deepred);font-weight:700;}
#adminSidebar .offcanvas-body{scrollbar-width:thin;}
/* Topbar */
.topbar{background:#fff;border-bottom:1px solid #e7dcc3;position:sticky;top:0;z-index:1020;}
.topbar .page-title{font-weight:800;color:var(--maroon);}
.bell{position:relative;color:var(--maroon);}
.bell .count{position:absolute;top:-6px;right:-8px;background:var(--maroon);color:#fff;font-size:.62rem;border-radius:50%;min-width:17px;height:17px;line-height:17px;text-align:center;font-weight:700;}
/* Cards & tables */
.card{border:1px solid #e7dcc3;border-radius:.6rem;box-shadow:0 1px 2px rgba(0,0,0,.04);}
.card-header{background:var(--cream);font-weight:700;color:var(--maroon);border-bottom:1px solid #e7dcc3;}
.stat-card{border-left:4px solid var(--maroon);}
.stat-card .stat-num{font-size:1.5rem;font-weight:800;color:var(--maroon);}
.stat-card a{text-decoration:none;}
.btn-maroon{background:var(--maroon);border-color:var(--maroon);color:#fff;}
.btn-maroon:hover{background:var(--deepred);border-color:var(--deepred);color:#fff;}
.btn-gold{background:var(--gold);border-color:var(--gold);color:var(--deepred);font-weight:700;}
.btn-gold:hover{background:#f5c62e;border-color:#f5c62e;color:var(--deepred);}
.table thead th{background:var(--maroon);color:#fff;font-size:.78rem;letter-spacing:.3px;white-space:nowrap;}
.table td{vertical-align:middle;}
.table-responsive{overflow-x:auto;}
.badge{font-size:.72rem;}
.thumb{width:44px;height:44px;object-fit:cover;border-radius:.35rem;border:1px solid #e7dcc3;}
tr.low-stock{background:#fff3f3;}
.form-label{font-weight:600;font-size:.82rem;}
.required::after{content:" *";color:var(--maroon);}
.timeline{border-left:3px solid var(--gold);margin-left:.5rem;padding-left:1rem;}
.timeline .t-item{position:relative;padding-bottom:1rem;}
.timeline .t-item::before{content:"";position:absolute;left:-1.32rem;top:.25rem;width:.7rem;height:.7rem;border-radius:50%;background:var(--maroon);}
@media print{.topbar,#adminSidebar,.no-print{display:none!important;}}
</style>
</head>
<body>

<div class="d-lg-flex align-items-lg-stretch">
<div class="offcanvas-lg offcanvas-start flex-shrink-0" tabindex="-1" id="adminSidebar" aria-label="Admin navigation" style="width:250px;">
  <div class="offcanvas-body d-flex flex-column p-0 vh-100 sticky-lg-top">
    <div class="brand p-3 text-center position-relative">
      <button type="button" class="btn-close btn-close-white position-absolute top-0 end-0 m-2 d-lg-none" data-bs-dismiss="offcanvas" aria-label="Close"></button>
      <div class="brand-name fs-5">Memon Frozen Food</div>
      <div class="brand-tag">HYGIENIC TASTE</div>
    </div>
    <nav class="p-2 flex-grow-1 overflow-auto">
      <?php foreach ($nav as $section): ?>
        <?php
        $visible = array_filter($section['items'], function ($it) {
            return $it[2] === null || (function_exists('has_perm') && has_perm($it[2]));
        });
        if (!$visible) {
            continue;
        }
        ?>
        <?php if ($section['group']): ?>
          <div class="nav-group px-2 mt-3 mb-1"><?= esc($section['group']) ?></div>
        <?php endif; ?>
        <?php foreach ($visible as $it): [$label, $url, $perm, $icon] = $it; ?>
          <a class="nav-link <?= $current === $url ? 'active' : '' ?>" href="<?= esc($url) ?>">
            <span class="me-2"><?= $icon ?></span><?= esc($label) ?>
          </a>
        <?php endforeach; ?>
      <?php endforeach; ?>
    </nav>
    <div class="p-3 border-top border-light border-opacity-25 small text-center" style="color:#f7e9d2;">
      Khairpur Mirs · <?= esc(defined('ORDER_PHONE') ? ORDER_PHONE : '0300-3130608') ?>
    </div>
  </div>
</div>

<div class="flex-grow-1 d-flex flex-column min-vh-100" style="min-width:0;">
  <nav class="topbar d-flex align-items-center gap-2 px-3 py-2">
    <button class="btn btn-sm btn-outline-secondary d-lg-none" type="button" data-bs-toggle="offcanvas" data-bs-target="#adminSidebar" aria-controls="adminSidebar">☰</button>
    <span class="page-title fs-5 mb-0"><?= esc($page_title ?? 'Admin') ?></span>
    <div class="ms-auto d-flex align-items-center gap-2">
      <?= $page_actions ?? '' ?>
      <a href="notifications.php" class="bell text-decoration-none me-1" title="Notifications" aria-label="Notifications">
        <span class="fs-5">🔔</span>
        <?php if ($unread > 0): ?><span class="count"><?= $unread > 99 ? '99+' : $unread ?></span><?php endif; ?>
      </a>
      <a href="../index.php" class="btn btn-sm btn-outline-secondary" target="_blank" rel="noopener">🌐 View Site</a>
      <span class="d-none d-md-inline small text-muted"><?= esc($admin['name'] ?? 'Admin') ?></span>
      <a href="logout.php" class="btn btn-sm btn-maroon">Logout</a>
    </div>
  </nav>

  <main class="container-fluid py-3 flex-grow-1" style="max-width:1400px;">
    <?= function_exists('mff_notices_html') ? mff_notices_html() : '' ?>
    <?= $content ?? '' ?>
  </main>

  <footer class="text-center small text-muted py-2 border-top">
    <?= esc(defined('SITE_NAME') ? SITE_NAME : 'Memon Frozen Food') ?> · Admin Panel · <?= date('Y') ?>
  </footer>
</div><!-- /flex wrapper -->
</div><!-- /d-lg-flex -->

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
