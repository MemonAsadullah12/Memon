<?php
// Read-only audit trail viewer.
require_once __DIR__ . '/../includes/auth.php';
require_admin('audit.view');
require_once __DIR__ . '/_helpers.php';
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/helpers.php';

$db = db();
$page_title = 'Audit Logs';

$action = $_GET['action'] ?? '';
$adminId = (int) ($_GET['admin_id'] ?? 0);
$dfrom = $_GET['dfrom'] ?? '';
$dto = $_GET['dto'] ?? '';
$q = trim($_GET['q'] ?? '');

$where = [];
$params = [];
if ($action !== '') {
    $where[] = 'a.action = ?';
    $params[] = $action;
}
if ($adminId > 0) {
    $where[] = 'a.admin_id = ?';
    $params[] = $adminId;
}
if ($dfrom !== '' && preg_match('/^\d{4}-\d{2}-\d{2}$/', $dfrom)) {
    $where[] = 'DATE(a.created_at) >= ?';
    $params[] = $dfrom;
}
if ($dto !== '' && preg_match('/^\d{4}-\d{2}-\d{2}$/', $dto)) {
    $where[] = 'DATE(a.created_at) <= ?';
    $params[] = $dto;
}
if ($q !== '') {
    $where[] = '(a.record_type LIKE ? OR CAST(a.record_id AS CHAR) LIKE ? OR a.ip_address LIKE ?)';
    $params[] = "%$q%";
    $params[] = "%$q%";
    $params[] = "%$q%";
}
$whereSql = $where ? 'WHERE ' . implode(' AND ', $where) : '';

$st = $db->prepare("SELECT COUNT(*) FROM audit_logs a $whereSql");
$st->execute($params);
$total = (int) $st->fetchColumn();
$page = max(1, (int) ($_GET['page'] ?? 1));
$per = 25;
$offset = ($page - 1) * $per;

$st = $db->prepare(
    "SELECT a.*, u.name AS admin_name FROM audit_logs a
     LEFT JOIN users u ON u.id = a.admin_id
     $whereSql ORDER BY a.id DESC LIMIT $per OFFSET $offset"
);
$st->execute($params);
$rows = $st->fetchAll();

$actions = $db->query('SELECT DISTINCT action FROM audit_logs ORDER BY action')->fetchAll(PDO::FETCH_COLUMN);
$admins = $db->query('SELECT u.id, u.name FROM users u WHERE EXISTS (SELECT 1 FROM audit_logs a WHERE a.admin_id = u.id) ORDER BY u.name')->fetchAll();

ob_start();
?>
<div class="card mb-3"><div class="card-body">
  <form method="get" class="row g-2">
    <div class="col-md-3"><select name="action" class="form-select form-select-sm">
      <option value="">All actions</option>
      <?php foreach ($actions as $ac): ?><option <?= $action === $ac ? 'selected' : '' ?>><?= esc($ac) ?></option><?php endforeach; ?>
    </select></div>
    <div class="col-md-2"><select name="admin_id" class="form-select form-select-sm">
      <option value="0">All admins</option>
      <?php foreach ($admins as $ad): ?><option value="<?= (int) $ad['id'] ?>" <?= $adminId === (int) $ad['id'] ? 'selected' : '' ?>><?= esc($ad['name']) ?></option><?php endforeach; ?>
    </select></div>
    <div class="col-md-2"><input type="date" name="dfrom" class="form-control form-control-sm" value="<?= esc($dfrom) ?>" title="From date"></div>
    <div class="col-md-2"><input type="date" name="dto" class="form-control form-control-sm" value="<?= esc($dto) ?>" title="To date"></div>
    <div class="col-md-2"><input type="text" name="q" class="form-control form-control-sm" placeholder="Record type / id / IP…" value="<?= esc($q) ?>"></div>
    <div class="col-md-1"><button class="btn btn-sm btn-maroon w-100">Go</button></div>
  </form>
</div></div>

<div class="card"><div class="table-responsive"><table class="table table-sm mb-0">
  <thead><tr><th>Time</th><th>Admin</th><th>Action</th><th>Record</th><th>Old value</th><th>New value</th><th>IP</th></tr></thead>
  <tbody>
  <?php if (!$rows): ?><tr><td colspan="7" class="text-center text-muted py-4">No audit entries found.</td></tr><?php endif; ?>
  <?php foreach ($rows as $r): ?>
    <tr>
      <td class="small text-nowrap"><?= esc(mff_date($r['created_at'])) ?></td>
      <td><?= esc($r['admin_name'] ?? 'System') ?></td>
      <td><code class="small"><?= esc($r['action']) ?></code></td>
      <td class="small"><?= $r['record_type'] ? esc($r['record_type']) . ' #' . esc((string) $r['record_id']) : '—' ?></td>
      <td class="small" title="<?= esc($r['old_value'] ?? '') ?>"><?= esc(mb_substr($r['old_value'] ?? '', 0, 60)) ?: '—' ?></td>
      <td class="small" title="<?= esc($r['new_value'] ?? '') ?>"><?= esc(mb_substr($r['new_value'] ?? '', 0, 60)) ?: '—' ?></td>
      <td class="small text-muted"><?= esc($r['ip_address'] ?? '—') ?></td>
    </tr>
  <?php endforeach; ?>
  </tbody>
</table></div></div>
<div class="mt-2"><?= mff_pagination($total, $page, $per, 'audit-logs.php', ['action' => $action, 'admin_id' => $adminId, 'dfrom' => $dfrom, 'dto' => $dto, 'q' => $q]) ?></div>
<?php
$content = ob_get_clean();
include __DIR__ . '/_layout.php';
