<?php
// Database backups. Dumps are generated in pure PHP (SHOW CREATE TABLE + chunked
// INSERTs — no mysqldump / exec dependency) and stored under database/backups/,
// which is protected by a "Deny from all" .htaccess. Downloads are served through
// this script only, never via a direct URL.
require_once __DIR__ . '/../includes/auth.php';
require_admin('backups.run');
require_once __DIR__ . '/_helpers.php';
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/helpers.php';

$db = db();
$page_title = 'Backups';
$backupDir = dirname(__DIR__) . '/database/backups/';

/**
 * Write a full SQL dump of the current database to $file.
 * Uses SHOW CREATE TABLE for schema and chunked SELECTs for data.
 */
function mff_create_dump(PDO $db, string $file): void
{
    $fh = fopen($file, 'wb');
    if (!$fh) {
        throw new RuntimeException('Could not write to the backup directory.');
    }
    $write = function (string $s) use ($fh) {
        fwrite($fh, $s);
    };

    $dbName = (string) $db->query('SELECT DATABASE()')->fetchColumn();
    $write("-- Memon Frozen Food database backup\n");
    $write('-- Database: ' . $dbName . "\n");
    $write('-- Created: ' . date('Y-m-d H:i:s') . "\n\n");
    $write("SET FOREIGN_KEY_CHECKS=0;\n\n");

    $tables = $db->query('SHOW TABLES')->fetchAll(PDO::FETCH_COLUMN);
    foreach ($tables as $table) {
        // Table names come from the server itself; still quote them defensively.
        $qt = '`' . str_replace('`', '``', $table) . '`';
        $create = $db->query("SHOW CREATE TABLE $qt")->fetch();
        $write("-- --------------------------------------------------------\n");
        $write("-- Table structure for $qt\n\n");
        $write("DROP TABLE IF EXISTS $qt;\n");
        $write($create['Create Table'] . ";\n\n");

        $count = (int) $db->query("SELECT COUNT(*) FROM $qt")->fetchColumn();
        if ($count === 0) {
            continue;
        }
        $write("-- Data for $qt ($count rows)\n");
        $cols = $db->query("SHOW COLUMNS FROM $qt")->fetchAll(PDO::FETCH_COLUMN);
        $colList = implode(', ', array_map(fn($c) => '`' . str_replace('`', '``', $c) . '`', $cols));

        $chunk = 500;
        for ($offset = 0; $offset < $count; $offset += $chunk) {
            $rows = $db->query("SELECT * FROM $qt LIMIT $chunk OFFSET $offset")->fetchAll(PDO::FETCH_NUM);
            if (!$rows) {
                break;
            }
            $write("INSERT INTO $qt ($colList) VALUES\n");
            $lines = [];
            foreach ($rows as $row) {
                $vals = array_map(fn($v) => $v === null ? 'NULL' : $db->quote((string) $v), $row);
                $lines[] = '(' . implode(', ', $vals) . ')';
            }
            $write(implode(",\n", $lines) . ";\n");
        }
        $write("\n");
    }
    $write("SET FOREIGN_KEY_CHECKS=1;\n");
    fclose($fh);
}

// --- Create a new backup ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'create') {
    csrf_check();
    try {
        if (!is_dir($backupDir) && !mkdir($backupDir, 0755, true)) {
            throw new RuntimeException('Could not create the backup directory.');
        }
        // Keep the .htaccess protection in place even if the directory was recreated.
        $ht = $backupDir . '.htaccess';
        if (!file_exists($ht)) {
            file_put_contents($ht, "Deny from all\n");
        }
        $filename = 'mff-backup-' . date('Ymd-His') . '.sql';
        set_time_limit(0);
        mff_create_dump($db, $backupDir . $filename);
        $size = filesize($backupDir . $filename);
        $db->prepare('INSERT INTO backup_logs (filename, size_bytes, admin_id) VALUES (?,?,?)')
            ->execute([$filename, $size, current_admin()['id'] ?? null]);
        mff_audit('backup.create', 'backup_logs', (int) $db->lastInsertId(), null, ['filename' => $filename, 'size' => $size]);
        mff_flash('Backup created: ' . $filename . ' (' . number_format($size) . ' bytes).');
    } catch (Throwable $e) {
        mff_flash('Backup failed: ' . $e->getMessage(), 'danger');
    }
    redirect('backups.php');
}

// --- Delete an old backup file ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'delete') {
    csrf_check();
    $bid = (int) ($_POST['id'] ?? 0);
    $row = $db->query('SELECT * FROM backup_logs WHERE id = ' . $bid)->fetch();
    if ($row && preg_match('/^mff-backup-[0-9-]+\.sql$/', $row['filename'])) {
        @unlink($backupDir . $row['filename']);
        $db->prepare('DELETE FROM backup_logs WHERE id = ?')->execute([$bid]);
        mff_audit('backup.delete', 'backup_logs', $bid, $row['filename'], null);
        mff_flash('Backup deleted.');
    }
    redirect('backups.php');
}

// --- Download through PHP (never a direct URL) ---
if (isset($_GET['download'])) {
    $bid = (int) $_GET['download'];
    $row = $db->query('SELECT * FROM backup_logs WHERE id = ' . $bid)->fetch();
    if (!$row || !preg_match('/^mff-backup-[0-9-]+\.sql$/', $row['filename'])) {
        exit('Backup not found.');
    }
    $path = $backupDir . $row['filename'];
    if (!is_file($path)) {
        exit('Backup file is missing from disk.');
    }
    while (ob_get_level() > 0) {
        ob_end_clean();
    }
    header('Content-Type: application/sql');
    header('Content-Disposition: attachment; filename="' . $row['filename'] . '"');
    header('Content-Length: ' . filesize($path));
    readfile($path);
    exit;
}

$logs = $db->query(
    'SELECT b.*, u.name AS admin_name FROM backup_logs b LEFT JOIN users u ON u.id = b.admin_id ORDER BY b.id DESC'
)->fetchAll();

ob_start();
?>
<div class="card mb-3"><div class="card-body">
  <form method="post" class="d-flex flex-wrap align-items-center gap-3">
    <input type="hidden" name="csrf" value="<?= esc(csrf_token()) ?>">
    <input type="hidden" name="action" value="create">
    <div>
      <strong>Create a full database backup</strong><br>
      <small class="text-muted">Generates a .sql dump (schema + data) and stores it in <code>database/backups/</code>.</small>
    </div>
    <button class="btn btn-maroon ms-auto" onclick="this.disabled=true;this.form.submit();">💾 Create backup now</button>
  </form>
  <hr>
  <p class="small text-muted mb-0"><strong>Retention policy:</strong> keep the most recent 30 backups (or 90 days), and
    download a copy off-site regularly. Backup files are blocked from direct web access (<code>.htaccess: Deny from all</code>)
    and can only be downloaded through this page by an admin with backup permission.</p>
</div></div>

<div class="card"><div class="card-header">Backup history (<?= count($logs) ?>)</div>
<div class="table-responsive"><table class="table table-sm mb-0">
  <thead><tr><th>File</th><th class="text-end">Size</th><th>Created</th><th>By</th><th></th></tr></thead>
  <tbody>
  <?php if (!$logs): ?><tr><td colspan="5" class="text-center text-muted py-4">No backups yet. Create your first backup above.</td></tr><?php endif; ?>
  <?php foreach ($logs as $l): ?>
    <tr>
      <td><code><?= esc($l['filename']) ?></code></td>
      <td class="text-end"><?= number_format((int) $l['size_bytes']) ?> bytes</td>
      <td class="small"><?= esc(mff_date($l['created_at'])) ?></td>
      <td class="small"><?= esc($l['admin_name'] ?? '—') ?></td>
      <td class="text-nowrap">
        <a href="backups.php?download=<?= (int) $l['id'] ?>" class="btn btn-sm btn-outline-secondary">Download</a>
        <form method="post" class="d-inline" onsubmit="return confirm('Delete this backup file permanently?')">
          <input type="hidden" name="csrf" value="<?= esc(csrf_token()) ?>">
          <input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?= (int) $l['id'] ?>">
          <button class="btn btn-sm btn-outline-danger">Delete</button>
        </form>
      </td>
    </tr>
  <?php endforeach; ?>
  </tbody>
</table></div></div>
<?php
$content = ob_get_clean();
include __DIR__ . '/_layout.php';
