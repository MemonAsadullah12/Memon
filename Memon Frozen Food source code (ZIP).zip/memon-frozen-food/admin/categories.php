<?php
require_once __DIR__ . '/../includes/auth.php';
require_admin('categories.manage');
require_once __DIR__ . '/_helpers.php';
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/helpers.php';

$db = db();
$page_title = 'Categories';

// --- Save (add/edit) ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'save') {
    csrf_check();
    $id = (int) ($_POST['id'] ?? 0);
    $name = trim($_POST['name'] ?? '');
    $description = trim($_POST['description'] ?? '');
    $sort = (int) ($_POST['sort_order'] ?? 0);
    $active = isset($_POST['is_active']) ? 1 : 0;
    if ($name === '') {
        mff_flash('Category name is required.', 'danger');
    } else {
        $slug = mff_unique_slug($db, 'categories', mff_slug($name), $id ?: null);
        if ($id > 0) {
            $old = $db->query('SELECT * FROM categories WHERE id = ' . $id)->fetch();
            $db->prepare('UPDATE categories SET name=?, slug=?, description=?, sort_order=?, is_active=? WHERE id=?')
                ->execute([$name, $slug, $description, $sort, $active, $id]);
            mff_audit('category.update', 'categories', $id, $old['name'] ?? '', $name);
            mff_flash('Category updated.');
        } else {
            $db->prepare('INSERT INTO categories (name, slug, description, sort_order, is_active) VALUES (?,?,?,?,?)')
                ->execute([$name, $slug, $description, $sort, $active]);
            $nid = (int) $db->lastInsertId();
            mff_audit('category.create', 'categories', $nid, null, $name);
            mff_flash('Category added.');
        }
    }
    redirect('categories.php');
}

// --- Toggle active ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'toggle') {
    csrf_check();
    $id = (int) ($_POST['id'] ?? 0);
    $db->prepare('UPDATE categories SET is_active = 1 - is_active WHERE id = ?')->execute([$id]);
    mff_audit('category.toggle', 'categories', $id);
    mff_flash('Category status changed.');
    redirect('categories.php');
}

// --- Delete (blocked when products exist) ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'delete') {
    csrf_check();
    $id = (int) ($_POST['id'] ?? 0);
    $st = $db->prepare('SELECT COUNT(*) FROM products WHERE category_id = ?');
    $st->execute([$id]);
    if ((int) $st->fetchColumn() > 0) {
        mff_flash('Cannot delete: products exist in this category. Deactivate it instead.', 'danger');
    } else {
        $c = $db->query('SELECT name FROM categories WHERE id = ' . $id)->fetch();
        $db->prepare('DELETE FROM categories WHERE id = ?')->execute([$id]);
        mff_audit('category.delete', 'categories', $id, $c['name'] ?? '', null);
        mff_flash('Category deleted.');
    }
    redirect('categories.php');
}

$editId = (int) ($_GET['edit'] ?? 0);
$editRow = $editId ? $db->query('SELECT * FROM categories WHERE id = ' . $editId)->fetch() : null;
$cats = $db->query(
    'SELECT c.*, (SELECT COUNT(*) FROM products p WHERE p.category_id = c.id) AS product_count
     FROM categories c ORDER BY c.sort_order, c.name'
)->fetchAll();

ob_start();
?>
<div class="row g-3">
  <div class="col-lg-4">
    <div class="card"><div class="card-header"><?= $editRow ? 'Edit Category' : 'Add Category' ?></div><div class="card-body">
      <form method="post">
        <input type="hidden" name="csrf" value="<?= esc(csrf_token()) ?>">
        <input type="hidden" name="action" value="save">
        <input type="hidden" name="id" value="<?= (int) ($editRow['id'] ?? 0) ?>">
        <div class="mb-2"><label class="form-label required">Name</label>
          <input type="text" name="name" class="form-control" required value="<?= esc($editRow['name'] ?? '') ?>"></div>
        <div class="mb-2"><label class="form-label">Description</label>
          <textarea name="description" class="form-control" rows="2"><?= esc($editRow['description'] ?? '') ?></textarea></div>
        <div class="mb-2"><label class="form-label">Sort order</label>
          <input type="number" name="sort_order" class="form-control" value="<?= (int) ($editRow['sort_order'] ?? 0) ?>"></div>
        <div class="form-check mb-3">
          <input type="checkbox" name="is_active" id="catActive" class="form-check-input" <?= ($editRow['is_active'] ?? 1) ? 'checked' : '' ?>>
          <label class="form-check-label" for="catActive">Active</label>
        </div>
        <button class="btn btn-maroon"><?= $editRow ? 'Save changes' : 'Add category' ?></button>
        <?php if ($editRow): ?><a href="categories.php" class="btn btn-outline-secondary">Cancel</a><?php endif; ?>
      </form>
    </div></div>
  </div>
  <div class="col-lg-8">
    <div class="card"><div class="table-responsive"><table class="table table-sm mb-0">
      <thead><tr><th>#</th><th>Name</th><th>Slug</th><th class="text-end">Products</th><th>Active</th><th></th></tr></thead>
      <tbody>
      <?php foreach ($cats as $c): ?>
        <tr>
          <td><?= (int) $c['sort_order'] ?></td>
          <td><strong><?= esc($c['name']) ?></strong><br><small class="text-muted"><?= esc(mb_substr($c['description'] ?? '', 0, 60)) ?></small></td>
          <td class="small text-muted"><?= esc($c['slug']) ?></td>
          <td class="text-end"><?= (int) $c['product_count'] ?></td>
          <td><?= $c['is_active'] ? '<span class="badge bg-success">Yes</span>' : '<span class="badge bg-secondary">No</span>' ?></td>
          <td class="text-nowrap">
            <a href="categories.php?edit=<?= (int) $c['id'] ?>" class="btn btn-sm btn-outline-secondary">Edit</a>
            <form method="post" class="d-inline">
              <input type="hidden" name="csrf" value="<?= esc(csrf_token()) ?>">
              <input type="hidden" name="action" value="toggle"><input type="hidden" name="id" value="<?= (int) $c['id'] ?>">
              <button class="btn btn-sm btn-outline-warning"><?= $c['is_active'] ? 'Deactivate' : 'Activate' ?></button>
            </form>
            <form method="post" class="d-inline" onsubmit="return confirm('Delete this category?')">
              <input type="hidden" name="csrf" value="<?= esc(csrf_token()) ?>">
              <input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?= (int) $c['id'] ?>">
              <button class="btn btn-sm btn-outline-danger">Delete</button>
            </form>
          </td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table></div></div>
  </div>
</div>
<?php
$content = ob_get_clean();
include __DIR__ . '/_layout.php';
