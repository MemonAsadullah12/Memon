<?php
require_once __DIR__ . '/../includes/auth.php';
require_admin('content.edit');
require_once __DIR__ . '/_helpers.php';
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/helpers.php';

$db = db();
$page_title = 'Content';
$tab = $_GET['tab'] ?? 'pages';
if (!in_array($tab, ['pages', 'faqs', 'banners', 'reviews'], true)) {
    $tab = 'pages';
}

// ---------- PAGES ----------
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['section'] ?? '') === 'pages') {
    csrf_check();
    $action = $_POST['action'] ?? 'save';
    $id = (int) ($_POST['id'] ?? 0);
    if ($action === 'delete' && $id) {
        $db->prepare('DELETE FROM pages WHERE id = ?')->execute([$id]);
        mff_audit('page.delete', 'pages', $id);
        mff_flash('Page deleted.');
    } else {
        $title = trim($_POST['title'] ?? '');
        $slug = mff_unique_slug($db, 'pages', mff_slug(($_POST['slug'] ?? '') ?: $title), $id ?: null);
        $contentHtml = $_POST['content'] ?? '';
        if ($title === '') {
            mff_flash('Title is required.', 'danger');
        } elseif ($id) {
            $db->prepare('UPDATE pages SET slug=?, title=?, content=? WHERE id=?')->execute([$slug, $title, $contentHtml, $id]);
            mff_audit('page.update', 'pages', $id, null, $title);
            mff_flash('Page updated.');
        } else {
            $db->prepare('INSERT INTO pages (slug, title, content) VALUES (?,?,?)')->execute([$slug, $title, $contentHtml]);
            mff_audit('page.create', 'pages', (int) $db->lastInsertId(), null, $title);
            mff_flash('Page added.');
        }
    }
    redirect('content.php?tab=pages');
}

// ---------- FAQS ----------
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['section'] ?? '') === 'faqs') {
    csrf_check();
    $action = $_POST['action'] ?? 'save';
    $id = (int) ($_POST['id'] ?? 0);
    if ($action === 'delete' && $id) {
        $db->prepare('DELETE FROM faqs WHERE id = ?')->execute([$id]);
        mff_audit('faq.delete', 'faqs', $id);
        mff_flash('FAQ deleted.');
    } else {
        $q = trim($_POST['question'] ?? '');
        $a = trim($_POST['answer'] ?? '');
        $sort = (int) ($_POST['sort_order'] ?? 0);
        $active = isset($_POST['is_active']) ? 1 : 0;
        if ($q === '') {
            mff_flash('Question is required.', 'danger');
        } elseif ($id) {
            $db->prepare('UPDATE faqs SET question=?, answer=?, sort_order=?, is_active=? WHERE id=?')->execute([$q, $a, $sort, $active, $id]);
            mff_audit('faq.update', 'faqs', $id);
            mff_flash('FAQ updated.');
        } else {
            $db->prepare('INSERT INTO faqs (question, answer, sort_order, is_active) VALUES (?,?,?,?)')->execute([$q, $a, $sort, $active]);
            mff_audit('faq.create', 'faqs', (int) $db->lastInsertId(), null, $q);
            mff_flash('FAQ added.');
        }
    }
    redirect('content.php?tab=faqs');
}

// ---------- BANNERS ----------
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['section'] ?? '') === 'banners') {
    csrf_check();
    $action = $_POST['action'] ?? 'save';
    $id = (int) ($_POST['id'] ?? 0);
    if ($action === 'delete' && $id) {
        $db->prepare('DELETE FROM banners WHERE id = ?')->execute([$id]);
        mff_audit('banner.delete', 'banners', $id);
        mff_flash('Banner deleted.');
    } else {
        try {
            $title = trim($_POST['title'] ?? '');
            $link = trim($_POST['link_url'] ?? '');
            $sort = (int) ($_POST['sort_order'] ?? 0);
            $active = isset($_POST['is_active']) ? 1 : 0;
            $img = null;
            if (!empty($_FILES['image']['name'])) {
                $img = mff_upload_image($_FILES['image'], 'banners');
            }
            if ($title === '') {
                throw new RuntimeException('Banner title is required.');
            }
            if ($id) {
                $old = $db->query('SELECT image FROM banners WHERE id = ' . $id)->fetch();
                $db->prepare('UPDATE banners SET title=?, image=COALESCE(?,image), link_url=?, sort_order=?, is_active=? WHERE id=?')
                    ->execute([$title, $img, $link ?: null, $sort, $active, $id]);
                if ($img && $old['image']) {
                    @unlink(dirname(__DIR__) . '/' . $old['image']);
                }
                mff_audit('banner.update', 'banners', $id, null, $title);
                mff_flash('Banner updated.');
            } else {
                if (!$img) {
                    throw new RuntimeException('Banner image is required.');
                }
                $db->prepare('INSERT INTO banners (title, image, link_url, sort_order, is_active) VALUES (?,?,?,?,?)')
                    ->execute([$title, $img, $link ?: null, $sort, $active]);
                mff_audit('banner.create', 'banners', (int) $db->lastInsertId(), null, $title);
                mff_flash('Banner added.');
            }
        } catch (Throwable $e) {
            mff_flash($e->getMessage(), 'danger');
        }
    }
    redirect('content.php?tab=banners');
}

// ---------- REVIEWS ----------
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['section'] ?? '') === 'reviews') {
    csrf_check();
    $id = (int) ($_POST['id'] ?? 0);
    $action = $_POST['action'] ?? '';
    if ($id && $action === 'approve') {
        $db->prepare('UPDATE reviews SET is_approved = 1 WHERE id = ?')->execute([$id]);
        mff_audit('review.approve', 'reviews', $id);
        mff_flash('Review approved.');
    } elseif ($id && $action === 'unapprove') {
        $db->prepare('UPDATE reviews SET is_approved = 0 WHERE id = ?')->execute([$id]);
        mff_audit('review.unapprove', 'reviews', $id);
        mff_flash('Review unapproved.');
    } elseif ($id && $action === 'delete') {
        $db->prepare('DELETE FROM reviews WHERE id = ?')->execute([$id]);
        mff_audit('review.delete', 'reviews', $id);
        mff_flash('Review deleted.');
    }
    redirect('content.php?tab=reviews');
}

$pages = $db->query('SELECT * FROM pages ORDER BY title')->fetchAll();
$faqs = $db->query('SELECT * FROM faqs ORDER BY sort_order, id')->fetchAll();
$banners = $db->query('SELECT * FROM banners ORDER BY sort_order, id')->fetchAll();
$reviews = $db->query('SELECT r.*, p.name AS product_name FROM reviews r LEFT JOIN products p ON p.id = r.product_id ORDER BY r.id DESC')->fetchAll();

$ep = (int) ($_GET['edit_page'] ?? 0);
$editPage = $ep ? $db->query('SELECT * FROM pages WHERE id = ' . $ep)->fetch() : null;
$ef = (int) ($_GET['edit_faq'] ?? 0);
$editFaq = $ef ? $db->query('SELECT * FROM faqs WHERE id = ' . $ef)->fetch() : null;
$eb = (int) ($_GET['edit_banner'] ?? 0);
$editBanner = $eb ? $db->query('SELECT * FROM banners WHERE id = ' . $eb)->fetch() : null;

$page_actions = '<div class="btn-group btn-group-sm">'
    . '<a href="content.php?tab=pages" class="btn ' . ($tab === 'pages' ? 'btn-maroon' : 'btn-outline-secondary') . '">Pages</a>'
    . '<a href="content.php?tab=faqs" class="btn ' . ($tab === 'faqs' ? 'btn-maroon' : 'btn-outline-secondary') . '">FAQs</a>'
    . '<a href="content.php?tab=banners" class="btn ' . ($tab === 'banners' ? 'btn-maroon' : 'btn-outline-secondary') . '">Banners</a>'
    . '<a href="content.php?tab=reviews" class="btn ' . ($tab === 'reviews' ? 'btn-maroon' : 'btn-outline-secondary') . '">Reviews</a>'
    . '</div>';

ob_start();
?>

<?php if ($tab === 'pages'): ?>
<div class="row g-3">
  <div class="col-lg-5"><div class="card"><div class="card-header"><?= $editPage ? 'Edit Page' : 'Add Page' ?></div><div class="card-body">
    <form method="post">
      <input type="hidden" name="csrf" value="<?= esc(csrf_token()) ?>"><input type="hidden" name="section" value="pages">
      <input type="hidden" name="id" value="<?= (int) ($editPage['id'] ?? 0) ?>">
      <div class="mb-2"><label class="form-label required">Title</label><input type="text" name="title" class="form-control" required value="<?= esc($editPage['title'] ?? '') ?>"></div>
      <div class="mb-2"><label class="form-label">Slug</label><input type="text" name="slug" class="form-control" placeholder="Auto from title" value="<?= esc($editPage['slug'] ?? '') ?>"></div>
      <div class="mb-2"><label class="form-label">Content (HTML allowed)</label><textarea name="content" class="form-control" rows="8"><?= esc($editPage['content'] ?? '') ?></textarea></div>
      <button class="btn btn-maroon"><?= $editPage ? 'Save' : 'Add page' ?></button>
      <?php if ($editPage): ?><a href="content.php?tab=pages" class="btn btn-outline-secondary">Cancel</a><?php endif; ?>
    </form>
  </div></div></div>
  <div class="col-lg-7"><div class="card"><div class="table-responsive"><table class="table table-sm mb-0">
    <thead><tr><th>Title</th><th>Slug</th><th></th></tr></thead><tbody>
    <?php foreach ($pages as $pg): ?><tr>
      <td><?= esc($pg['title']) ?></td><td class="small text-muted"><?= esc($pg['slug']) ?></td>
      <td class="text-nowrap"><a href="content.php?tab=pages&edit_page=<?= (int) $pg['id'] ?>" class="btn btn-sm btn-outline-secondary">Edit</a>
      <form method="post" class="d-inline" onsubmit="return confirm('Delete this page?')">
        <input type="hidden" name="csrf" value="<?= esc(csrf_token()) ?>"><input type="hidden" name="section" value="pages">
        <input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?= (int) $pg['id'] ?>">
        <button class="btn btn-sm btn-outline-danger">Delete</button></form></td>
    </tr><?php endforeach; ?>
    </tbody></table></div></div></div>
</div>
<?php endif; ?>

<?php if ($tab === 'faqs'): ?>
<div class="row g-3">
  <div class="col-lg-5"><div class="card"><div class="card-header"><?= $editFaq ? 'Edit FAQ' : 'Add FAQ' ?></div><div class="card-body">
    <form method="post">
      <input type="hidden" name="csrf" value="<?= esc(csrf_token()) ?>"><input type="hidden" name="section" value="faqs">
      <input type="hidden" name="id" value="<?= (int) ($editFaq['id'] ?? 0) ?>">
      <div class="mb-2"><label class="form-label required">Question</label><input type="text" name="question" class="form-control" required value="<?= esc($editFaq['question'] ?? '') ?>"></div>
      <div class="mb-2"><label class="form-label">Answer</label><textarea name="answer" class="form-control" rows="4"><?= esc($editFaq['answer'] ?? '') ?></textarea></div>
      <div class="mb-2"><label class="form-label">Sort order</label><input type="number" name="sort_order" class="form-control" value="<?= (int) ($editFaq['sort_order'] ?? 0) ?>"></div>
      <div class="form-check mb-2"><input type="checkbox" name="is_active" class="form-check-input" id="faqA" <?= ($editFaq['is_active'] ?? 1) ? 'checked' : '' ?>><label class="form-check-label" for="faqA">Active</label></div>
      <button class="btn btn-maroon"><?= $editFaq ? 'Save' : 'Add FAQ' ?></button>
      <?php if ($editFaq): ?><a href="content.php?tab=faqs" class="btn btn-outline-secondary">Cancel</a><?php endif; ?>
    </form>
  </div></div></div>
  <div class="col-lg-7"><div class="card"><div class="table-responsive"><table class="table table-sm mb-0">
    <thead><tr><th>#</th><th>Question</th><th>Active</th><th></th></tr></thead><tbody>
    <?php foreach ($faqs as $fq): ?><tr>
      <td><?= (int) $fq['sort_order'] ?></td><td><?= esc($fq['question']) ?><br><small class="text-muted"><?= esc(mb_substr($fq['answer'] ?? '', 0, 80)) ?></small></td>
      <td><?= $fq['is_active'] ? '<span class="badge bg-success">Yes</span>' : '<span class="badge bg-secondary">No</span>' ?></td>
      <td class="text-nowrap"><a href="content.php?tab=faqs&edit_faq=<?= (int) $fq['id'] ?>" class="btn btn-sm btn-outline-secondary">Edit</a>
      <form method="post" class="d-inline" onsubmit="return confirm('Delete this FAQ?')">
        <input type="hidden" name="csrf" value="<?= esc(csrf_token()) ?>"><input type="hidden" name="section" value="faqs">
        <input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?= (int) $fq['id'] ?>">
        <button class="btn btn-sm btn-outline-danger">Delete</button></form></td>
    </tr><?php endforeach; ?>
    </tbody></table></div></div></div>
</div>
<?php endif; ?>

<?php if ($tab === 'banners'): ?>
<div class="row g-3">
  <div class="col-lg-4"><div class="card"><div class="card-header"><?= $editBanner ? 'Edit Banner' : 'Add Banner' ?></div><div class="card-body">
    <form method="post" enctype="multipart/form-data">
      <input type="hidden" name="csrf" value="<?= esc(csrf_token()) ?>"><input type="hidden" name="section" value="banners">
      <input type="hidden" name="id" value="<?= (int) ($editBanner['id'] ?? 0) ?>">
      <?php if (!empty($editBanner['image'])): ?><img src="../<?= esc($editBanner['image']) ?>" class="img-fluid rounded mb-2"><?php endif; ?>
      <div class="mb-2"><label class="form-label required">Title</label><input type="text" name="title" class="form-control" required value="<?= esc($editBanner['title'] ?? '') ?>"></div>
      <div class="mb-2"><label class="form-label">Image (JPG/PNG/WebP ≤2MB)</label><input type="file" name="image" class="form-control" accept=".jpg,.jpeg,.png,.webp"></div>
      <div class="mb-2"><label class="form-label">Link URL</label><input type="text" name="link_url" class="form-control" value="<?= esc($editBanner['link_url'] ?? '') ?>"></div>
      <div class="mb-2"><label class="form-label">Sort order</label><input type="number" name="sort_order" class="form-control" value="<?= (int) ($editBanner['sort_order'] ?? 0) ?>"></div>
      <div class="form-check mb-2"><input type="checkbox" name="is_active" class="form-check-input" id="banA" <?= ($editBanner['is_active'] ?? 1) ? 'checked' : '' ?>><label class="form-check-label" for="banA">Active</label></div>
      <button class="btn btn-maroon"><?= $editBanner ? 'Save' : 'Add banner' ?></button>
      <?php if ($editBanner): ?><a href="content.php?tab=banners" class="btn btn-outline-secondary">Cancel</a><?php endif; ?>
    </form>
  </div></div></div>
  <div class="col-lg-8"><div class="card"><div class="table-responsive"><table class="table table-sm mb-0">
    <thead><tr><th></th><th>Title</th><th>Link</th><th>#</th><th>Active</th><th></th></tr></thead><tbody>
    <?php foreach ($banners as $b): ?><tr>
      <td><?php if ($b['image']): ?><img class="thumb" src="../<?= esc($b['image']) ?>"><?php endif; ?></td>
      <td><?= esc($b['title']) ?></td><td class="small"><?= esc($b['link_url'] ?? '—') ?></td>
      <td><?= (int) $b['sort_order'] ?></td>
      <td><?= $b['is_active'] ? '<span class="badge bg-success">Yes</span>' : '<span class="badge bg-secondary">No</span>' ?></td>
      <td class="text-nowrap"><a href="content.php?tab=banners&edit_banner=<?= (int) $b['id'] ?>" class="btn btn-sm btn-outline-secondary">Edit</a>
      <form method="post" class="d-inline" onsubmit="return confirm('Delete this banner?')">
        <input type="hidden" name="csrf" value="<?= esc(csrf_token()) ?>"><input type="hidden" name="section" value="banners">
        <input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?= (int) $b['id'] ?>">
        <button class="btn btn-sm btn-outline-danger">Delete</button></form></td>
    </tr><?php endforeach; ?>
    </tbody></table></div></div></div>
</div>
<?php endif; ?>

<?php if ($tab === 'reviews'): ?>
<div class="card"><div class="table-responsive"><table class="table table-sm mb-0">
  <thead><tr><th>Product</th><th>Customer</th><th>Rating</th><th>Review</th><th>Status</th><th></th></tr></thead><tbody>
  <?php if (!$reviews): ?><tr><td colspan="6" class="text-center text-muted py-3">No reviews yet.</td></tr><?php endif; ?>
  <?php foreach ($reviews as $rv): ?><tr>
    <td><?= esc($rv['product_name'] ?? '—') ?></td>
    <td><?= esc($rv['customer_name']) ?></td>
    <td><?= str_repeat('⭐', (int) $rv['rating']) ?></td>
    <td class="small"><?= esc($rv['review_text']) ?></td>
    <td><?= $rv['is_approved'] ? '<span class="badge bg-success">Approved</span>' : '<span class="badge bg-warning text-dark">Pending</span>' ?></td>
    <td class="text-nowrap">
      <form method="post" class="d-inline">
        <input type="hidden" name="csrf" value="<?= esc(csrf_token()) ?>"><input type="hidden" name="section" value="reviews">
        <input type="hidden" name="id" value="<?= (int) $rv['id'] ?>">
        <?php if ($rv['is_approved']): ?>
          <button name="action" value="unapprove" class="btn btn-sm btn-outline-warning">Unapprove</button>
        <?php else: ?>
          <button name="action" value="approve" class="btn btn-sm btn-outline-success">Approve</button>
        <?php endif; ?>
        <button name="action" value="delete" class="btn btn-sm btn-outline-danger" onclick="return confirm('Delete this review?')">Delete</button>
      </form>
    </td>
  </tr><?php endforeach; ?>
  </tbody></table></div></div>
<?php endif; ?>

<?php
$content = ob_get_clean();
include __DIR__ . '/_layout.php';
