<?php
require_once __DIR__ . '/../includes/auth.php';
require_admin('coupons.manage');
require_once __DIR__ . '/_helpers.php';
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/helpers.php';

$db = db();
$page_title = 'Coupons';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'save') {
    csrf_check();
    $id = (int) ($_POST['id'] ?? 0);
    $code = strtoupper(trim($_POST['code'] ?? ''));
    $dtype = $_POST['discount_type'] ?? 'percent';
    $dval = (float) ($_POST['discount_value'] ?? 0);
    $min = max(0, (int) ($_POST['min_order'] ?? 0));
    $maxd = ($_POST['max_discount'] ?? '') === '' ? null : max(0, (int) $_POST['max_discount']);
    $starts = ($_POST['starts_at'] ?? '') ?: null;
    $ends = ($_POST['ends_at'] ?? '') ?: null;
    $ulimit = ($_POST['usage_limit'] ?? '') === '' ? null : max(1, (int) $_POST['usage_limit']);
    $plimit = ($_POST['per_customer_limit'] ?? '') === '' ? null : max(1, (int) $_POST['per_customer_limit']);
    $active = isset($_POST['is_active']) ? 1 : 0;
    $pids = array_map('intval', $_POST['product_ids'] ?? []);
    $cids = array_map('intval', $_POST['category_ids'] ?? []);
    try {
        if ($code === '' || !in_array($dtype, ['percent', 'fixed'], true) || $dval <= 0) {
            throw new RuntimeException('Code, valid type and a positive discount value are required.');
        }
        $st = $db->prepare('SELECT id FROM coupons WHERE code = ?' . ($id ? ' AND id <> ' . $id : '') . ' LIMIT 1');
        $st->execute([$code]);
        if ($st->fetch()) {
            throw new RuntimeException('Coupon code already exists.');
        }
        $db->beginTransaction();
        if ($id > 0) {
            $db->prepare(
                'UPDATE coupons SET code=?, discount_type=?, discount_value=?, min_order=?, max_discount=?, starts_at=?, ends_at=?, usage_limit=?, per_customer_limit=?, is_active=? WHERE id=?'
            )->execute([$code, $dtype, $dval, $min, $maxd, $starts, $ends, $ulimit, $plimit, $active, $id]);
            $db->prepare('DELETE FROM coupon_products WHERE coupon_id = ?')->execute([$id]);
            $db->prepare('DELETE FROM coupon_categories WHERE coupon_id = ?')->execute([$id]);
            mff_audit('coupon.update', 'coupons', $id, null, $code);
            $cid = $id;
            mff_flash('Coupon updated.');
        } else {
            $db->prepare(
                'INSERT INTO coupons (code, discount_type, discount_value, min_order, max_discount, starts_at, ends_at, usage_limit, per_customer_limit, is_active)
                 VALUES (?,?,?,?,?,?,?,?,?,?)'
            )->execute([$code, $dtype, $dval, $min, $maxd, $starts, $ends, $ulimit, $plimit, $active]);
            $cid = (int) $db->lastInsertId();
            mff_audit('coupon.create', 'coupons', $cid, null, $code);
            mff_flash('Coupon added.');
        }
        $ip = $db->prepare('INSERT INTO coupon_products (coupon_id, product_id) VALUES (?,?)');
        foreach ($pids as $x) {
            if ($x > 0) {
                $ip->execute([$cid, $x]);
            }
        }
        $ic = $db->prepare('INSERT INTO coupon_categories (coupon_id, category_id) VALUES (?,?)');
        foreach ($cids as $x) {
            if ($x > 0) {
                $ic->execute([$cid, $x]);
            }
        }
        $db->commit();
    } catch (Throwable $e) {
        if ($db->inTransaction()) {
            $db->rollBack();
        }
        mff_flash($e->getMessage(), 'danger');
    }
    redirect('coupons.php');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'delete') {
    csrf_check();
    $id = (int) ($_POST['id'] ?? 0);
    $st = $db->prepare('SELECT COUNT(*) FROM coupon_redemptions WHERE coupon_id = ?');
    $st->execute([$id]);
    if ((int) $st->fetchColumn() > 0) {
        mff_flash('Cannot delete: this coupon has redemptions. Deactivate it instead.', 'danger');
    } else {
        $db->prepare('DELETE FROM coupons WHERE id = ?')->execute([$id]);
        mff_audit('coupon.delete', 'coupons', $id);
        mff_flash('Coupon deleted.');
    }
    redirect('coupons.php');
}

$editId = (int) ($_GET['edit'] ?? 0);
$editRow = $editId ? $db->query('SELECT * FROM coupons WHERE id = ' . $editId)->fetch() : null;
$editPids = $editId ? $db->query('SELECT product_id FROM coupon_products WHERE coupon_id = ' . $editId)->fetchAll(PDO::FETCH_COLUMN) : [];
$editCids = $editId ? $db->query('SELECT category_id FROM coupon_categories WHERE coupon_id = ' . $editId)->fetchAll(PDO::FETCH_COLUMN) : [];

$viewId = (int) ($_GET['redemptions'] ?? 0);
$redemptions = [];
$redCoupon = null;
if ($viewId > 0) {
    $redCoupon = $db->query('SELECT code FROM coupons WHERE id = ' . $viewId)->fetch();
    $st = $db->prepare(
        'SELECT r.*, o.order_number FROM coupon_redemptions r LEFT JOIN orders o ON o.id = r.order_id
         WHERE r.coupon_id = ? ORDER BY r.id DESC'
    );
    $st->execute([$viewId]);
    $redemptions = $st->fetchAll();
}

$coupons = $db->query(
    'SELECT c.*, (SELECT COUNT(*) FROM coupon_redemptions WHERE coupon_id = c.id) AS used_count
     FROM coupons c ORDER BY c.id DESC'
)->fetchAll();
$products = $db->query('SELECT id, name FROM products WHERE is_active = 1 ORDER BY name')->fetchAll();
$categories = $db->query('SELECT id, name FROM categories WHERE is_active = 1 ORDER BY name')->fetchAll();

ob_start();
?>
<?php if ($redCoupon): ?>
<div class="card mb-3"><div class="card-header d-flex justify-content-between">
  <span>Redemptions for <strong><?= esc($redCoupon['code']) ?></strong> (<?= count($redemptions) ?>)</span>
  <a href="coupons.php" class="btn btn-sm btn-outline-secondary">Back</a>
</div><div class="table-responsive"><table class="table table-sm mb-0">
  <thead><tr><th>Order</th><th>Customer phone</th><th class="text-end">Discount</th></tr></thead>
  <tbody>
  <?php if (!$redemptions): ?><tr><td colspan="3" class="text-center text-muted py-3">No redemptions yet.</td></tr><?php endif; ?>
  <?php foreach ($redemptions as $r): ?>
    <tr><td><?= $r['order_id'] ? '<a href="order-view.php?id=' . (int) $r['order_id'] . '">' . esc($r['order_number']) . '</a>' : '—' ?></td>
    <td><?= esc($r['customer_phone'] ?? '—') ?></td><td class="text-end"><?= esc(rs((int) $r['discount_amount'])) ?></td></tr>
  <?php endforeach; ?>
  </tbody>
</table></div></div>
<?php endif; ?>

<div class="row g-3">
  <div class="col-lg-4">
    <div class="card"><div class="card-header"><?= $editRow ? 'Edit Coupon' : 'Add Coupon' ?></div><div class="card-body">
      <form method="post">
        <input type="hidden" name="csrf" value="<?= esc(csrf_token()) ?>">
        <input type="hidden" name="action" value="save">
        <input type="hidden" name="id" value="<?= (int) ($editRow['id'] ?? 0) ?>">
        <div class="row g-2">
          <div class="col-6"><label class="form-label required">Code</label>
            <input type="text" name="code" class="form-control text-uppercase" required value="<?= esc($editRow['code'] ?? '') ?>"></div>
          <div class="col-6"><label class="form-label required">Type</label>
            <select name="discount_type" class="form-select">
              <option value="percent" <?= ($editRow['discount_type'] ?? '') === 'percent' ? 'selected' : '' ?>>Percent %</option>
              <option value="fixed" <?= ($editRow['discount_type'] ?? '') === 'fixed' ? 'selected' : '' ?>>Fixed Rs</option>
            </select></div>
          <div class="col-6"><label class="form-label required">Value</label>
            <input type="number" name="discount_value" class="form-control" min="0" step="0.01" required value="<?= esc($editRow['discount_value'] ?? '') ?>"></div>
          <div class="col-6"><label class="form-label">Min order (Rs)</label>
            <input type="number" name="min_order" class="form-control" min="0" value="<?= (int) ($editRow['min_order'] ?? 0) ?>"></div>
          <div class="col-6"><label class="form-label">Max discount (Rs)</label>
            <input type="number" name="max_discount" class="form-control" min="0" value="<?= esc($editRow['max_discount'] ?? '') ?>"></div>
          <div class="col-6"><label class="form-label">Usage limit (total)</label>
            <input type="number" name="usage_limit" class="form-control" min="1" value="<?= esc($editRow['usage_limit'] ?? '') ?>"></div>
          <div class="col-6"><label class="form-label">Per-customer limit</label>
            <input type="number" name="per_customer_limit" class="form-control" min="1" value="<?= esc($editRow['per_customer_limit'] ?? '') ?>"></div>
          <div class="col-6"><label class="form-label">Starts at</label>
            <input type="datetime-local" name="starts_at" class="form-control" value="<?= esc($editRow['starts_at'] ? date('Y-m-d\TH:i', strtotime($editRow['starts_at'])) : '') ?>"></div>
          <div class="col-6"><label class="form-label">Ends at</label>
            <input type="datetime-local" name="ends_at" class="form-control" value="<?= esc($editRow['ends_at'] ? date('Y-m-d\TH:i', strtotime($editRow['ends_at'])) : '') ?>"></div>
          <div class="col-12"><label class="form-label">Restrict to products (blank = all)</label>
            <select name="product_ids[]" class="form-select" multiple size="4">
              <?php foreach ($products as $pr): ?><option value="<?= (int) $pr['id'] ?>" <?= in_array($pr['id'], $editPids, true) ? 'selected' : '' ?>><?= esc($pr['name']) ?></option><?php endforeach; ?>
            </select></div>
          <div class="col-12"><label class="form-label">Restrict to categories (blank = all)</label>
            <select name="category_ids[]" class="form-select" multiple size="4">
              <?php foreach ($categories as $ct): ?><option value="<?= (int) $ct['id'] ?>" <?= in_array($ct['id'], $editCids, true) ? 'selected' : '' ?>><?= esc($ct['name']) ?></option><?php endforeach; ?>
            </select></div>
        </div>
        <div class="form-check my-2"><input type="checkbox" name="is_active" id="cActive" class="form-check-input" <?= ($editRow['is_active'] ?? 1) ? 'checked' : '' ?>>
          <label class="form-check-label" for="cActive">Active</label></div>
        <button class="btn btn-maroon"><?= $editRow ? 'Save changes' : 'Add coupon' ?></button>
        <?php if ($editRow): ?><a href="coupons.php" class="btn btn-outline-secondary">Cancel</a><?php endif; ?>
      </form>
    </div></div>
  </div>
  <div class="col-lg-8">
    <div class="card"><div class="table-responsive"><table class="table table-sm mb-0">
      <thead><tr><th>Code</th><th>Discount</th><th class="text-end">Min</th><th>Validity</th><th class="text-end">Used</th><th>Active</th><th></th></tr></thead>
      <tbody>
      <?php foreach ($coupons as $cp): ?>
        <tr>
          <td><strong><?= esc($cp['code']) ?></strong></td>
          <td><?= $cp['discount_type'] === 'percent' ? esc(rtrim(rtrim($cp['discount_value'], '0'), '.')) . '%' : esc(rs((int) $cp['discount_value'])) ?></td>
          <td class="text-end"><?= esc(rs((int) $cp['min_order'])) ?></td>
          <td class="small"><?= $cp['starts_at'] ? date('d M y', strtotime($cp['starts_at'])) : '…' ?> → <?= $cp['ends_at'] ? date('d M y', strtotime($cp['ends_at'])) : '…' ?></td>
          <td class="text-end"><?= (int) $cp['used_count'] ?><?= $cp['usage_limit'] ? ' / ' . (int) $cp['usage_limit'] : '' ?></td>
          <td><?= $cp['is_active'] ? '<span class="badge bg-success">Yes</span>' : '<span class="badge bg-secondary">No</span>' ?></td>
          <td class="text-nowrap">
            <a href="coupons.php?redemptions=<?= (int) $cp['id'] ?>" class="btn btn-sm btn-outline-info">Redemptions</a>
            <a href="coupons.php?edit=<?= (int) $cp['id'] ?>" class="btn btn-sm btn-outline-secondary">Edit</a>
            <form method="post" class="d-inline" onsubmit="return confirm('Delete this coupon?')">
              <input type="hidden" name="csrf" value="<?= esc(csrf_token()) ?>">
              <input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?= (int) $cp['id'] ?>">
              <button class="btn btn-sm btn-outline-danger">Delete</button>
            </form>
          </td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table></div></div>
  </div>
</div>
<?php
$content = ob_get_clean();
include __DIR__ . '/_layout.php';
