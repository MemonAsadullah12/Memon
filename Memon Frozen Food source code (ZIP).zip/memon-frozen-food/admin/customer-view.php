<?php
require_once __DIR__ . '/../includes/auth.php';
require_admin('customers.view');
require_once __DIR__ . '/_helpers.php';
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/helpers.php';

$db = db();
$id = (int) ($_GET['id'] ?? 0);
$canEdit = has_perm('customers.edit');

$st = $db->prepare('SELECT * FROM customers WHERE id = ?');
$st->execute([$id]);
$c = $st->fetch();
if (!$c) {
    mff_flash('Customer not found.', 'danger');
    redirect('customers.php');
}
$page_title = $c['name'];

// --- Save internal notes ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'notes' && $canEdit) {
    csrf_check();
    $notes = trim($_POST['notes'] ?? '');
    $db->prepare('UPDATE customers SET notes = ? WHERE id = ?')->execute([$notes, $id]);
    mff_audit('customer.notes', 'customers', $id, mb_substr($c['notes'] ?? '', 0, 100), mb_substr($notes, 0, 100));
    mff_flash('Notes saved.');
    redirect('customer-view.php?id=' . $id);
}

// --- Block / unblock ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'toggle' && $canEdit) {
    csrf_check();
    $db->prepare('UPDATE customers SET is_active = 1 - is_active WHERE id = ?')->execute([$id]);
    mff_audit('customer.toggle', 'customers', $id, ['is_active' => (int) $c['is_active']], ['is_active' => 1 - (int) $c['is_active']]);
    mff_flash($c['is_active'] ? 'Customer blocked.' : 'Customer unblocked.', $c['is_active'] ? 'warning' : 'success');
    redirect('customer-view.php?id=' . $id);
}

$addr = $db->prepare('SELECT * FROM customer_addresses WHERE customer_id = ? ORDER BY is_default DESC, id');
$addr->execute([$id]);
$addresses = $addr->fetchAll();

$ost = $db->prepare(
    'SELECT id, order_number, total_amount, order_status, payment_status, created_at,
            (SELECT COUNT(*) FROM order_items WHERE order_id = orders.id) AS items
     FROM orders WHERE customer_id = ? OR customer_phone = ? ORDER BY id DESC'
);
$ost->execute([$id, $c['phone']]);
$orders = $ost->fetchAll();
$spent = 0;
foreach ($orders as $oo) {
    if (!in_array($oo['order_status'], ['cancelled', 'returned'], true)) {
        $spent += (int) $oo['total_amount'];
    }
}

ob_start();
?>
<div class="row g-3">
  <div class="col-lg-4">
    <div class="card mb-3"><div class="card-header d-flex justify-content-between align-items-center">
      <span>Profile</span><?= $c['is_active'] ? '<span class="badge bg-success">Active</span>' : '<span class="badge bg-danger">Blocked</span>' ?>
    </div><div class="card-body">
      <h5><?= esc($c['name']) ?></h5>
      <p class="mb-1">📞 <?= esc($c['phone']) ?></p>
      <?php if ($c['whatsapp_number']): ?><p class="mb-1">💬 <?= esc($c['whatsapp_number']) ?></p><?php endif; ?>
      <?php if ($c['email']): ?><p class="mb-1">✉️ <?= esc($c['email']) ?></p><?php endif; ?>
      <hr>
      <p class="mb-1"><strong><?= count($orders) ?></strong> orders · <strong><?= esc(rs($spent)) ?></strong> total spent</p>
      <?php if ($canEdit): ?>
        <form method="post" class="d-inline" onsubmit="return confirm('<?= $c['is_active'] ? 'Block' : 'Unblock' ?> this customer?')">
          <input type="hidden" name="csrf" value="<?= esc(csrf_token()) ?>">
          <input type="hidden" name="action" value="toggle">
          <button class="btn btn-sm <?= $c['is_active'] ? 'btn-outline-danger' : 'btn-outline-success' ?>"><?= $c['is_active'] ? 'Block customer' : 'Unblock customer' ?></button>
        </form>
      <?php endif; ?>
    </div></div>

    <div class="card mb-3"><div class="card-header">Saved addresses</div>
      <ul class="list-group list-group-flush small">
        <?php if (!$addresses): ?><li class="list-group-item text-muted">No saved addresses.</li><?php endif; ?>
        <?php foreach ($addresses as $a): ?>
          <li class="list-group-item"><strong><?= esc($a['label'] ?? 'Address') ?></strong>
            <?= $a['is_default'] ? '<span class="badge bg-gold text-dark">default</span>' : '' ?><br>
            <?= esc($a['address']) ?><br><?= esc($a['area']) ?>, <?= esc($a['city']) ?>
            <?= $a['landmark'] ? '<br>Landmark: ' . esc($a['landmark']) : '' ?></li>
        <?php endforeach; ?>
      </ul>
    </div>

    <div class="card"><div class="card-header">Internal notes <?= $canEdit ? '' : '<small class="text-muted">(read-only)</small>' ?></div><div class="card-body">
      <?php if ($canEdit): ?>
      <form method="post">
        <input type="hidden" name="csrf" value="<?= esc(csrf_token()) ?>">
        <input type="hidden" name="action" value="notes">
        <textarea name="notes" class="form-control form-control-sm" rows="3"><?= esc($c['notes'] ?? '') ?></textarea>
        <button class="btn btn-sm btn-maroon mt-2">Save notes</button>
      </form>
      <?php else: ?>
        <p class="small mb-0"><?= esc($c['notes'] ?: '—') ?></p>
      <?php endif; ?>
    </div></div>
  </div>

  <div class="col-lg-8">
    <div class="card"><div class="card-header">Order history (<?= count($orders) ?>)</div>
    <div class="table-responsive"><table class="table table-sm mb-0">
      <thead><tr><th>Order</th><th>Date</th><th class="text-end">Items</th><th class="text-end">Total</th><th>Payment</th><th>Status</th><th></th></tr></thead>
      <tbody>
      <?php if (!$orders): ?><tr><td colspan="7" class="text-center text-muted py-3">No orders yet.</td></tr><?php endif; ?>
      <?php foreach ($orders as $oo): ?>
        <tr>
          <td><strong><?= esc($oo['order_number']) ?></strong></td>
          <td class="small"><?= esc(mff_date($oo['created_at'])) ?></td>
          <td class="text-end"><?= (int) $oo['items'] ?></td>
          <td class="text-end"><?= esc(rs((int) $oo['total_amount'])) ?></td>
          <td><?= mff_payment_badge($oo['payment_status']) ?></td>
          <td><?= mff_status_badge($oo['order_status']) ?></td>
          <td><a href="order-view.php?id=<?= (int) $oo['id'] ?>" class="btn btn-sm btn-outline-secondary">View</a></td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table></div></div>
  </div>
</div>
<?php
$content = ob_get_clean();
include __DIR__ . '/_layout.php';
