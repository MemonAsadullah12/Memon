<?php
require_once __DIR__ . '/../includes/auth.php';
require_admin('customers.view');
require_once __DIR__ . '/_helpers.php';
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/helpers.php';

$db = db();
$page_title = 'Customers';

// --- CSV export ---
if (isset($_GET['export']) && $_GET['export'] === 'csv') {
    require_admin('customers.export');
    $rows = $db->query(
        "SELECT c.id, c.name, c.phone, c.whatsapp_number, c.email, c.is_active,
                (SELECT COUNT(*) FROM orders o WHERE o.customer_id = c.id OR o.customer_phone = c.phone) AS orders,
                (SELECT COALESCE(SUM(total_amount),0) FROM orders o WHERE (o.customer_id = c.id OR o.customer_phone = c.phone) AND o.order_status NOT IN ('cancelled','returned')) AS spent
         FROM customers c ORDER BY c.name"
    )->fetchAll();
    mff_csv_download('customers-' . date('Ymd') . '.csv',
        ['ID', 'Name', 'Phone', 'WhatsApp', 'Email', 'Active', 'Orders', 'Total spent (Rs)'],
        array_map(fn($r) => [$r['id'], $r['name'], $r['phone'], $r['whatsapp_number'], $r['email'], $r['is_active'], $r['orders'], $r['spent']], $rows));
}

$q = trim($_GET['q'] ?? '');
$where = '';
$params = [];
if ($q !== '') {
    $where = 'WHERE (c.name LIKE ? OR c.phone LIKE ? OR c.email LIKE ?)';
    $params = ["%$q%", "%$q%", "%$q%"];
}

$st = $db->prepare("SELECT COUNT(*) FROM customers c $where");
$st->execute($params);
$total = (int) $st->fetchColumn();
$page = max(1, (int) ($_GET['page'] ?? 1));
$per = 20;
$offset = ($page - 1) * $per;

$st = $db->prepare(
    "SELECT c.*,
            (SELECT COUNT(*) FROM orders o WHERE o.customer_id = c.id OR o.customer_phone = c.phone) AS orders_count,
            (SELECT COALESCE(SUM(total_amount),0) FROM orders o WHERE (o.customer_id = c.id OR o.customer_phone = c.phone) AND o.order_status NOT IN ('cancelled','returned')) AS total_spent,
            (SELECT MAX(created_at) FROM orders o WHERE o.customer_id = c.id OR o.customer_phone = c.phone) AS last_order
     FROM customers c $where ORDER BY c.id DESC LIMIT $per OFFSET $offset"
);
$st->execute($params);
$rows = $st->fetchAll();

if (has_perm('customers.export')) {
    $page_actions = '<a href="customers.php?export=csv&q=' . urlencode($q) . '" class="btn btn-sm btn-outline-secondary">Export CSV</a>';
}

ob_start();
?>
<div class="card mb-3"><div class="card-body">
  <form method="get" class="row g-2">
    <div class="col-md-10"><input type="text" name="q" class="form-control form-control-sm" placeholder="Search name, phone or email…" value="<?= esc($q) ?>"></div>
    <div class="col-md-2"><button class="btn btn-sm btn-maroon w-100">Search</button></div>
  </form>
</div></div>

<div class="card"><div class="table-responsive"><table class="table table-sm table-hover mb-0">
  <thead><tr><th>Customer</th><th>Phone</th><th class="text-end">Orders</th><th class="text-end">Total spent</th><th>Last order</th><th>Status</th><th></th></tr></thead>
  <tbody>
  <?php if (!$rows): ?><tr><td colspan="7" class="text-center text-muted py-4">No customers found.</td></tr><?php endif; ?>
  <?php foreach ($rows as $c): ?>
    <tr>
      <td><strong><?= esc($c['name']) ?></strong><br><small class="text-muted"><?= esc($c['email'] ?? '') ?></small></td>
      <td><?= esc($c['phone']) ?><?= $c['whatsapp_number'] ? '<br><small class="text-muted">WA: ' . esc($c['whatsapp_number']) . '</small>' : '' ?></td>
      <td class="text-end"><?= (int) $c['orders_count'] ?></td>
      <td class="text-end"><?= esc(rs((int) $c['total_spent'])) ?></td>
      <td class="small"><?= $c['last_order'] ? esc(mff_date($c['last_order'])) : '—' ?></td>
      <td><?= $c['is_active'] ? '<span class="badge bg-success">Active</span>' : '<span class="badge bg-danger">Blocked</span>' ?></td>
      <td><a href="customer-view.php?id=<?= (int) $c['id'] ?>" class="btn btn-sm btn-outline-secondary">View</a></td>
    </tr>
  <?php endforeach; ?>
  </tbody>
</table></div></div>
<div class="mt-2"><?= mff_pagination($total, $page, $per, 'customers.php', ['q' => $q]) ?></div>
<?php
$content = ob_get_clean();
include __DIR__ . '/_layout.php';
