<?php
require_once __DIR__ . '/../includes/auth.php';
require_admin('deliveries.view');
require_once __DIR__ . '/_helpers.php';
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/helpers.php';

$db = db();
$page_title = 'Delivery Assignments';
$canEdit = has_perm('deliveries.edit');

// --- Assign staff to an order ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'assign' && $canEdit) {
    csrf_check();
    $orderId = (int) ($_POST['order_id'] ?? 0);
    $staff = trim($_POST['staff_name'] ?? '');
    $sphone = trim($_POST['staff_phone'] ?? '');
    $notes = trim($_POST['notes'] ?? '');
    try {
        if ($orderId <= 0 || $staff === '') {
            throw new RuntimeException('Order and staff name are required.');
        }
        $o = $db->query('SELECT id, order_status FROM orders WHERE id = ' . $orderId)->fetch();
        if (!$o || !in_array($o['order_status'], ['ready', 'out_for_delivery'], true)) {
            throw new RuntimeException('Only orders that are Ready or Out for Delivery can be assigned.');
        }
        $st = $db->prepare('SELECT id FROM delivery_assignments WHERE order_id = ? LIMIT 1');
        $st->execute([$orderId]);
        if ($st->fetch()) {
            throw new RuntimeException('This order already has a delivery assignment.');
        }
        $db->prepare(
            "INSERT INTO delivery_assignments (order_id, staff_name, staff_phone, status, assigned_at, notes)
             VALUES (?, ?, ?, 'assigned', NOW(), ?)"
        )->execute([$orderId, $staff, $sphone, $notes]);
        mff_audit('delivery.assign', 'delivery_assignments', (int) $db->lastInsertId(), null, ['order_id' => $orderId, 'staff' => $staff]);
        mff_flash('Delivery assigned to ' . $staff . '.');
    } catch (Throwable $e) {
        mff_flash($e->getMessage(), 'danger');
    }
    redirect('delivery-assignments.php');
}

// --- Update assignment status (auto-stamps dispatched/delivered) ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'setstatus' && $canEdit) {
    csrf_check();
    $aid = (int) ($_POST['id'] ?? 0);
    $status = $_POST['status'] ?? '';
    if ($aid > 0 && in_array($status, ['assigned', 'dispatched', 'delivered', 'failed'], true)) {
        $a = $db->query('SELECT * FROM delivery_assignments WHERE id = ' . $aid)->fetch();
        $extra = '';
        $params = [$status, $aid];
        if ($status === 'dispatched') {
            $extra = ', dispatched_at = COALESCE(dispatched_at, NOW())';
        } elseif ($status === 'delivered') {
            $extra = ', delivered_at = NOW()';
            // Keep order status in sync when possible
            if ($a && mff_can_transition($db->query('SELECT order_status FROM orders WHERE id = ' . (int) $a['order_id'])->fetchColumn(), 'delivered')) {
                $db->prepare('UPDATE orders SET order_status = ? WHERE id = ?')->execute(['delivered', $a['order_id']]);
            }
        }
        $db->prepare("UPDATE delivery_assignments SET status = ? $extra WHERE id = ?")->execute($params);
        mff_audit('delivery.status', 'delivery_assignments', $aid, $a['status'] ?? '', $status);
        mff_flash('Assignment updated.');
    }
    redirect('delivery-assignments.php');
}

// --- Record a delivery attempt ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'attempt' && $canEdit) {
    csrf_check();
    $aid = (int) ($_POST['id'] ?? 0);
    $result = trim($_POST['result'] ?? '');
    $notes = trim($_POST['notes'] ?? '');
    if ($aid > 0 && $result !== '') {
        $db->prepare('INSERT INTO delivery_attempts (assignment_id, attempted_at, result, notes) VALUES (?, NOW(), ?, ?)')
            ->execute([$aid, $result, $notes]);
        mff_audit('delivery.attempt', 'delivery_attempts', (int) $db->lastInsertId(), null, ['assignment_id' => $aid, 'result' => $result]);
        mff_flash('Delivery attempt recorded.');
    }
    redirect('delivery-assignments.php');
}

$assignable = $db->query(
    "SELECT o.id, o.order_number, o.customer_name FROM orders o
     WHERE o.order_status IN ('ready','out_for_delivery')
       AND NOT EXISTS (SELECT 1 FROM delivery_assignments d WHERE d.order_id = o.id)
     ORDER BY o.id DESC"
)->fetchAll();

$rows = $db->query(
    'SELECT d.*, o.order_number, o.customer_name, o.customer_phone, o.total_amount, o.order_status,
            (SELECT COUNT(*) FROM delivery_attempts WHERE assignment_id = d.id) AS attempts
     FROM delivery_assignments d JOIN orders o ON o.id = d.order_id
     ORDER BY d.id DESC LIMIT 50'
)->fetchAll();

ob_start();
?>
<?php if ($canEdit && $assignable): ?>
<div class="card mb-3"><div class="card-header">Assign delivery staff</div><div class="card-body">
  <form method="post" class="row g-2">
    <input type="hidden" name="csrf" value="<?= esc(csrf_token()) ?>">
    <input type="hidden" name="action" value="assign">
    <div class="col-md-3"><label class="form-label required">Order</label>
      <select name="order_id" class="form-select form-select-sm" required>
        <option value="">— Select order —</option>
        <?php foreach ($assignable as $ao): ?><option value="<?= (int) $ao['id'] ?>"><?= esc($ao['order_number']) ?> · <?= esc($ao['customer_name']) ?></option><?php endforeach; ?>
      </select></div>
    <div class="col-md-3"><label class="form-label required">Staff name</label>
      <input type="text" name="staff_name" class="form-control form-control-sm" required></div>
    <div class="col-md-2"><label class="form-label">Staff phone</label>
      <input type="text" name="staff_phone" class="form-control form-control-sm"></div>
    <div class="col-md-3"><label class="form-label">Notes</label>
      <input type="text" name="notes" class="form-control form-control-sm"></div>
    <div class="col-md-1 d-flex align-items-end"><button class="btn btn-sm btn-maroon w-100">Assign</button></div>
  </form>
</div></div>
<?php endif; ?>

<div class="card"><div class="table-responsive"><table class="table table-sm mb-0">
  <thead><tr><th>Order</th><th>Customer</th><th>Staff</th><th>Status</th><th>Assigned</th><th>Dispatched</th><th>Delivered</th><th class="text-end">Attempts</th><?= $canEdit ? '<th>Update</th>' : '' ?></tr></thead>
  <tbody>
  <?php if (!$rows): ?><tr><td colspan="9" class="text-center text-muted py-4">No delivery assignments yet.</td></tr><?php endif; ?>
  <?php foreach ($rows as $r): ?>
    <tr>
      <td><a href="order-view.php?id=<?= (int) $r['order_id'] ?>"><?= esc($r['order_number']) ?></a><br><small class="text-muted"><?= mff_status_badge($r['order_status']) ?></small></td>
      <td><?= esc($r['customer_name']) ?><br><small class="text-muted"><?= esc($r['customer_phone']) ?></small></td>
      <td><?= esc($r['staff_name']) ?><br><small class="text-muted"><?= esc($r['staff_phone']) ?></small></td>
      <td><span class="badge bg-<?= $r['status'] === 'delivered' ? 'success' : ($r['status'] === 'failed' ? 'danger' : 'info') ?>"><?= esc(ucfirst($r['status'])) ?></span></td>
      <td class="small"><?= esc(mff_date($r['assigned_at'])) ?></td>
      <td class="small"><?= $r['dispatched_at'] ? esc(mff_date($r['dispatched_at'])) : '—' ?></td>
      <td class="small"><?= $r['delivered_at'] ? esc(mff_date($r['delivered_at'])) : '—' ?></td>
      <td class="text-end"><?= (int) $r['attempts'] ?></td>
      <?php if ($canEdit): ?><td>
        <form method="post" class="d-flex gap-1 mb-1">
          <input type="hidden" name="csrf" value="<?= esc(csrf_token()) ?>">
          <input type="hidden" name="action" value="setstatus"><input type="hidden" name="id" value="<?= (int) $r['id'] ?>">
          <select name="status" class="form-select form-select-sm">
            <?php foreach (['assigned', 'dispatched', 'delivered', 'failed'] as $s): ?><option value="<?= $s ?>" <?= $r['status'] === $s ? 'selected' : '' ?>><?= ucfirst($s) ?></option><?php endforeach; ?>
          </select>
          <button class="btn btn-sm btn-outline-secondary">Set</button>
        </form>
        <form method="post" class="d-flex gap-1">
          <input type="hidden" name="csrf" value="<?= esc(csrf_token()) ?>">
          <input type="hidden" name="action" value="attempt"><input type="hidden" name="id" value="<?= (int) $r['id'] ?>">
          <input type="text" name="result" class="form-control form-control-sm" placeholder="Attempt result…" required>
          <input type="text" name="notes" class="form-control form-control-sm" placeholder="Notes">
          <button class="btn btn-sm btn-outline-warning" title="Record delivery attempt">Log</button>
        </form>
      </td><?php endif; ?>
    </tr>
  <?php endforeach; ?>
  </tbody>
</table></div></div>
<?php
$content = ob_get_clean();
include __DIR__ . '/_layout.php';
