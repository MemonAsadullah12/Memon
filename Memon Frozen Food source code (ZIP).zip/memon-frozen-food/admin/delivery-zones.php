<?php
require_once __DIR__ . '/../includes/auth.php';
require_admin('deliveries.view');
require_once __DIR__ . '/_helpers.php';
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/helpers.php';

$db = db();
$page_title = 'Delivery Zones';
$canEdit = has_perm('deliveries.edit');

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'save' && $canEdit) {
    csrf_check();
    $id = (int) ($_POST['id'] ?? 0);
    $name = trim($_POST['name'] ?? '');
    $areas = trim($_POST['areas'] ?? '');
    $fee = max(0, (int) ($_POST['delivery_fee'] ?? 0));
    $min = max(0, (int) ($_POST['min_order'] ?? 0));
    $free = ($_POST['free_above'] ?? '') === '' ? null : max(0, (int) $_POST['free_above']);
    $active = isset($_POST['is_active']) ? 1 : 0;
    if ($name === '') {
        mff_flash('Zone name is required.', 'danger');
    } else {
        if ($id > 0) {
            $db->prepare('UPDATE delivery_zones SET name=?, areas=?, delivery_fee=?, min_order=?, free_above=?, is_active=? WHERE id=?')
                ->execute([$name, $areas, $fee, $min, $free, $active, $id]);
            mff_audit('zone.update', 'delivery_zones', $id, null, $name);
            mff_flash('Zone updated.');
        } else {
            $db->prepare('INSERT INTO delivery_zones (name, areas, delivery_fee, min_order, free_above, is_active) VALUES (?,?,?,?,?,?)')
                ->execute([$name, $areas, $fee, $min, $free, $active]);
            mff_audit('zone.create', 'delivery_zones', (int) $db->lastInsertId(), null, $name);
            mff_flash('Zone added.');
        }
    }
    redirect('delivery-zones.php');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'delete' && $canEdit) {
    csrf_check();
    $id = (int) ($_POST['id'] ?? 0);
    $st = $db->prepare('SELECT COUNT(*) FROM orders WHERE delivery_zone_id = ?');
    $st->execute([$id]);
    if ((int) $st->fetchColumn() > 0) {
        mff_flash('Cannot delete: orders use this zone. Deactivate it instead.', 'danger');
    } else {
        $db->prepare('DELETE FROM delivery_zones WHERE id = ?')->execute([$id]);
        mff_audit('zone.delete', 'delivery_zones', $id);
        mff_flash('Zone deleted.');
    }
    redirect('delivery-zones.php');
}

$editId = (int) ($_GET['edit'] ?? 0);
$editRow = $editId ? $db->query('SELECT * FROM delivery_zones WHERE id = ' . $editId)->fetch() : null;
$zones = $db->query(
    'SELECT z.*, (SELECT COUNT(*) FROM orders o WHERE o.delivery_zone_id = z.id) AS orders_count
     FROM delivery_zones z ORDER BY z.name'
)->fetchAll();

ob_start();
?>
<div class="row g-3">
  <?php if ($canEdit): ?>
  <div class="col-lg-4">
    <div class="card"><div class="card-header"><?= $editRow ? 'Edit Zone' : 'Add Zone' ?></div><div class="card-body">
      <form method="post">
        <input type="hidden" name="csrf" value="<?= esc(csrf_token()) ?>">
        <input type="hidden" name="action" value="save">
        <input type="hidden" name="id" value="<?= (int) ($editRow['id'] ?? 0) ?>">
        <div class="mb-2"><label class="form-label required">Zone name</label>
          <input type="text" name="name" class="form-control" required value="<?= esc($editRow['name'] ?? '') ?>"></div>
        <div class="mb-2"><label class="form-label">Areas (one per line)</label>
          <textarea name="areas" class="form-control" rows="4" placeholder="e.g.&#10;Satellite Town&#10;Civil Lines"><?= esc($editRow['areas'] ?? '') ?></textarea></div>
        <div class="row g-2">
          <div class="col-6"><label class="form-label">Delivery fee (Rs)</label>
            <input type="number" name="delivery_fee" class="form-control" min="0" value="<?= (int) ($editRow['delivery_fee'] ?? 0) ?>"></div>
          <div class="col-6"><label class="form-label">Min order (Rs)</label>
            <input type="number" name="min_order" class="form-control" min="0" value="<?= (int) ($editRow['min_order'] ?? 0) ?>"></div>
          <div class="col-12"><label class="form-label">Free delivery above (Rs, blank = never)</label>
            <input type="number" name="free_above" class="form-control" min="0" value="<?= esc($editRow['free_above'] ?? '') ?>"></div>
        </div>
        <div class="form-check my-2"><input type="checkbox" name="is_active" id="zActive" class="form-check-input" <?= ($editRow['is_active'] ?? 1) ? 'checked' : '' ?>>
          <label class="form-check-label" for="zActive">Active</label></div>
        <button class="btn btn-maroon"><?= $editRow ? 'Save changes' : 'Add zone' ?></button>
        <?php if ($editRow): ?><a href="delivery-zones.php" class="btn btn-outline-secondary">Cancel</a><?php endif; ?>
      </form>
    </div></div>
  </div>
  <?php endif; ?>
  <div class="col-lg-<?= $canEdit ? '8' : '12' ?>">
    <div class="card"><div class="table-responsive"><table class="table table-sm mb-0">
      <thead><tr><th>Zone</th><th>Areas</th><th class="text-end">Fee</th><th class="text-end">Min order</th><th class="text-end">Free above</th><th class="text-end">Orders</th><th>Active</th><?= $canEdit ? '<th></th>' : '' ?></tr></thead>
      <tbody>
      <?php foreach ($zones as $z): ?>
        <tr>
          <td><strong><?= esc($z['name']) ?></strong></td>
          <td class="small"><?= nl2br(esc(mb_substr($z['areas'] ?? '', 0, 120))) ?></td>
          <td class="text-end"><?= esc(rs((int) $z['delivery_fee'])) ?></td>
          <td class="text-end"><?= esc(rs((int) $z['min_order'])) ?></td>
          <td class="text-end"><?= $z['free_above'] !== null ? esc(rs((int) $z['free_above'])) : '—' ?></td>
          <td class="text-end"><?= (int) $z['orders_count'] ?></td>
          <td><?= $z['is_active'] ? '<span class="badge bg-success">Yes</span>' : '<span class="badge bg-secondary">No</span>' ?></td>
          <?php if ($canEdit): ?><td class="text-nowrap">
            <a href="delivery-zones.php?edit=<?= (int) $z['id'] ?>" class="btn btn-sm btn-outline-secondary">Edit</a>
            <form method="post" class="d-inline" onsubmit="return confirm('Delete this zone?')">
              <input type="hidden" name="csrf" value="<?= esc(csrf_token()) ?>">
              <input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?= (int) $z['id'] ?>">
              <button class="btn btn-sm btn-outline-danger">Delete</button>
            </form>
          </td><?php endif; ?>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table></div></div>
  </div>
</div>
<?php
$content = ob_get_clean();
include __DIR__ . '/_layout.php';
