<?php
require_once __DIR__ . '/../includes/auth.php';
require_admin('expenses.view');
require_once __DIR__ . '/_helpers.php';
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/helpers.php';

$db = db();
$page_title = 'Expenses';
$canEdit = has_perm('expenses.edit');

// --- Add expense category inline ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'addcat' && $canEdit) {
    csrf_check();
    $name = trim($_POST['cat_name'] ?? '');
    if ($name !== '') {
        try {
            $db->prepare('INSERT INTO expense_categories (name) VALUES (?)')->execute([$name]);
            mff_audit('expense_category.create', 'expense_categories', (int) $db->lastInsertId(), null, $name);
            mff_flash('Category added.');
        } catch (Throwable $e) {
            mff_flash('Category already exists.', 'danger');
        }
    }
    redirect('expenses.php');
}

// --- Save expense ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'save' && $canEdit) {
    csrf_check();
    $id = (int) ($_POST['id'] ?? 0);
    $catId = (int) ($_POST['category_id'] ?? 0);
    $date = $_POST['expense_date'] ?? date('Y-m-d');
    $amount = (int) ($_POST['amount'] ?? 0);
    $desc = trim($_POST['description'] ?? '');
    $pm = $_POST['payment_method'] ?? 'Cash';
    try {
        if ($catId <= 0 || $amount <= 0 || $desc === '') {
            throw new RuntimeException('Category, a positive amount and a description are required.');
        }
        $receipt = null;
        if (!empty($_FILES['receipt']['name'])) {
            $receipt = mff_upload_image($_FILES['receipt'], 'receipts');
        }
        if ($id > 0) {
            $old = $db->query('SELECT * FROM expenses WHERE id = ' . $id)->fetch();
            if ($receipt === null) {
                $receipt = $old['receipt_file'];
            }
            $db->prepare('UPDATE expenses SET category_id=?, expense_date=?, amount=?, description=?, payment_method=?, receipt_file=? WHERE id=?')
                ->execute([$catId, $date, $amount, $desc, $pm, $receipt, $id]);
            mff_audit('expense.update', 'expenses', $id, ['amount' => $old['amount']], ['amount' => $amount]);
            mff_flash('Expense updated.');
        } else {
            $db->prepare('INSERT INTO expenses (category_id, expense_date, amount, description, payment_method, receipt_file, admin_id) VALUES (?,?,?,?,?,?,?)')
                ->execute([$catId, $date, $amount, $desc, $pm, $receipt, current_admin()['id'] ?? null]);
            mff_audit('expense.create', 'expenses', (int) $db->lastInsertId(), null, ['amount' => $amount, 'description' => $desc]);
            mff_flash('Expense added.');
        }
    } catch (Throwable $e) {
        mff_flash($e->getMessage(), 'danger');
    }
    redirect('expenses.php');
}

// --- Delete ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'delete' && $canEdit) {
    csrf_check();
    $id = (int) ($_POST['id'] ?? 0);
    $db->prepare('DELETE FROM expenses WHERE id = ?')->execute([$id]);
    mff_audit('expense.delete', 'expenses', $id);
    mff_flash('Expense deleted.');
    redirect('expenses.php');
}

$cat = (int) ($_GET['cat'] ?? 0);
$dfrom = $_GET['dfrom'] ?? '';
$dto = $_GET['dto'] ?? '';
$where = [];
$params = [];
if ($cat > 0) {
    $where[] = 'e.category_id = ?';
    $params[] = $cat;
}
if ($dfrom !== '') {
    $where[] = 'e.expense_date >= ?';
    $params[] = $dfrom;
}
if ($dto !== '') {
    $where[] = 'e.expense_date <= ?';
    $params[] = $dto;
}
$whereSql = $where ? 'WHERE ' . implode(' AND ', $where) : '';

$st = $db->prepare("SELECT COUNT(*) FROM expenses e $whereSql");
$st->execute($params);
$total = (int) $st->fetchColumn();
$st = $db->prepare("SELECT COALESCE(SUM(amount),0) FROM expenses e $whereSql");
$st->execute($params);
$totalAmt = (int) $st->fetchColumn();
$page = max(1, (int) ($_GET['page'] ?? 1));
$per = 20;
$offset = ($page - 1) * $per;

$st = $db->prepare(
    "SELECT e.*, c.name AS cat_name, u.name AS admin_name FROM expenses e
     JOIN expense_categories c ON c.id = e.category_id
     LEFT JOIN users u ON u.id = e.admin_id
     $whereSql ORDER BY e.expense_date DESC, e.id DESC LIMIT $per OFFSET $offset"
);
$st->execute($params);
$rows = $st->fetchAll();
$cats = $db->query('SELECT * FROM expense_categories ORDER BY name')->fetchAll();
$editId = (int) ($_GET['edit'] ?? 0);
$editRow = $editId ? $db->query('SELECT * FROM expenses WHERE id = ' . $editId)->fetch() : null;

ob_start();
?>
<div class="alert alert-info">Total expenses (filtered): <strong><?= esc(rs($totalAmt)) ?></strong></div>

<?php if ($canEdit): ?>
<div class="row g-3 mb-3">
  <div class="col-lg-8">
    <div class="card"><div class="card-header"><?= $editRow ? 'Edit Expense' : 'Add Expense' ?></div><div class="card-body">
      <form method="post" enctype="multipart/form-data" class="row g-2">
        <input type="hidden" name="csrf" value="<?= esc(csrf_token()) ?>">
        <input type="hidden" name="action" value="save">
        <input type="hidden" name="id" value="<?= (int) ($editRow['id'] ?? 0) ?>">
        <div class="col-md-3"><label class="form-label required">Category</label>
          <select name="category_id" class="form-select form-select-sm" required>
            <option value="">—</option>
            <?php foreach ($cats as $cc): ?><option value="<?= (int) $cc['id'] ?>" <?= (int) ($editRow['category_id'] ?? 0) === (int) $cc['id'] ? 'selected' : '' ?>><?= esc($cc['name']) ?></option><?php endforeach; ?>
          </select></div>
        <div class="col-md-3"><label class="form-label required">Date</label>
          <input type="date" name="expense_date" class="form-control form-control-sm" value="<?= esc($editRow['expense_date'] ?? date('Y-m-d')) ?>"></div>
        <div class="col-md-3"><label class="form-label required">Amount (Rs)</label>
          <input type="number" name="amount" class="form-control form-control-sm" min="1" required value="<?= esc($editRow['amount'] ?? '') ?>"></div>
        <div class="col-md-3"><label class="form-label">Paid via</label>
          <select name="payment_method" class="form-select form-select-sm">
            <?php foreach (['Cash', 'Bank Transfer', 'Easypaisa', 'JazzCash', 'Other'] as $m): ?><option <?= ($editRow['payment_method'] ?? '') === $m ? 'selected' : '' ?>><?= $m ?></option><?php endforeach; ?>
          </select></div>
        <div class="col-md-8"><label class="form-label required">Description</label>
          <input type="text" name="description" class="form-control form-control-sm" required value="<?= esc($editRow['description'] ?? '') ?>"></div>
        <div class="col-md-4"><label class="form-label">Receipt (image ≤2MB)</label>
          <input type="file" name="receipt" class="form-control form-control-sm" accept=".jpg,.jpeg,.png,.webp"></div>
        <div class="col-12">
          <button class="btn btn-sm btn-maroon"><?= $editRow ? 'Save changes' : 'Add expense' ?></button>
          <?php if ($editRow): ?><a href="expenses.php" class="btn btn-sm btn-outline-secondary">Cancel</a><?php endif; ?>
        </div>
      </form>
    </div></div>
  </div>
  <div class="col-lg-4">
    <div class="card"><div class="card-header">Add category</div><div class="card-body">
      <form method="post" class="d-flex gap-2">
        <input type="hidden" name="csrf" value="<?= esc(csrf_token()) ?>">
        <input type="hidden" name="action" value="addcat">
        <input type="text" name="cat_name" class="form-control form-control-sm" placeholder="e.g. Packaging" required>
        <button class="btn btn-sm btn-outline-secondary">Add</button>
      </form>
    </div></div>
  </div>
</div>
<?php endif; ?>

<div class="card mb-3"><div class="card-body">
  <form method="get" class="row g-2">
    <div class="col-md-3"><select name="cat" class="form-select form-select-sm">
      <option value="0">All categories</option>
      <?php foreach ($cats as $cc): ?><option value="<?= (int) $cc['id'] ?>" <?= $cat === (int) $cc['id'] ? 'selected' : '' ?>><?= esc($cc['name']) ?></option><?php endforeach; ?>
    </select></div>
    <div class="col-md-3"><input type="date" name="dfrom" class="form-control form-control-sm" value="<?= esc($dfrom) ?>"></div>
    <div class="col-md-3"><input type="date" name="dto" class="form-control form-control-sm" value="<?= esc($dto) ?>"></div>
    <div class="col-md-2"><button class="btn btn-sm btn-maroon w-100">Filter</button></div>
  </form>
</div></div>

<div class="card"><div class="table-responsive"><table class="table table-sm mb-0">
  <thead><tr><th>Date</th><th>Category</th><th>Description</th><th class="text-end">Amount</th><th>Paid via</th><th>Receipt</th><th>By</th><?= $canEdit ? '<th></th>' : '' ?></tr></thead>
  <tbody>
  <?php if (!$rows): ?><tr><td colspan="8" class="text-center text-muted py-4">No expenses found.</td></tr><?php endif; ?>
  <?php foreach ($rows as $r): ?>
    <tr>
      <td class="small"><?= esc(date('d M Y', strtotime($r['expense_date']))) ?></td>
      <td><span class="badge bg-secondary"><?= esc($r['cat_name']) ?></span></td>
      <td><?= esc($r['description']) ?></td>
      <td class="text-end fw-bold"><?= esc(rs((int) $r['amount'])) ?></td>
      <td class="small"><?= esc($r['payment_method']) ?></td>
      <td><?= $r['receipt_file'] ? '<a href="../' . esc($r['receipt_file']) . '" target="_blank">View</a>' : '—' ?></td>
      <td class="small"><?= esc($r['admin_name'] ?? '—') ?></td>
      <?php if ($canEdit): ?><td class="text-nowrap">
        <a href="expenses.php?edit=<?= (int) $r['id'] ?>" class="btn btn-sm btn-outline-secondary">Edit</a>
        <form method="post" class="d-inline" onsubmit="return confirm('Delete this expense?')">
          <input type="hidden" name="csrf" value="<?= esc(csrf_token()) ?>">
          <input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?= (int) $r['id'] ?>">
          <button class="btn btn-sm btn-outline-danger">Delete</button>
        </form>
      </td><?php endif; ?>
    </tr>
  <?php endforeach; ?>
  </tbody>
</table></div></div>
<div class="mt-2"><?= mff_pagination($total, $page, $per, 'expenses.php', ['cat' => $cat, 'dfrom' => $dfrom, 'dto' => $dto]) ?></div>
<?php
$content = ob_get_clean();
include __DIR__ . '/_layout.php';
