<?php
require_once __DIR__ . '/../includes/auth.php';
require_admin('dashboard.view');
require_once __DIR__ . '/_helpers.php';
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/helpers.php';

$db = db();
$page_title = 'Dashboard';

// --- Date range filter for the sales figures ---
$range = $_GET['range'] ?? 'today';
if (!in_array($range, ['today', '7d', '30d'], true)) {
    $range = 'today';
}
$fromMap = ['today' => date('Y-m-d'), '7d' => date('Y-m-d', strtotime('-6 days')), '30d' => date('Y-m-d', strtotime('-29 days'))];
$from = $fromMap[$range];

// Sales + orders in range (excluding cancelled/returned)
$st = $db->prepare(
    "SELECT COALESCE(SUM(total_amount),0) AS sales, COUNT(*) AS cnt
     FROM orders WHERE DATE(created_at) >= ? AND order_status NOT IN ('cancelled','returned')"
);
$st->execute([$from]);
$r = $st->fetch();
$rangeSales = (int) $r['sales'];
$rangeOrders = (int) $r['cnt'];

// Pipeline counts (all time, current snapshot)
$pipeline = ['received' => 0, 'confirmed' => 0, 'preparing' => 0, 'ready' => 0, 'out_for_delivery' => 0, 'delivered' => 0, 'cancelled' => 0, 'returned' => 0];
foreach ($db->query('SELECT order_status, COUNT(*) c FROM orders GROUP BY order_status') as $row) {
    $pipeline[$row['order_status']] = (int) $row['c'];
}
$pending = $pipeline['received'] + $pipeline['confirmed'];

// Misc counters
$totalCustomers = (int) $db->query('SELECT COUNT(*) FROM customers')->fetchColumn();
$activeProducts = (int) $db->query('SELECT COUNT(*) FROM products WHERE is_active = 1')->fetchColumn();
$lowStockCount = (int) $db->query('SELECT COUNT(*) FROM products WHERE is_active = 1 AND stock_quantity <= low_stock_threshold')->fetchColumn();
$monthStart = date('Y-m-01');
$st = $db->prepare(
    "SELECT COALESCE(SUM(total_amount),0) FROM orders
     WHERE DATE(created_at) >= ? AND order_status NOT IN ('cancelled','returned')"
);
$st->execute([$monthStart]);
$monthlyRevenue = (int) $st->fetchColumn();

// Top 5 products by quantity sold (last 30 days, non-cancelled orders)
$topProducts = $db->query(
    "SELECT p.id, p.name, SUM(oi.quantity) AS qty, SUM(oi.line_total) AS rev
     FROM order_items oi
     JOIN orders o ON o.id = oi.order_id
     LEFT JOIN products p ON p.id = oi.product_id
     WHERE o.created_at >= DATE_SUB(CURDATE(), INTERVAL 30 DAY)
       AND o.order_status NOT IN ('cancelled','returned')
     GROUP BY oi.product_id, p.name
     ORDER BY qty DESC LIMIT 5"
)->fetchAll();

// Recent 10 orders
$recentOrders = $db->query(
    "SELECT o.id, o.order_number, o.customer_name, o.total_amount, o.order_status, o.payment_status, o.created_at,
            (SELECT COUNT(*) FROM order_items WHERE order_id = o.id) AS items
     FROM orders o ORDER BY o.id DESC LIMIT 10"
)->fetchAll();

// Sales chart: last 14 days
$chartRows = $db->query(
    "SELECT DATE(created_at) AS d, COALESCE(SUM(total_amount),0) AS s
     FROM orders
     WHERE created_at >= DATE_SUB(CURDATE(), INTERVAL 13 DAY)
       AND order_status NOT IN ('cancelled','returned')
     GROUP BY DATE(created_at)"
)->fetchAll(PDO::FETCH_KEY_PAIR);
$chartLabels = [];
$chartValues = [];
for ($i = 13; $i >= 0; $i--) {
    $d = date('Y-m-d', strtotime("-$i days"));
    $chartLabels[] = date('d M', strtotime($d));
    $chartValues[] = (int) ($chartRows[$d] ?? 0);
}

// Order-status doughnut counts
$statusCounts = [];
foreach (mff_statuses() as $code => $label) {
    $statusCounts[] = ['label' => $label, 'count' => $pipeline[$code] ?? 0];
}

// Low stock alerts
$lowStock = $db->query(
    'SELECT id, name, sku, stock_quantity, low_stock_threshold
     FROM products WHERE is_active = 1 AND stock_quantity <= low_stock_threshold
     ORDER BY stock_quantity ASC LIMIT 10'
)->fetchAll();

// Recent audit activity
$recentAudit = $db->query(
    'SELECT a.action, a.record_type, a.record_id, a.created_at, u.name AS admin_name
     FROM audit_logs a LEFT JOIN users u ON u.id = a.admin_id
     ORDER BY a.id DESC LIMIT 10'
)->fetchAll();

$rangeLabel = ['today' => 'Today', '7d' => 'Last 7 days', '30d' => 'Last 30 days'][$range];

ob_start();
?>
<div class="d-flex flex-wrap align-items-center gap-2 mb-3">
  <h2 class="h5 mb-0 text-muted">Welcome back, <?= esc(current_admin()['name'] ?? 'Admin') ?> 👋</h2>
  <div class="ms-auto btn-group btn-group-sm" role="group" aria-label="Date range">
    <?php foreach (['today' => 'Today', '7d' => '7 days', '30d' => '30 days'] as $k => $lbl): ?>
      <a href="index.php?range=<?= $k ?>" class="btn <?= $range === $k ? 'btn-maroon' : 'btn-outline-secondary' ?>"><?= $lbl ?></a>
    <?php endforeach; ?>
  </div>
</div>

<!-- Stat cards -->
<div class="row g-3 mb-4">
  <?php
  $cards = [
      ['Sales (' . $rangeLabel . ')', rs($rangeSales), 'orders.php', '💰'],
      ['Orders (' . $rangeLabel . ')', number_format($rangeOrders), 'orders.php', '🧾'],
      ['Pending (Received + Confirmed)', number_format($pending), 'orders.php?status=received', '⏳'],
      ['Out for Delivery', number_format($pipeline['out_for_delivery']), 'orders.php?status=out_for_delivery', '🛵'],
      ['Monthly Revenue', rs($monthlyRevenue), 'reports.php?tab=monthly', '📈'],
      ['Customers', number_format($totalCustomers), 'customers.php', '👥'],
      ['Active Products', number_format($activeProducts), 'products.php', '🍗'],
      ['Low Stock Alerts', number_format($lowStockCount), 'reports.php?tab=low_stock', '⚠️'],
  ];
  foreach ($cards as [$label, $val, $link, $icon]):
      $can = true;
      if (str_starts_with($link, 'orders.php')) {
          $can = has_perm('orders.view');
      } elseif (str_starts_with($link, 'reports.php')) {
          $can = has_perm('reports.view');
      } elseif (str_starts_with($link, 'customers.php')) {
          $can = has_perm('customers.view');
      } elseif (str_starts_with($link, 'products.php')) {
          $can = has_perm('products.view');
      }
      ?>
    <div class="col-6 col-md-4 col-xl-3">
      <div class="card stat-card h-100"><div class="card-body py-3">
        <div class="d-flex justify-content-between align-items-start">
          <div>
            <div class="stat-num"><?= esc($val) ?></div>
            <div class="text-muted small"><?= esc($label) ?></div>
          </div>
          <span class="fs-3"><?= $icon ?></span>
        </div>
        <?php if ($can): ?><a href="<?= esc($link) ?>" class="small">View →</a><?php endif; ?>
      </div></div>
    </div>
  <?php endforeach; ?>
</div>

<div class="row g-3 mb-4">
  <!-- Sales chart -->
  <div class="col-lg-8">
    <div class="card h-100">
      <div class="card-header">Sales — last 14 days</div>
      <div class="card-body"><canvas id="salesChart" height="220" style="width:100%;height:220px;"></canvas></div>
    </div>
  </div>
  <!-- Status doughnut -->
  <div class="col-lg-4">
    <div class="card h-100">
      <div class="card-header">Orders by status</div>
      <div class="card-body d-flex justify-content-center"><canvas id="statusChart" width="220" height="220"></canvas></div>
      <div class="card-footer small">
        <?php foreach ($statusCounts as $sc): ?>
          <?php if ($sc['count'] > 0): ?><span class="me-2">• <?= esc($sc['label']) ?>: <strong><?= $sc['count'] ?></strong></span><?php endif; ?>
        <?php endforeach; ?>
      </div>
    </div>
  </div>
</div>

<div class="row g-3 mb-4">
  <!-- Top products -->
  <div class="col-lg-6">
    <div class="card h-100">
      <div class="card-header">Top 5 products (last 30 days)</div>
      <div class="table-responsive"><table class="table table-sm mb-0">
        <thead><tr><th>Product</th><th class="text-end">Qty sold</th><th class="text-end">Revenue</th></tr></thead>
        <tbody>
        <?php if (!$topProducts): ?><tr><td colspan="3" class="text-center text-muted py-3">No sales in the last 30 days.</td></tr><?php endif; ?>
        <?php foreach ($topProducts as $tp): ?>
          <tr>
            <td><?= esc($tp['name'] ?? '—') ?></td>
            <td class="text-end"><?= number_format((int) $tp['qty']) ?></td>
            <td class="text-end"><?= esc(rs((int) $tp['rev'])) ?></td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table></div>
    </div>
  </div>
  <!-- Low stock -->
  <div class="col-lg-6">
    <div class="card h-100">
      <div class="card-header d-flex justify-content-between align-items-center">
        <span>Low stock alerts</span>
        <?php if (has_perm('inventory.view')): ?><a href="inventory.php" class="btn btn-sm btn-maroon">Manage stock</a><?php endif; ?>
      </div>
      <div class="table-responsive"><table class="table table-sm mb-0">
        <thead><tr><th>Product</th><th>SKU</th><th class="text-end">Stock</th><th class="text-end">Threshold</th></tr></thead>
        <tbody>
        <?php if (!$lowStock): ?><tr><td colspan="4" class="text-center text-muted py-3">All stocked up. 🎉</td></tr><?php endif; ?>
        <?php foreach ($lowStock as $ls): ?>
          <tr class="low-stock">
            <td><?= esc($ls['name']) ?></td>
            <td class="text-muted small"><?= esc($ls['sku']) ?></td>
            <td class="text-end fw-bold text-danger"><?= (int) $ls['stock_quantity'] ?></td>
            <td class="text-end"><?= (int) $ls['low_stock_threshold'] ?></td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table></div>
    </div>
  </div>
</div>

<div class="row g-3">
  <!-- Recent orders -->
  <div class="col-lg-7">
    <div class="card">
      <div class="card-header d-flex justify-content-between align-items-center">
        <span>Recent orders</span>
        <?php if (has_perm('orders.view')): ?><a href="orders.php" class="btn btn-sm btn-maroon">All orders</a><?php endif; ?>
      </div>
      <div class="table-responsive"><table class="table table-sm mb-0">
        <thead><tr><th>Order</th><th>Customer</th><th class="text-end">Items</th><th class="text-end">Total</th><th>Status</th><th></th></tr></thead>
        <tbody>
        <?php if (!$recentOrders): ?><tr><td colspan="6" class="text-center text-muted py-3">No orders yet.</td></tr><?php endif; ?>
        <?php foreach ($recentOrders as $o): ?>
          <tr>
            <td><strong><?= esc($o['order_number']) ?></strong><br><small class="text-muted"><?= esc(mff_date($o['created_at'])) ?></small></td>
            <td><?= esc($o['customer_name']) ?></td>
            <td class="text-end"><?= (int) $o['items'] ?></td>
            <td class="text-end"><?= esc(rs((int) $o['total_amount'])) ?></td>
            <td><?= mff_status_badge($o['order_status']) ?></td>
            <td><?php if (has_perm('orders.view')): ?><a href="order-view.php?id=<?= (int) $o['id'] ?>" class="btn btn-sm btn-outline-secondary">View</a><?php endif; ?></td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table></div>
    </div>
  </div>
  <!-- Recent audit -->
  <div class="col-lg-5">
    <div class="card">
      <div class="card-header d-flex justify-content-between align-items-center">
        <span>Recent admin activity</span>
        <?php if (has_perm('audit.view')): ?><a href="audit-logs.php" class="btn btn-sm btn-maroon">Audit logs</a><?php endif; ?>
      </div>
      <ul class="list-group list-group-flush small">
        <?php if (!$recentAudit): ?><li class="list-group-item text-muted">No activity recorded yet.</li><?php endif; ?>
        <?php foreach ($recentAudit as $a): ?>
          <li class="list-group-item">
            <strong><?= esc($a['admin_name'] ?? 'System') ?></strong>
            <span class="text-muted"><?= esc($a['action']) ?></span>
            <?php if ($a['record_type']): ?><span class="badge bg-light text-dark"><?= esc($a['record_type']) ?> #<?= esc((string) $a['record_id']) ?></span><?php endif; ?>
            <br><small class="text-muted"><?= esc(mff_date($a['created_at'])) ?></small>
          </li>
        <?php endforeach; ?>
      </ul>
    </div>
  </div>
</div>

<script>
// Vanilla-JS bar chart (no external chart library).
(function () {
  var labels = <?= json_encode($chartLabels) ?>;
  var values = <?= json_encode($chartValues) ?>;
  var cv = document.getElementById('salesChart');
  if (!cv) return;
  var ctx = cv.getContext('2d');
  var W = cv.width = cv.offsetWidth * 2, H = cv.height = 440;
  var max = Math.max.apply(null, values.concat([1]));
  var padL = 90, padB = 60, padT = 20;
  var bw = (W - padL - 20) / values.length;
  ctx.clearRect(0, 0, W, H);
  ctx.font = '20px sans-serif'; ctx.fillStyle = '#666';
  for (var g = 0; g <= 4; g++) {
    var y = padT + (H - padB - padT) * g / 4, v = Math.round(max * (4 - g) / 4);
    ctx.strokeStyle = '#eee'; ctx.beginPath(); ctx.moveTo(padL, y); ctx.lineTo(W - 10, y); ctx.stroke();
    ctx.fillText('Rs ' + v.toLocaleString(), 6, y + 7);
  }
  values.forEach(function (v, i) {
    var h = (H - padB - padT) * v / max, x = padL + i * bw + bw * 0.18, y = H - padB - h;
    ctx.fillStyle = '#970D0D'; ctx.fillRect(x, y, bw * 0.64, h);
    ctx.fillStyle = '#666'; ctx.save(); ctx.translate(x + bw * 0.3, H - padB + 14);
    ctx.rotate(0); ctx.textAlign = 'center'; ctx.fillText(labels[i], 0, 18); ctx.restore();
    if (v > 0) { ctx.fillStyle = '#970D0D'; ctx.textAlign = 'center'; ctx.fillText(v.toLocaleString(), x + bw * 0.32, y - 8); }
  });
})();
// Vanilla-JS doughnut chart for order statuses.
(function () {
  var data = <?= json_encode(array_values(array_filter($statusCounts, fn($s) => $s['count'] > 0))) ?>;
  var cv = document.getElementById('statusChart');
  if (!cv || !data.length) return;
  var ctx = cv.getContext('2d'), total = data.reduce(function (a, b) { return a + b.count; }, 0);
  var colors = ['#970D0D', '#FFD54A', '#E9A23B', '#228B52', '#0d6efd', '#6c757d', '#dc3545', '#6610f2'];
  var cx = 220, cy = 220, r = 170, ir = 100, ang = -Math.PI / 2;
  data.forEach(function (d, i) {
    var sweep = total ? (d.count / total) * Math.PI * 2 : 0;
    ctx.beginPath(); ctx.arc(cx, cy, r, ang, ang + sweep); ctx.arc(cx, cy, ir, ang + sweep, ang, true);
    ctx.closePath(); ctx.fillStyle = colors[i % colors.length]; ctx.fill();
    ang += sweep;
  });
  ctx.fillStyle = '#222'; ctx.font = 'bold 34px sans-serif'; ctx.textAlign = 'center';
  ctx.fillText(total, cx, cy + 12);
})();
</script>
<?php
$content = ob_get_clean();
include __DIR__ . '/_layout.php';
