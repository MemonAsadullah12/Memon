<?php
require_once __DIR__ . '/../includes/auth.php';
require_admin('inventory.view');
require_once __DIR__ . '/_helpers.php';
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/helpers.php';

$db = db();
$page_title = 'Inventory';
$canEdit = has_perm('inventory.edit');

// --- Stock adjustment: ONE transaction updating stock_movements + products + inventory ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'adjust' && $canEdit) {
    csrf_check();
    $pid = (int) ($_POST['product_id'] ?? 0);
    $type = $_POST['movement_type'] ?? '';
    $qty = (int) ($_POST['change_qty'] ?? 0);
    $notes = trim($_POST['notes'] ?? '');
    $batchNo = trim($_POST['batch_no'] ?? '');
    $expiry = $_POST['expiry_date'] ?? '';
    $validTypes = ['received', 'adjustment', 'damaged', 'expired', 'returned'];
    try {
        if ($pid <= 0 || !in_array($type, $validTypes, true)) {
            throw new RuntimeException('Please choose a product and a valid movement type.');
        }
        if ($qty === 0) {
            throw new RuntimeException('Quantity change cannot be zero (use negative numbers to reduce stock).');
        }
        $p = $db->query('SELECT id, name, stock_quantity FROM products WHERE id = ' . $pid)->fetch();
        if (!$p) {
            throw new RuntimeException('Product not found.');
        }
        $newQty = (int) $p['stock_quantity'] + $qty;
        if ($newQty < 0) {
            throw new RuntimeException('Adjustment would take stock below zero (current: ' . $p['stock_quantity'] . ').');
        }
        $db->beginTransaction();
        $db->prepare(
            "INSERT INTO stock_movements (product_id, change_qty, movement_type, reference_type, notes, admin_id)
             VALUES (?, ?, ?, 'manual', ?, ?)"
        )->execute([$pid, $qty, $type, $notes, current_admin()['id'] ?? null]);
        $db->prepare('UPDATE products SET stock_quantity = ?, updated_at = NOW() WHERE id = ?')->execute([$newQty, $pid]);
        $db->prepare('INSERT INTO inventory (product_id, quantity) VALUES (?, ?) ON DUPLICATE KEY UPDATE quantity = ?')
            ->execute([$pid, $newQty, $newQty]);
        if ($batchNo !== '' || $expiry !== '') {
            $db->prepare('INSERT INTO inventory_batches (product_id, batch_no, expiry_date, quantity) VALUES (?,?,?,?)')
                ->execute([$pid, $batchNo ?: null, $expiry ?: null, max(0, $qty)]);
        }
        $db->commit();
        mff_audit('inventory.adjust', 'products', $pid, ['stock_quantity' => (int) $p['stock_quantity'], 'type' => $type], ['stock_quantity' => $newQty, 'change' => $qty]);
        mff_flash('Stock updated: ' . $p['name'] . ' is now ' . $newQty . '.');
    } catch (Throwable $e) {
        if ($db->inTransaction()) {
            $db->rollBack();
        }
        mff_flash($e->getMessage(), 'danger');
    }
    redirect('inventory.php');
}

$rows = $db->query(
    'SELECT p.id, p.name, p.sku, p.stock_quantity, p.low_stock_threshold, p.is_active,
            (SELECT MAX(created_at) FROM stock_movements WHERE product_id = p.id) AS last_movement
     FROM products p ORDER BY p.name'
)->fetchAll();

ob_start();
?>
<?php if ($canEdit): ?>
<div class="card mb-3"><div class="card-header">Adjust stock</div><div class="card-body">
  <form method="post" class="row g-2">
    <input type="hidden" name="csrf" value="<?= esc(csrf_token()) ?>">
    <input type="hidden" name="action" value="adjust">
    <div class="col-md-3"><label class="form-label required">Product</label>
      <select name="product_id" class="form-select form-select-sm" required>
        <option value="">— Select —</option>
        <?php foreach ($rows as $r): ?><option value="<?= (int) $r['id'] ?>"><?= esc($r['name']) ?> (<?= (int) $r['stock_quantity'] ?>)</option><?php endforeach; ?>
      </select></div>
    <div class="col-md-2"><label class="form-label required">Type</label>
      <select name="movement_type" class="form-select form-select-sm" required>
        <option value="received">Received (stock in)</option>
        <option value="adjustment">Adjustment</option>
        <option value="damaged">Damaged</option>
        <option value="expired">Expired</option>
        <option value="returned">Returned</option>
      </select></div>
    <div class="col-md-2"><label class="form-label required">Change qty</label>
      <input type="number" name="change_qty" class="form-control form-control-sm" required placeholder="+10 / −2">
      <small class="text-muted">Negative reduces stock.</small></div>
    <div class="col-md-2"><label class="form-label">Batch no. (optional)</label>
      <input type="text" name="batch_no" class="form-control form-control-sm"></div>
    <div class="col-md-2"><label class="form-label">Expiry (optional)</label>
      <input type="date" name="expiry_date" class="form-control form-control-sm"></div>
    <div class="col-md-3"><label class="form-label">Notes</label>
      <input type="text" name="notes" class="form-control form-control-sm" placeholder="Reason…"></div>
    <div class="col-md-2 d-flex align-items-end"><button class="btn btn-sm btn-maroon w-100">Apply</button></div>
  </form>
</div></div>
<?php endif; ?>

<div class="card"><div class="table-responsive"><table class="table table-sm table-hover mb-0">
  <thead><tr><th>Product</th><th>SKU</th><th class="text-end">Stock</th><th class="text-end">Threshold</th><th>Status</th><th>Last movement</th></tr></thead>
  <tbody>
  <?php foreach ($rows as $r): ?>
    <?php $low = (int) $r['stock_quantity'] <= (int) $r['low_stock_threshold']; ?>
    <tr class="<?= $low ? 'low-stock' : '' ?>">
      <td><?= esc($r['name']) ?> <?= $r['is_active'] ? '' : '<span class="badge bg-secondary">inactive</span>' ?></td>
      <td class="small"><?= esc($r['sku']) ?></td>
      <td class="text-end fw-bold <?= $low ? 'text-danger' : '' ?>"><?= (int) $r['stock_quantity'] ?></td>
      <td class="text-end"><?= (int) $r['low_stock_threshold'] ?></td>
      <td><?= (int) $r['stock_quantity'] === 0 ? '<span class="badge bg-danger">Out of stock</span>' : ($low ? '<span class="badge bg-warning text-dark">Low</span>' : '<span class="badge bg-success">OK</span>') ?></td>
      <td class="small"><?= $r['last_movement'] ? esc(mff_date($r['last_movement'])) : '—' ?></td>
    </tr>
  <?php endforeach; ?>
  </tbody>
</table></div></div>
<?php
$content = ob_get_clean();
include __DIR__ . '/_layout.php';
