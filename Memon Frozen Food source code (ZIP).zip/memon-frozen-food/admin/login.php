<?php
// Admin sign-in. Uses includes/auth.php::admin_login(), which enforces the
// rate limit (5 failures / 15 min per IP, session-tracked + audited),
// regenerates the session id, and audits successful/failed attempts.
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/helpers.php';

if (function_exists('current_admin') && current_admin()) {
    redirect('index.php');
}

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    if ($email === '' || $password === '') {
        $error = 'Please enter your email and password.';
    } else {
        $res = admin_login($email, $password); // ['ok'=>bool, 'msg'=>string, 'user'=>array]
        if (!empty($res['ok'])) {
            redirect('index.php');
        }
        $error = $res['msg'] ?? 'Invalid email or password.';
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Admin Login · <?= esc(defined('SITE_NAME') ? SITE_NAME : 'Memon Frozen Food') ?></title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<style>
:root{--maroon:#970D0D;--deepred:#790808;--gold:#FFD54A;--cream:#FFF8E9;}
body{background:linear-gradient(135deg,var(--maroon),var(--deepred));min-height:100vh;display:flex;align-items:center;justify-content:center;padding:1rem;}
.card{max-width:400px;width:100%;border-radius:.8rem;overflow:hidden;border:none;box-shadow:0 10px 30px rgba(0,0,0,.35);}
.card-header{background:var(--maroon);color:#fff;text-align:center;padding:1.5rem 1rem;border:none;}
.brand-tag{color:var(--gold);letter-spacing:3px;font-size:.7rem;font-weight:700;}
.btn-maroon{background:var(--maroon);border-color:var(--maroon);color:#fff;font-weight:700;}
.btn-maroon:hover{background:var(--deepred);border-color:var(--deepred);color:#fff;}
</style>
</head>
<body>
<div class="card">
  <div class="card-header">
    <div class="fs-4 fw-bold">Memon Frozen Food</div>
    <div class="brand-tag">HYGIENIC TASTE</div>
    <div class="mt-2 small opacity-75">Admin Panel Sign In</div>
  </div>
  <div class="card-body p-4">
    <?php if ($error): ?>
      <div class="alert alert-danger"><?= esc($error) ?></div>
    <?php endif; ?>
    <form method="post" action="login.php" autocomplete="off">
      <input type="hidden" name="csrf" value="<?= esc(csrf_token()) ?>">
      <div class="mb-3">
        <label class="form-label fw-semibold" for="email">Email</label>
        <input type="email" class="form-control" id="email" name="email" required autofocus
               value="<?= esc($_POST['email'] ?? '') ?>">
      </div>
      <div class="mb-3">
        <label class="form-label fw-semibold" for="password">Password</label>
        <input type="password" class="form-control" id="password" name="password" required>
      </div>
      <button type="submit" class="btn btn-maroon w-100">Sign In</button>
    </form>
    <div class="text-center mt-3">
      <a href="../index.php" class="small text-decoration-none">← Back to store</a>
    </div>
  </div>
</div>
</body>
</html>
