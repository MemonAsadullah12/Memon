<?php
// Admin sign-out: destroy the session and return to the login screen.
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/helpers.php';

if (function_exists('admin_logout')) {
    admin_logout();
} else {
    $_SESSION = [];
    if (session_status() === PHP_SESSION_ACTIVE) {
        session_destroy();
    }
}
redirect('login.php');
