<?php
require_once __DIR__ . '/../includes/auth.php';
require_admin('notifications.view');
require_once __DIR__ . '/_helpers.php';
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/helpers.php';

$db = db();
$page_title = 'Notifications';

// --- Mark read/unread ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && in_array($_POST['action'] ?? '', ['read', 'unread'], true)) {
    csrf_check();
    $nid = (int) ($_POST['id'] ?? 0);
    $db->prepare('UPDATE notifications SET is_read = ? WHERE id = ?')->execute([$_POST['action'] === 'read' ? 1 : 0, $nid]);
    redirect('notifications.php');
}
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'read_all') {
    csrf_check();
    $db->query('UPDATE notifications SET is_read = 1 WHERE is_read = 0');
    mff_flash('All notifications marked as read.');
    redirect('notifications.php');
}

// --- WhatsApp composer: builds a MANUAL click-to-chat link (nothing is auto-sent) ---
$waLink = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'whatsapp') {
    csrf_check();
    $number = preg_replace('/\D/', '', $_POST['number'] ?? '');
    $message = trim($_POST['message'] ?? '');
    if ($number === '' || $message === '') {
        mff_flash('A phone number and a message are required.', 'danger');
    } else {
        $waLink = 'https://wa.me/' . $number . '?text=' . urlencode($message);
        $db->prepare(
            "INSERT INTO notification_logs (channel, recipient, message, status, response)
             VALUES ('whatsapp_manual', ?, ?, 'manual', ?)"
        )->execute([$number, $message, $waLink]);
        mff_audit('notification.whatsapp_manual', 'notification_logs', (int) $db->lastInsertId(), null, ['recipient' => $number]);
        mff_flash('Link built below — click it to open WhatsApp manually. Nothing was sent automatically.');
    }
}

$type = $_GET['type'] ?? '';
$read = $_GET['read'] ?? '';
$where = [];
$params = [];
if ($type !== '') {
    $where[] = 'type = ?';
    $params[] = $type;
}
if ($read === '0') {
    $where[] = 'is_read = 0';
} elseif ($read === '1') {
    $where[] = 'is_read = 1';
}
$whereSql = $where ? 'WHERE ' . implode(' AND ', $where) : '';
$st = $db->prepare("SELECT COUNT(*) FROM notifications $whereSql");
$st->execute($params);
$total = (int) $st->fetchColumn();
$page = max(1, (int) ($_GET['page'] ?? 1));
$per = 20;
$offset = ($page - 1) * $per;
$st = $db->prepare("SELECT * FROM notifications $whereSql ORDER BY id DESC LIMIT $per OFFSET $offset");
$st->execute($params);
$rows = $st->fetchAll();
$types = $db->query('SELECT DISTINCT type FROM notifications ORDER BY type')->fetchAll(PDO::FETCH_COLUMN);
$logs = $db->query('SELECT * FROM notification_logs ORDER BY id DESC LIMIT 20')->fetchAll();
$recentCustomers = $db->query('SELECT DISTINCT customer_phone FROM orders ORDER BY id DESC LIMIT 30')->fetchAll(PDO::FETCH_COLUMN);

ob_start();
?>
<div class="row g-3">
  <div class="col-lg-7">
    <div class="card mb-3"><div class="card-header d-flex justify-content-between align-items-center">
      <span>Notifications</span>
      <form method="post" class="d-inline">
        <input type="hidden" name="csrf" value="<?= esc(csrf_token()) ?>">
        <input type="hidden" name="action" value="read_all">
        <button class="btn btn-sm btn-outline-secondary">Mark all read</button>
      </form>
    </div>
    <div class="card-body py-2">
      <form method="get" class="row g-2">
        <div class="col-5"><select name="type" class="form-select form-select-sm">
          <option value="">All types</option>
          <?php foreach ($types as $t): ?><option <?= $type === $t ? 'selected' : '' ?>><?= esc($t) ?></option><?php endforeach; ?>
        </select></div>
        <div class="col-4"><select name="read" class="form-select form-select-sm">
          <option value="">All</option>
          <option value="0" <?= $read === '0' ? 'selected' : '' ?>>Unread</option>
          <option value="1" <?= $read === '1' ? 'selected' : '' ?>>Read</option>
        </select></div>
        <div class="col-3"><button class="btn btn-sm btn-maroon w-100">Filter</button></div>
      </form>
    </div>
    <ul class="list-group list-group-flush">
      <?php if (!$rows): ?><li class="list-group-item text-muted">No notifications.</li><?php endif; ?>
      <?php foreach ($rows as $n): ?>
        <li class="list-group-item <?= $n['is_read'] ? '' : 'fw-bold' ?>" style="<?= $n['is_read'] ? '' : 'background:#FFF8E9;' ?>">
          <div class="d-flex justify-content-between">
            <div>
              <span class="badge bg-secondary"><?= esc($n['type']) ?></span>
              <?= esc($n['title']) ?><br>
              <small class="<?= $n['is_read'] ? 'text-muted' : '' ?>"><?= esc($n['message']) ?></small><br>
              <small class="text-muted"><?= esc(mff_date($n['created_at'])) ?></small>
              <?php if ($n['link']): ?> <a href="<?= esc($n['link']) ?>" class="small">Open →</a><?php endif; ?>
            </div>
            <form method="post">
              <input type="hidden" name="csrf" value="<?= esc(csrf_token()) ?>">
              <input type="hidden" name="action" value="<?= $n['is_read'] ? 'unread' : 'read' ?>">
              <input type="hidden" name="id" value="<?= (int) $n['id'] ?>">
              <button class="btn btn-sm btn-outline-secondary"><?= $n['is_read'] ? 'Mark unread' : 'Mark read' ?></button>
            </form>
          </div>
        </li>
      <?php endforeach; ?>
    </ul>
    <div class="card-body"><?= mff_pagination($total, $page, $per, 'notifications.php', ['type' => $type, 'read' => $read]) ?></div>
    </div>
  </div>

  <div class="col-lg-5">
    <div class="card mb-3"><div class="card-header">💬 Notify via WhatsApp <small class="text-muted">(manual click-to-chat)</small></div><div class="card-body">
      <p class="small text-muted">This builds a <code>wa.me</code> link. Clicking it opens WhatsApp with your message pre-filled — <strong>nothing is sent automatically</strong>. Each use is logged.</p>
      <form method="post">
        <input type="hidden" name="csrf" value="<?= esc(csrf_token()) ?>">
        <input type="hidden" name="action" value="whatsapp">
        <div class="mb-2"><label class="form-label required">Recipient number</label>
          <input type="text" name="number" class="form-control form-control-sm" required
                 list="recentNumbers" placeholder="e.g. 923003130608" value="<?= esc($_POST['number'] ?? '') ?>">
          <datalist id="recentNumbers"><?php foreach ($recentCustomers as $rn): ?><option value="<?= esc($rn) ?>"><?php endforeach; ?></datalist></div>
        <div class="mb-2"><label class="form-label required">Message</label>
          <textarea name="message" class="form-control form-control-sm" rows="4" required><?= esc($_POST['message'] ?? '') ?></textarea></div>
        <button class="btn btn-sm btn-success">Build WhatsApp link</button>
      </form>
      <?php if ($waLink): ?>
        <div class="alert alert-success mt-3">
          <strong>Your manual link:</strong><br>
          <a href="<?= esc($waLink) ?>" target="_blank" rel="noopener" class="btn btn-sm btn-success mt-2">📲 Open in WhatsApp</a>
          <div class="small mt-1 text-muted"><?= esc($waLink) ?></div>
        </div>
      <?php endif; ?>
    </div></div>

    <div class="card"><div class="card-header">Recent send log</div>
      <ul class="list-group list-group-flush small">
        <?php if (!$logs): ?><li class="list-group-item text-muted">Nothing logged yet.</li><?php endif; ?>
        <?php foreach ($logs as $l): ?>
          <li class="list-group-item"><span class="badge bg-info text-dark"><?= esc($l['channel']) ?></span>
            → <?= esc($l['recipient']) ?> <span class="text-muted">(<?= esc($l['status']) ?>)</span><br>
            <span class="text-muted"><?= esc(mb_substr($l['message'] ?? '', 0, 100)) ?></span></li>
        <?php endforeach; ?>
      </ul>
    </div>
  </div>
</div>
<?php
$content = ob_get_clean();
include __DIR__ . '/_layout.php';
