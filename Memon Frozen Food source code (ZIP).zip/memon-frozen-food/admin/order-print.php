<?php
// Printable order documents: receipt | kitchen | delivery. Auto-opens the print dialog.
require_once __DIR__ . '/../includes/auth.php';
require_admin('orders.print');
require_once __DIR__ . '/_helpers.php';
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/helpers.php';

$db = db();
$id = (int) ($_GET['id'] ?? 0);
$type = $_GET['type'] ?? 'receipt';
if (!in_array($type, ['receipt', 'kitchen', 'delivery'], true)) {
    $type = 'receipt';
}

$st = $db->prepare('SELECT * FROM orders WHERE id = ?');
$st->execute([$id]);
$o = $st->fetch();
if (!$o) {
    exit('Order not found.');
}
$items = $db->prepare('SELECT * FROM order_items WHERE order_id = ? ORDER BY id');
$items->execute([$id]);
$items = $items->fetchAll();

$titles = ['receipt' => 'Order Receipt', 'kitchen' => 'Kitchen Ticket', 'delivery' => 'Delivery Slip'];
$site = defined('SITE_NAME') ? SITE_NAME : 'Memon Frozen Food';
$phone = defined('ORDER_PHONE') ? ORDER_PHONE : '0300-3130608';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<title><?= esc($titles[$type]) ?> · <?= esc($o['order_number']) ?></title>
<style>
body{font-family:Arial,sans-serif;color:#222;max-width:700px;margin:0 auto;padding:20px;font-size:14px;}
h1{font-size:22px;margin:0;} h2{font-size:16px;margin:18px 0 8px;border-bottom:2px solid #970D0D;padding-bottom:4px;}
.brand{text-align:center;border-bottom:3px double #970D0D;padding-bottom:10px;margin-bottom:14px;}
.brand .tag{color:#970D0D;letter-spacing:3px;font-size:11px;font-weight:bold;}
table{width:100%;border-collapse:collapse;margin-top:8px;}
th,td{border:1px solid #ccc;padding:6px 8px;text-align:left;}
th{background:#f5f5f5;}
.num{text-align:right;}
.meta{display:flex;justify-content:space-between;gap:20px;}
.meta div{flex:1;}
.big{font-size:18px;font-weight:bold;}
@media print{.no-print{display:none;}}
</style>
</head>
<body onload="window.print()">
<div class="no-print" style="margin-bottom:12px;">
  <button onclick="window.print()">🖨️ Print / Save as PDF</button>
  <button onclick="window.close()">Close</button>
</div>

<div class="brand">
  <h1><?= esc($site) ?></h1>
  <div class="tag">HYGIENIC TASTE</div>
  <div>Khairpur Mirs · <?= esc($phone) ?></div>
  <h2 style="border:none;margin:10px 0 0;"><?= esc($titles[$type]) ?></h2>
</div>

<div class="meta">
  <div>
    <strong>Order:</strong> <?= esc($o['order_number']) ?><br>
    <strong>Date:</strong> <?= esc(mff_date($o['created_at'])) ?><br>
    <strong>Status:</strong> <?= esc(mff_status_label($o['order_status'])) ?>
  </div>
  <div>
    <strong><?= esc($o['customer_name']) ?></strong><br>
    <?= esc($o['customer_phone']) ?><br>
    <?= esc($o['delivery_address']) ?><br>
    <?= esc($o['area']) ?>, <?= esc($o['city']) ?>
    <?= $o['landmark'] ? '<br>Landmark: ' . esc($o['landmark']) : '' ?>
  </div>
</div>

<?php if ($type === 'kitchen'): ?>
  <h2>Items to prepare</h2>
  <table><thead><tr><th>#</th><th>Item</th><th>Pack</th><th class="num">Qty</th></tr></thead><tbody>
  <?php $n = 1;
  foreach ($items as $it): ?>
    <tr><td><?= $n++ ?></td><td><strong><?= esc($it['product_name_snapshot']) ?></strong></td>
    <td><?= esc($it['pack_size_snapshot'] ?? '') ?></td><td class="num"><strong><?= (int) $it['quantity'] ?></strong></td></tr>
  <?php endforeach; ?>
  </tbody></table>
  <?php if ($o['customer_notes']): ?><p><strong>Note:</strong> <?= esc($o['customer_notes']) ?></p><?php endif; ?>
<?php else: ?>
  <h2>Items</h2>
  <table><thead><tr><th>#</th><th>Item</th><th class="num">Qty</th>
  <?php if ($type === 'receipt'): ?><th class="num">Unit price</th><th class="num">Total</th><?php endif; ?>
  </tr></thead><tbody>
  <?php $n = 1;
  foreach ($items as $it): ?>
    <tr><td><?= $n++ ?></td><td><?= esc($it['product_name_snapshot']) ?><br><small><?= esc($it['pack_size_snapshot'] ?? '') ?></small></td>
    <td class="num"><?= (int) $it['quantity'] ?></td>
    <?php if ($type === 'receipt'): ?><td class="num"><?= esc(rs((int) $it['unit_price'])) ?></td><td class="num"><?= esc(rs((int) $it['line_total'])) ?></td><?php endif; ?>
    </tr>
  <?php endforeach; ?>
  </tbody></table>
  <?php if ($type === 'receipt'): ?>
    <table style="width:300px;margin-left:auto;">
      <tr><td>Subtotal</td><td class="num"><?= esc(rs((int) $o['subtotal'])) ?></td></tr>
      <tr><td>Discount</td><td class="num">− <?= esc(rs((int) $o['discount_amount'])) ?></td></tr>
      <tr><td>Delivery fee</td><td class="num"><?= esc(rs((int) $o['delivery_fee'])) ?></td></tr>
      <tr><td><strong>Total</strong></td><td class="num big"><?= esc(rs((int) $o['total_amount'])) ?></td></tr>
      <tr><td>Payment</td><td class="num"><?= esc($o['payment_method']) ?> (<?= esc(ucfirst($o['payment_status'])) ?>)</td></tr>
    </table>
  <?php else: ?>
    <h2>Delivery info</h2>
    <p><strong>Collect:</strong> <span class="big"><?= esc(rs((int) $o['total_amount'])) ?></span>
    (<?= esc($o['payment_method']) ?> · <?= esc(ucfirst($o['payment_status'])) ?>)</p>
  <?php endif; ?>
<?php endif; ?>

<p style="margin-top:24px;">Signature: ______________________</p>
<p class="no-print"><small>Printed <?= date('d M Y, h:i A') ?></small></p>
</body>
</html>
