<?php
require_once __DIR__ . '/../includes/auth.php';
require_admin('orders.view');
require_once __DIR__ . '/_helpers.php';
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/helpers.php';

$db = db();
$id = (int) ($_GET['id'] ?? 0);
$page_title = 'Order Details';
$canEdit = has_perm('orders.edit');

$st = $db->prepare('SELECT o.*, z.name AS zone_name FROM orders o LEFT JOIN delivery_zones z ON z.id = o.delivery_zone_id WHERE o.id = ?');
$st->execute([$id]);
$o = $st->fetch();
if (!$o) {
    mff_flash('Order not found.', 'danger');
    redirect('orders.php');
}
$page_title = 'Order ' . $o['order_number'];

$items = $db->prepare('SELECT * FROM order_items WHERE order_id = ? ORDER BY id');
$items->execute([$id]);
$items = $items->fetchAll();

$history = $db->prepare(
    'SELECT h.*, u.name AS admin_name FROM order_status_history h LEFT JOIN users u ON u.id = h.admin_id
     WHERE h.order_id = ? ORDER BY h.id ASC'
);
$history->execute([$id]);
$history = $history->fetchAll();

$pays = $db->prepare('SELECT p.*, u.name AS admin_name FROM payments p LEFT JOIN users u ON u.id = p.admin_id WHERE p.order_id = ? ORDER BY p.id');
$pays->execute([$id]);
$pays = $pays->fetchAll();
$paidTotal = array_sum(array_column(array_filter($pays, fn($x) => in_array($x['status'], ['received', 'pending'], true)), 'amount'));
$outstanding = (int) $o['total_amount'] - (int) $paidTotal;

$assign = $db->prepare('SELECT * FROM delivery_assignments WHERE order_id = ? ORDER BY id DESC LIMIT 1');
$assign->execute([$id]);
$assign = $assign->fetch();

// --- Status change ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'status' && $canEdit) {
    csrf_check();
    $to = $_POST['new_status'] ?? '';
    $note = trim($_POST['note'] ?? '');
    $from = $o['order_status'];
    if (!mff_can_transition($from, $to)) {
        mff_flash('Invalid status transition.', 'danger');
    } else {
        $db->beginTransaction();
        $db->prepare('UPDATE orders SET order_status = ? WHERE id = ?')->execute([$to, $id]);
        $db->prepare('INSERT INTO order_status_history (order_id, old_status, new_status, note, admin_id) VALUES (?,?,?,?,?)')
            ->execute([$id, $from, $to, $note, current_admin()['id'] ?? null]);
        // Sync delivery assignment timestamps
        if ($assign && in_array($to, ['out_for_delivery', 'delivered'], true)) {
            if ($to === 'out_for_delivery') {
                $db->prepare("UPDATE delivery_assignments SET status='dispatched', dispatched_at = COALESCE(dispatched_at, NOW()) WHERE id = ?")->execute([$assign['id']]);
            } else {
                $db->prepare("UPDATE delivery_assignments SET status='delivered', delivered_at = NOW() WHERE id = ?")->execute([$assign['id']]);
            }
        }
        $db->commit();
        mff_audit('order.status_change', 'orders', $id, ['order_status' => $from], ['order_status' => $to]);
        mff_flash('Order status changed to ' . mff_status_label($to) . '.');
    }
    redirect('order-view.php?id=' . $id);
}

// --- Edit permitted customer/delivery fields ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'details' && $canEdit) {
    csrf_check();
    $fields = ['customer_name', 'customer_phone', 'whatsapp_number', 'delivery_address', 'area', 'landmark', 'customer_notes'];
    $old = array_intersect_key($o, array_flip($fields));
    $new = [];
    foreach ($fields as $f) {
        $new[$f] = trim($_POST[$f] ?? '');
    }
    $set = implode(', ', array_map(fn($k) => "$k = ?", $fields));
    $db->prepare("UPDATE orders SET $set WHERE id = $id")->execute(array_values($new));
    mff_audit('order.details_update', 'orders', $id, $old, $new);
    mff_flash('Order details updated.');
    redirect('order-view.php?id=' . $id);
}

$targets = mff_transitions()[$o['order_status']] ?? [];
if ($canEdit && $targets) {
    $page_actions = '<a class="btn btn-sm btn-outline-secondary" href="order-print.php?id=' . $id . '&type=receipt" target="_blank">🧾 Receipt</a> '
        . '<a class="btn btn-sm btn-outline-secondary" href="order-print.php?id=' . $id . '&type=kitchen" target="_blank">👨‍🍳 Kitchen</a> '
        . '<a class="btn btn-sm btn-outline-secondary" href="order-print.php?id=' . $id . '&type=delivery" target="_blank">🛵 Delivery slip</a>';
} elseif (has_perm('orders.print')) {
    $page_actions = '<a class="btn btn-sm btn-outline-secondary" href="order-print.php?id=' . $id . '&type=receipt" target="_blank">🖨️ Print</a>';
}

ob_start();
?>
<div class="row g-3">
  <div class="col-lg-8">
    <div class="card mb-3"><div class="card-header d-flex justify-content-between">
      <span>Order <?= esc($o['order_number']) ?></span>
      <span><?= mff_status_badge($o['order_status']) ?> <?= mff_payment_badge($o['payment_status']) ?></span>
    </div><div class="card-body">
      <div class="row small mb-3">
        <div class="col-md-6"><strong>Placed:</strong> <?= esc(mff_date($o['created_at'])) ?><br>
          <strong>Payment method:</strong> <?= esc($o['payment_method']) ?><br>
          <strong>Delivery zone:</strong> <?= esc($o['zone_name'] ?? '—') ?></div>
        <div class="col-md-6"><strong>Tracking token:</strong> <code><?= esc($o['tracking_token'] ?? '—') ?></code><br>
          <strong>Customer notes:</strong> <?= esc($o['customer_notes'] ?: '—') ?></div>
      </div>
      <div class="table-responsive"><table class="table table-sm">
        <thead><tr><th>Item</th><th>SKU</th><th class="text-end">Qty</th><th class="text-end">Unit price</th><th class="text-end">Discount</th><th class="text-end">Line total</th></tr></thead>
        <tbody>
        <?php foreach ($items as $it): ?>
          <tr><td><?= esc($it['product_name_snapshot']) ?><br><small class="text-muted"><?= esc($it['pack_size_snapshot'] ?? '') ?></small></td>
          <td class="small"><?= esc($it['sku_snapshot'] ?? '') ?></td>
          <td class="text-end"><?= (int) $it['quantity'] ?></td>
          <td class="text-end"><?= esc(rs((int) $it['unit_price'])) ?></td>
          <td class="text-end"><?= esc(rs((int) $it['discount_amount'])) ?></td>
          <td class="text-end fw-bold"><?= esc(rs((int) $it['line_total'])) ?></td></tr>
        <?php endforeach; ?>
        </tbody>
        <tfoot>
          <tr><td colspan="5" class="text-end">Subtotal</td><td class="text-end"><?= esc(rs((int) $o['subtotal'])) ?></td></tr>
          <tr><td colspan="5" class="text-end">Discount</td><td class="text-end">− <?= esc(rs((int) $o['discount_amount'])) ?></td></tr>
          <tr><td colspan="5" class="text-end">Delivery fee</td><td class="text-end"><?= esc(rs((int) $o['delivery_fee'])) ?></td></tr>
          <tr><td colspan="5" class="text-end">Tax</td><td class="text-end"><?= esc(rs((int) $o['tax_amount'])) ?></td></tr>
          <tr class="fw-bold"><td colspan="5" class="text-end">Total</td><td class="text-end"><?= esc(rs((int) $o['total_amount'])) ?></td></tr>
          <tr><td colspan="5" class="text-end">Paid</td><td class="text-end text-success"><?= esc(rs((int) $paidTotal)) ?></td></tr>
          <tr><td colspan="5" class="text-end">Outstanding</td><td class="text-end <?= $outstanding > 0 ? 'text-danger fw-bold' : '' ?>"><?= esc(rs($outstanding)) ?></td></tr>
        </tfoot>
      </table></div>
    </div></div>

    <div class="card mb-3"><div class="card-header">Status timeline</div><div class="card-body">
      <div class="timeline">
        <?php foreach ($history as $h): ?>
          <div class="t-item">
            <strong><?= esc(mff_status_label($h['old_status'] ?? '')) ?> → <?= esc(mff_status_label($h['new_status'])) ?></strong>
            <small class="text-muted">· <?= esc(mff_date($h['created_at'])) ?> · <?= esc($h['admin_name'] ?? 'system') ?></small>
            <?php if ($h['note']): ?><br><span class="small"><?= esc($h['note']) ?></span><?php endif; ?>
          </div>
        <?php endforeach; ?>
        <?php if (!$history): ?><p class="text-muted small">No history yet.</p><?php endif; ?>
      </div>
    </div></div>

    <?php if ($pays): ?>
    <div class="card mb-3"><div class="card-header">Payments</div><div class="table-responsive"><table class="table table-sm mb-0">
      <thead><tr><th>Date</th><th class="text-end">Amount</th><th>Method</th><th>Reference</th><th>Status</th><th>By</th></tr></thead>
      <tbody><?php foreach ($pays as $py): ?><tr>
        <td class="small"><?= esc(mff_date($py['received_at'])) ?></td>
        <td class="text-end"><?= esc(rs((int) $py['amount'])) ?></td>
        <td><?= esc($py['method']) ?></td><td class="small"><?= esc($py['reference'] ?? '—') ?></td>
        <td><?= mff_payment_badge($py['status']) ?></td><td class="small"><?= esc($py['admin_name'] ?? '—') ?></td>
      </tr><?php endforeach; ?></tbody>
    </table></div></div>
    <?php endif; ?>
  </div>

  <div class="col-lg-4">
    <div class="card mb-3"><div class="card-header">Customer &amp; delivery</div><div class="card-body small">
      <?php if ($canEdit): ?>
      <form method="post">
        <input type="hidden" name="csrf" value="<?= esc(csrf_token()) ?>">
        <input type="hidden" name="action" value="details">
        <?php foreach (['customer_name' => 'Name', 'customer_phone' => 'Phone', 'whatsapp_number' => 'WhatsApp', 'delivery_address' => 'Address', 'area' => 'Area', 'landmark' => 'Landmark'] as $f => $lbl): ?>
          <div class="mb-2"><label class="form-label"><?= $lbl ?></label>
          <input type="text" name="<?= $f ?>" class="form-control form-control-sm" value="<?= esc($o[$f] ?? '') ?>"></div>
        <?php endforeach; ?>
        <div class="mb-2"><label class="form-label">Internal / customer notes</label>
          <textarea name="customer_notes" class="form-control form-control-sm" rows="2"><?= esc($o['customer_notes'] ?? '') ?></textarea></div>
        <button class="btn btn-sm btn-maroon">Save details</button>
      </form>
      <?php else: ?>
        <strong><?= esc($o['customer_name']) ?></strong><br><?= esc($o['customer_phone']) ?>
        <?php if ($o['whatsapp_number']): ?><br>WhatsApp: <?= esc($o['whatsapp_number']) ?><?php endif; ?>
        <hr><?= esc($o['delivery_address']) ?><br><?= esc($o['area']) ?>, <?= esc($o['city']) ?>
        <?php if ($o['landmark']): ?><br>Landmark: <?= esc($o['landmark']) ?><?php endif; ?>
      <?php endif; ?>
      <?php if ($assign): ?>
        <hr><strong>Delivery:</strong> <?= esc($assign['staff_name']) ?> (<?= esc($assign['staff_phone']) ?>)<br>
        <small class="text-muted">Status: <?= esc($assign['status']) ?></small>
      <?php endif; ?>
    </div></div>

    <?php if ($canEdit): ?>
    <div class="card mb-3"><div class="card-header">Change status</div><div class="card-body">
      <?php if ($targets): ?>
      <form method="post">
        <input type="hidden" name="csrf" value="<?= esc(csrf_token()) ?>">
        <input type="hidden" name="action" value="status">
        <div class="mb-2"><label class="form-label">New status</label>
          <select name="new_status" class="form-select form-select-sm" required>
            <?php foreach ($targets as $t): ?><option value="<?= $t ?>"><?= esc(mff_status_label($t)) ?></option><?php endforeach; ?>
          </select></div>
        <div class="mb-2"><label class="form-label">Note (optional)</label>
          <input type="text" name="note" class="form-control form-control-sm"></div>
        <button class="btn btn-sm btn-maroon">Update status</button>
      </form>
      <?php else: ?>
        <p class="text-muted small mb-0">This order is in a final state (<?= esc(mff_status_label($o['order_status'])) ?>).</p>
      <?php endif; ?>
    </div></div>
    <?php endif; ?>
  </div>
</div>
<?php
$content = ob_get_clean();
include __DIR__ . '/_layout.php';
