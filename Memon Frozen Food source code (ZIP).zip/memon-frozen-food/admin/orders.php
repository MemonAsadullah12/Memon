<?php
require_once __DIR__ . '/../includes/auth.php';
require_admin('orders.view');
require_once __DIR__ . '/_helpers.php';
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/helpers.php';

$db = db();
$page_title = 'Orders';

$status = $_GET['status'] ?? '';
$pmethod = $_GET['pmethod'] ?? '';
$dfrom = $_GET['dfrom'] ?? '';
$dto = $_GET['dto'] ?? '';
$q = trim($_GET['q'] ?? '');

$where = [];
$params = [];
if ($status !== '' && isset(mff_statuses()[$status])) {
    $where[] = 'o.order_status = ?';
    $params[] = $status;
}
if ($pmethod !== '') {
    $where[] = 'o.payment_method = ?';
    $params[] = $pmethod;
}
if ($dfrom !== '') {
    $where[] = 'DATE(o.created_at) >= ?';
    $params[] = $dfrom;
}
if ($dto !== '') {
    $where[] = 'DATE(o.created_at) <= ?';
    $params[] = $dto;
}
if ($q !== '') {
    $where[] = '(o.order_number LIKE ? OR o.customer_name LIKE ? OR o.customer_phone LIKE ?)';
    $params[] = "%$q%";
    $params[] = "%$q%";
    $params[] = "%$q%";
}
$whereSql = $where ? 'WHERE ' . implode(' AND ', $where) : '';

$st = $db->prepare("SELECT COUNT(*) FROM orders o $whereSql");
$st->execute($params);
$total = (int) $st->fetchColumn();
$page = max(1, (int) ($_GET['page'] ?? 1));
$per = 20;
$offset = ($page - 1) * $per;

$st = $db->prepare(
    "SELECT o.id, o.order_number, o.customer_name, o.customer_phone, o.total_amount,
            o.payment_method, o.payment_status, o.order_status, o.created_at,
            (SELECT COUNT(*) FROM order_items WHERE order_id = o.id) AS items
     FROM orders o $whereSql ORDER BY o.id DESC LIMIT $per OFFSET $offset"
);
$st->execute($params);
$orders = $st->fetchAll();
$pms = $db->query('SELECT DISTINCT payment_method FROM orders ORDER BY payment_method')->fetchAll(PDO::FETCH_COLUMN);

ob_start();
?>
<div class="card mb-3"><div class="card-body">
  <form method="get" class="row g-2">
    <div class="col-md-2"><select name="status" class="form-select form-select-sm">
      <option value="">All statuses</option>
      <?php foreach (mff_statuses() as $code => $label): ?><option value="<?= $code ?>" <?= $status === $code ? 'selected' : '' ?>><?= esc($label) ?></option><?php endforeach; ?>
    </select></div>
    <div class="col-md-2"><select name="pmethod" class="form-select form-select-sm">
      <option value="">All payment methods</option>
      <?php foreach ($pms as $pm): ?><option <?= $pmethod === $pm ? 'selected' : '' ?>><?= esc($pm) ?></option><?php endforeach; ?>
    </select></div>
    <div class="col-md-2"><input type="date" name="dfrom" class="form-control form-control-sm" value="<?= esc($dfrom) ?>"></div>
    <div class="col-md-2"><input type="date" name="dto" class="form-control form-control-sm" value="<?= esc($dto) ?>"></div>
    <div class="col-md-3"><input type="text" name="q" class="form-control form-control-sm" placeholder="Order no / name / phone…" value="<?= esc($q) ?>"></div>
    <div class="col-md-1"><button class="btn btn-sm btn-maroon w-100">Go</button></div>
  </form>
</div></div>

<div class="card"><div class="table-responsive"><table class="table table-sm table-hover mb-0">
  <thead><tr><th>Order</th><th>Date</th><th>Customer</th><th class="text-end">Items</th><th class="text-end">Total</th><th>Payment</th><th>Status</th><th></th></tr></thead>
  <tbody>
  <?php if (!$orders): ?><tr><td colspan="8" class="text-center text-muted py-4">No orders found.</td></tr><?php endif; ?>
  <?php foreach ($orders as $o): ?>
    <tr>
      <td><strong><?= esc($o['order_number']) ?></strong></td>
      <td class="small"><?= esc(mff_date($o['created_at'])) ?></td>
      <td><?= esc($o['customer_name']) ?><br><small class="text-muted"><?= esc($o['customer_phone']) ?></small></td>
      <td class="text-end"><?= (int) $o['items'] ?></td>
      <td class="text-end fw-bold"><?= esc(rs((int) $o['total_amount'])) ?></td>
      <td class="small"><?= esc($o['payment_method']) ?><br><?= mff_payment_badge($o['payment_status']) ?></td>
      <td><?= mff_status_badge($o['order_status']) ?></td>
      <td><a href="order-view.php?id=<?= (int) $o['id'] ?>" class="btn btn-sm btn-outline-secondary">View</a></td>
    </tr>
  <?php endforeach; ?>
  </tbody>
</table></div></div>
<div class="mt-2"><?= mff_pagination($total, $page, $per, 'orders.php', ['status' => $status, 'pmethod' => $pmethod, 'dfrom' => $dfrom, 'dto' => $dto, 'q' => $q]) ?></div>
<?php
$content = ob_get_clean();
include __DIR__ . '/_layout.php';
