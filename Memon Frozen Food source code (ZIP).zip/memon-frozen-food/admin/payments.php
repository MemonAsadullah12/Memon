<?php
require_once __DIR__ . '/../includes/auth.php';
require_admin('payments.view');
require_once __DIR__ . '/_helpers.php';
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/helpers.php';

$db = db();
$page_title = 'Payments';
$canEdit = has_perm('payments.edit');

// --- Record a payment (never collects card numbers/CVVs) ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'record' && $canEdit) {
    csrf_check();
    $orderId = (int) ($_POST['order_id'] ?? 0);
    $amount = (int) ($_POST['amount'] ?? 0);
    $method = $_POST['method'] ?? '';
    $reference = trim($_POST['reference'] ?? '');
    $notes = trim($_POST['notes'] ?? '');
    $methods = ['COD', 'Bank Transfer', 'Easypaisa', 'JazzCash', 'Other'];
    try {
        if ($orderId <= 0 || $amount <= 0 || !in_array($method, $methods, true)) {
            throw new RuntimeException('Order, a positive amount and a valid method are required.');
        }
        $o = $db->query('SELECT id, order_number, total_amount FROM orders WHERE id = ' . $orderId)->fetch();
        if (!$o) {
            throw new RuntimeException('Order not found.');
        }
        $outstanding = mff_order_outstanding($db, $orderId);
        if ($amount > $outstanding) {
            throw new RuntimeException('Amount exceeds the outstanding balance of ' . rs($outstanding) . '.');
        }
        $db->prepare(
            "INSERT INTO payments (order_id, amount, method, reference, status, received_at, admin_id, notes)
             VALUES (?, ?, ?, ?, 'received', NOW(), ?, ?)"
        )->execute([$orderId, $amount, $method, $reference ?: null, current_admin()['id'] ?? null, $notes ?: null]);
        // Update order payment_status
        $newOutstanding = $outstanding - $amount;
        $pstatus = $newOutstanding <= 0 ? 'paid' : ($newOutstanding < (int) $o['total_amount'] ? 'partial' : 'pending');
        $db->prepare('UPDATE orders SET payment_status = ? WHERE id = ?')->execute([$pstatus, $orderId]);
        mff_audit('payment.record', 'payments', (int) $db->lastInsertId(), null, ['order_id' => $orderId, 'amount' => $amount, 'method' => $method]);
        mff_flash('Payment of ' . rs($amount) . ' recorded for ' . $o['order_number'] . '.');
    } catch (Throwable $e) {
        mff_flash($e->getMessage(), 'danger');
    }
    redirect('payments.php');
}

$method = $_GET['method'] ?? '';
$dfrom = $_GET['dfrom'] ?? '';
$dto = $_GET['dto'] ?? '';
$where = [];
$params = [];
if ($method !== '') {
    $where[] = 'p.method = ?';
    $params[] = $method;
}
if ($dfrom !== '') {
    $where[] = 'DATE(p.received_at) >= ?';
    $params[] = $dfrom;
}
if ($dto !== '') {
    $where[] = 'DATE(p.received_at) <= ?';
    $params[] = $dto;
}
$whereSql = $where ? 'WHERE ' . implode(' AND ', $where) : '';

$st = $db->prepare("SELECT COUNT(*) FROM payments p $whereSql");
$st->execute($params);
$total = (int) $st->fetchColumn();
$page = max(1, (int) ($_GET['page'] ?? 1));
$per = 20;
$offset = ($page - 1) * $per;

$st = $db->prepare(
    "SELECT p.*, o.order_number, u.name AS admin_name FROM payments p
     JOIN orders o ON o.id = p.order_id LEFT JOIN users u ON u.id = p.admin_id
     $whereSql ORDER BY p.id DESC LIMIT $per OFFSET $offset"
);
$st->execute($params);
$rows = $st->fetchAll();

$st = $db->prepare('SELECT COALESCE(SUM(amount),0) FROM payments p ' . ($whereSql ? $whereSql . ' AND' : 'WHERE') . " p.status = 'received'");
$st->execute($params);
$collected = (int) $st->fetchColumn();

// Orders with outstanding balance (for the record-payment dropdown)
$openOrders = $db->query(
    "SELECT o.id, o.order_number, o.customer_name,
            o.total_amount - COALESCE((SELECT SUM(amount) FROM payments WHERE order_id = o.id AND status IN ('received','pending')),0) AS outstanding
     FROM orders o
     WHERE o.order_status NOT IN ('cancelled','returned')
     HAVING outstanding > 0 ORDER BY o.id DESC LIMIT 100"
)->fetchAll();

ob_start();
?>
<div class="alert alert-info">Total collected (filtered): <strong><?= esc(rs($collected)) ?></strong>. Payments are recorded manually here — online payments are never marked successful from a form or receipt upload.</div>

<?php if ($canEdit && $openOrders): ?>
<div class="card mb-3"><div class="card-header">Record payment</div><div class="card-body">
  <form method="post" class="row g-2">
    <input type="hidden" name="csrf" value="<?= esc(csrf_token()) ?>">
    <input type="hidden" name="action" value="record">
    <div class="col-md-3"><label class="form-label required">Order</label>
      <select name="order_id" class="form-select form-select-sm" required>
        <option value="">— Select order —</option>
        <?php foreach ($openOrders as $oo): ?><option value="<?= (int) $oo['id'] ?>"><?= esc($oo['order_number']) ?> · <?= esc($oo['customer_name']) ?> · owes <?= esc(rs((int) $oo['outstanding'])) ?></option><?php endforeach; ?>
      </select></div>
    <div class="col-md-2"><label class="form-label required">Amount (Rs)</label>
      <input type="number" name="amount" class="form-control form-control-sm" min="1" required></div>
    <div class="col-md-2"><label class="form-label required">Method</label>
      <select name="method" class="form-select form-select-sm" required>
        <option>COD</option><option>Bank Transfer</option><option>Easypaisa</option><option>JazzCash</option><option>Other</option>
      </select></div>
    <div class="col-md-2"><label class="form-label">Reference</label>
      <input type="text" name="reference" class="form-control form-control-sm" placeholder="Txn ID / receipt no."></div>
    <div class="col-md-2"><label class="form-label">Notes</label>
      <input type="text" name="notes" class="form-control form-control-sm"></div>
    <div class="col-md-1 d-flex align-items-end"><button class="btn btn-sm btn-maroon w-100">Record</button></div>
  </form>
</div></div>
<?php endif; ?>

<div class="card mb-3"><div class="card-body">
  <form method="get" class="row g-2">
    <div class="col-md-3"><select name="method" class="form-select form-select-sm">
      <option value="">All methods</option>
      <?php foreach (['COD', 'Bank Transfer', 'Easypaisa', 'JazzCash', 'Other'] as $m): ?><option <?= $method === $m ? 'selected' : '' ?>><?= $m ?></option><?php endforeach; ?>
    </select></div>
    <div class="col-md-3"><input type="date" name="dfrom" class="form-control form-control-sm" value="<?= esc($dfrom) ?>"></div>
    <div class="col-md-3"><input type="date" name="dto" class="form-control form-control-sm" value="<?= esc($dto) ?>"></div>
    <div class="col-md-2"><button class="btn btn-sm btn-maroon w-100">Filter</button></div>
  </form>
</div></div>

<div class="card"><div class="table-responsive"><table class="table table-sm mb-0">
  <thead><tr><th>Date</th><th>Order</th><th class="text-end">Amount</th><th>Method</th><th>Reference</th><th>Status</th><th>Recorded by</th><th>Notes</th></tr></thead>
  <tbody>
  <?php if (!$rows): ?><tr><td colspan="8" class="text-center text-muted py-4">No payments found.</td></tr><?php endif; ?>
  <?php foreach ($rows as $r): ?>
    <tr>
      <td class="small"><?= esc(mff_date($r['received_at'])) ?></td>
      <td><a href="order-view.php?id=<?= (int) $r['order_id'] ?>"><?= esc($r['order_number']) ?></a></td>
      <td class="text-end fw-bold"><?= esc(rs((int) $r['amount'])) ?></td>
      <td><?= esc($r['method']) ?></td>
      <td class="small"><?= esc($r['reference'] ?? '—') ?></td>
      <td><?= mff_payment_badge($r['status']) ?></td>
      <td class="small"><?= esc($r['admin_name'] ?? '—') ?></td>
      <td class="small"><?= esc($r['notes'] ?? '—') ?></td>
    </tr>
  <?php endforeach; ?>
  </tbody>
</table></div></div>
<div class="mt-2"><?= mff_pagination($total, $page, $per, 'payments.php', ['method' => $method, 'dfrom' => $dfrom, 'dto' => $dto]) ?></div>
<?php
$content = ob_get_clean();
include __DIR__ . '/_layout.php';
