<?php
$id = (int) ($_GET['id'] ?? 0);
require_once __DIR__ . '/../includes/auth.php';
require_admin($id > 0 ? 'products.edit' : 'products.create');
require_once __DIR__ . '/_helpers.php';
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/helpers.php';

$db = db();
$page_title = $id > 0 ? 'Edit Product' : 'Add Product';

$p = $id > 0 ? $db->query('SELECT * FROM products WHERE id = ' . $id)->fetch() : null;
if ($id > 0 && !$p) {
    mff_flash('Product not found.', 'danger');
    redirect('products.php');
}

// Delete a gallery image (POST only, CSRF-protected)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'delimg') {
    csrf_check();
    $gi = (int) ($_POST['image_id'] ?? 0);
    $grow = $db->query('SELECT * FROM product_images WHERE id = ' . $gi . ' AND product_id = ' . $id)->fetch();
    if ($grow) {
        $db->prepare('DELETE FROM product_images WHERE id = ?')->execute([$gi]);
        @unlink(dirname(__DIR__) . '/' . $grow['image']);
        mff_audit('product.image_delete', 'product_images', $gi, $grow['image'], null);
        mff_flash('Gallery image removed.');
    }
    redirect('product-form.php' . ($id ? '?id=' . $id : ''));
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    try {
        $name = trim($_POST['name'] ?? '');
        if ($name === '') {
            throw new RuntimeException('Product name is required.');
        }
        $sku = trim($_POST['sku'] ?? '');
        if ($sku === '') {
            $sku = 'MFF-' . strtoupper(substr(bin2hex(random_bytes(3)), 0, 6));
        }
        $st = $db->prepare('SELECT id FROM products WHERE sku = ?' . ($id ? ' AND id <> ' . $id : '') . ' LIMIT 1');
        $st->execute([$sku]);
        if ($st->fetch()) {
            throw new RuntimeException('SKU already exists.');
        }
        $slug = mff_unique_slug($db, 'products', mff_slug(($_POST['slug'] ?? '') ?: $name), $id ?: null);

        $data = [
            'sku' => $sku,
            'category_id' => (int) ($_POST['category_id'] ?? 0) ?: null,
            'name' => $name,
            'slug' => $slug,
            'description' => trim($_POST['description'] ?? ''),
            'ingredients' => trim($_POST['ingredients'] ?? ''),
            'allergen_information' => trim($_POST['allergen_information'] ?? ''),
            'pack_size' => trim($_POST['pack_size'] ?? ''),
            'pieces_per_pack' => (int) ($_POST['pieces_per_pack'] ?? 0) ?: null,
            'cost_price' => ($_POST['cost_price'] ?? '') === '' ? null : (int) $_POST['cost_price'],
            'selling_price' => (int) ($_POST['selling_price'] ?? 0),
            'discount_price' => ($_POST['discount_price'] ?? '') === '' ? null : (int) $_POST['discount_price'],
            'stock_quantity' => max(0, (int) ($_POST['stock_quantity'] ?? 0)),
            'low_stock_threshold' => max(0, (int) ($_POST['low_stock_threshold'] ?? 5)),
            'is_featured' => isset($_POST['is_featured']) ? 1 : 0,
            'is_bestseller' => isset($_POST['is_bestseller']) ? 1 : 0,
            'is_active' => isset($_POST['is_active']) ? 1 : 0,
        ];
        if ($data['selling_price'] <= 0) {
            throw new RuntimeException('Selling price must be greater than zero.');
        }

        // Main image upload
        if (!empty($_FILES['image']['name'])) {
            $data['image'] = mff_upload_image($_FILES['image'], 'products');
        }

        $db->beginTransaction();
        if ($id > 0) {
            $oldPrice = (int) $p['selling_price'];
            $oldStock = (int) $p['stock_quantity'];
            $set = implode(', ', array_map(fn($k) => "$k = ?", array_keys($data)));
            $st = $db->prepare("UPDATE products SET $set, updated_at = NOW() WHERE id = $id");
            $st->execute(array_values($data));
            // Keep inventory mirror in sync when stock edited here
            if ($data['stock_quantity'] !== $oldStock) {
                $db->prepare('INSERT INTO inventory (product_id, quantity) VALUES (?, ?) ON DUPLICATE KEY UPDATE quantity = ?')
                    ->execute([$id, $data['stock_quantity'], $data['stock_quantity']]);
                $db->prepare(
                    "INSERT INTO stock_movements (product_id, change_qty, movement_type, reference_type, notes, admin_id)
                     VALUES (?, ?, 'adjustment', 'manual', ?, ?)"
                )->execute([$id, $data['stock_quantity'] - $oldStock, 'Stock edited on product form', current_admin()['id'] ?? null]);
            }
            if ($data['selling_price'] !== $oldPrice) {
                mff_audit('product.price_change', 'products', $id, ['selling_price' => $oldPrice], ['selling_price' => $data['selling_price']]);
            }
            if ($data['stock_quantity'] !== $oldStock) {
                mff_audit('product.stock_change', 'products', $id, ['stock_quantity' => $oldStock], ['stock_quantity' => $data['stock_quantity']]);
            }
            mff_audit('product.update', 'products', $id, $p['name'], $data['name']);
            $pid = $id;
            mff_flash('Product updated.');
        } else {
            $cols = implode(', ', array_keys($data));
            $ph = implode(', ', array_fill(0, count($data), '?'));
            $st = $db->prepare("INSERT INTO products ($cols) VALUES ($ph)");
            $st->execute(array_values($data));
            $pid = (int) $db->lastInsertId();
            $db->prepare('INSERT INTO inventory (product_id, quantity) VALUES (?, ?) ON DUPLICATE KEY UPDATE quantity = ?')
                ->execute([$pid, $data['stock_quantity'], $data['stock_quantity']]);
            mff_audit('product.create', 'products', $pid, null, $data['name']);
            mff_flash('Product added.');
        }

        // Gallery uploads
        if (!empty($_FILES['gallery']['name'][0])) {
            $maxSort = (int) $db->query('SELECT COALESCE(MAX(sort_order),0) FROM product_images WHERE product_id = ' . $pid)->fetchColumn();
            foreach ($_FILES['gallery']['name'] as $i => $gname) {
                if (!$gname) {
                    continue;
                }
                $gf = ['name' => $gname, 'type' => $_FILES['gallery']['type'][$i], 'tmp_name' => $_FILES['gallery']['tmp_name'][$i], 'error' => $_FILES['gallery']['error'][$i], 'size' => $_FILES['gallery']['size'][$i]];
                try {
                    $gpath = mff_upload_image($gf, 'products');
                    if ($gpath) {
                        $db->prepare('INSERT INTO product_images (product_id, image, sort_order) VALUES (?,?,?)')
                            ->execute([$pid, $gpath, ++$maxSort]);
                    }
                } catch (RuntimeException $e) {
                }
            }
        }
        $db->commit();
        redirect('products.php');
    } catch (Throwable $e) {
        if ($db->inTransaction()) {
            $db->rollBack();
        }
        mff_flash($e->getMessage(), 'danger');
    }
}

$categories = $db->query('SELECT id, name FROM categories WHERE is_active = 1 ORDER BY sort_order, name')->fetchAll();
$gallery = $id ? $db->query('SELECT * FROM product_images WHERE product_id = ' . $id . ' ORDER BY sort_order')->fetchAll() : [];
$v = fn($k, $d = '') => esc($_POST[$k] ?? $p[$k] ?? $d);

ob_start();
?>
<form method="post" enctype="multipart/form-data">
<input type="hidden" name="csrf" value="<?= esc(csrf_token()) ?>">
<div class="row g-3">
  <div class="col-lg-8">
    <div class="card mb-3"><div class="card-header">Basic info</div><div class="card-body">
      <div class="row g-2">
        <div class="col-md-8"><label class="form-label required">Product name</label>
          <input type="text" name="name" class="form-control" required value="<?= $v('name') ?>"></div>
        <div class="col-md-4"><label class="form-label">SKU</label>
          <input type="text" name="sku" class="form-control" placeholder="Auto if blank" value="<?= $v('sku') ?>"></div>
        <div class="col-md-6"><label class="form-label">Category</label>
          <select name="category_id" class="form-select"><option value="0">— None —</option>
          <?php foreach ($categories as $c): ?><option value="<?= (int) $c['id'] ?>" <?= (int) ($p['category_id'] ?? 0) === (int) $c['id'] ? 'selected' : '' ?>><?= esc($c['name']) ?></option><?php endforeach; ?>
          </select></div>
        <div class="col-md-6"><label class="form-label">URL slug</label>
          <input type="text" name="slug" class="form-control" placeholder="Auto from name" value="<?= $v('slug') ?>"></div>
        <div class="col-12"><label class="form-label">Description</label>
          <textarea name="description" class="form-control" rows="3"><?= $v('description') ?></textarea></div>
        <div class="col-md-6"><label class="form-label">Ingredients</label>
          <textarea name="ingredients" class="form-control" rows="2"><?= $v('ingredients') ?></textarea></div>
        <div class="col-md-6"><label class="form-label">Allergen information</label>
          <textarea name="allergen_information" class="form-control" rows="2"><?= $v('allergen_information') ?></textarea></div>
      </div>
    </div></div>
    <div class="card mb-3"><div class="card-header">Pricing &amp; stock</div><div class="card-body">
      <div class="row g-2">
        <div class="col-md-3"><label class="form-label">Pack size</label>
          <input type="text" name="pack_size" class="form-control" placeholder="e.g. 1 kg pack" value="<?= $v('pack_size') ?>"></div>
        <div class="col-md-3"><label class="form-label">Pieces per pack</label>
          <input type="number" name="pieces_per_pack" class="form-control" min="0" value="<?= $v('pieces_per_pack') ?>"></div>
        <div class="col-md-2"><label class="form-label">Cost price (Rs)</label>
          <input type="number" name="cost_price" class="form-control" min="0" value="<?= $v('cost_price') ?>"></div>
        <div class="col-md-2"><label class="form-label required">Selling price (Rs)</label>
          <input type="number" name="selling_price" class="form-control" min="1" required value="<?= $v('selling_price') ?>"></div>
        <div class="col-md-2"><label class="form-label">Discount price (Rs)</label>
          <input type="number" name="discount_price" class="form-control" min="0" value="<?= $v('discount_price') ?>"></div>
        <div class="col-md-3"><label class="form-label">Stock quantity</label>
          <input type="number" name="stock_quantity" class="form-control" min="0" value="<?= $v('stock_quantity', '0') ?>"></div>
        <div class="col-md-3"><label class="form-label">Low-stock threshold</label>
          <input type="number" name="low_stock_threshold" class="form-control" min="0" value="<?= $v('low_stock_threshold', '5') ?>"></div>
      </div>
    </div></div>
  </div>
  <div class="col-lg-4">
    <div class="card mb-3"><div class="card-header">Images</div><div class="card-body">
      <?php if (!empty($p['image'])): ?><img src="../<?= esc($p['image']) ?>" class="img-fluid rounded mb-2" alt=""><?php endif; ?>
      <label class="form-label">Main image (JPG/PNG/WebP, ≤2MB)</label>
      <input type="file" name="image" class="form-control mb-2" accept=".jpg,.jpeg,.png,.webp">
      <label class="form-label">Gallery (multiple)</label>
      <input type="file" name="gallery[]" class="form-control" multiple accept=".jpg,.jpeg,.png,.webp">
      <?php if ($gallery): ?><div class="d-flex flex-wrap gap-2 mt-2">
        <?php foreach ($gallery as $g): ?>
          <div class="position-relative"><img src="../<?= esc($g['image']) ?>" class="thumb" style="width:60px;height:60px;" alt="">
          <form method="post" class="position-absolute top-0 end-0" onsubmit="return confirm('Remove this image?')">
            <input type="hidden" name="csrf" value="<?= esc(csrf_token()) ?>">
            <input type="hidden" name="action" value="delimg">
            <input type="hidden" name="image_id" value="<?= (int) $g['id'] ?>">
            <button class="btn btn-sm btn-danger py-0 px-1">×</button>
          </form></div>
        <?php endforeach; ?>
      </div><?php endif; ?>
    </div></div>
    <div class="card mb-3"><div class="card-header">Visibility</div><div class="card-body">
      <?php foreach (['is_featured' => '⭐ Featured', 'is_bestseller' => '🏆 Bestseller', 'is_active' => '✅ Active (visible in shop)'] as $f => $lbl): ?>
        <div class="form-check mb-2"><input type="checkbox" name="<?= $f ?>" id="f_<?= $f ?>" class="form-check-input" <?= ($p[$f] ?? ($f === 'is_active' ? 1 : 0)) ? 'checked' : '' ?>>
        <label class="form-check-label" for="f_<?= $f ?>"><?= $lbl ?></label></div>
      <?php endforeach; ?>
    </div></div>
    <button class="btn btn-maroon w-100 mb-2"><?= $id ? 'Save changes' : 'Add product' ?></button>
    <a href="products.php" class="btn btn-outline-secondary w-100">Cancel</a>
  </div>
</div>
</form>
<?php
$content = ob_get_clean();
include __DIR__ . '/_layout.php';
