<?php
require_once __DIR__ . '/../includes/auth.php';
require_admin('products.view');
require_once __DIR__ . '/_helpers.php';
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/helpers.php';

$db = db();
$page_title = 'Products';
$canEdit = has_perm('products.edit');
$canCreate = has_perm('products.create');
$canDelete = has_perm('products.delete');

// --- Toggle flags (featured/bestseller/active) ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'toggle' && $canEdit) {
    csrf_check();
    $id = (int) ($_POST['id'] ?? 0);
    $field = $_POST['field'] ?? '';
    if ($id > 0 && in_array($field, ['is_featured', 'is_bestseller', 'is_active'], true)) {
        $old = $db->query('SELECT ' . $field . ' FROM products WHERE id = ' . $id)->fetchColumn();
        $db->prepare("UPDATE products SET $field = 1 - $field, updated_at = NOW() WHERE id = ?")->execute([$id]);
        mff_audit('product.toggle', 'products', $id, [$field => (int) $old], [$field => 1 - (int) $old]);
        mff_flash('Product updated.');
    }
    redirect('products.php');
}

// --- Delete (blocked if order items exist) ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'delete' && $canDelete) {
    csrf_check();
    $id = (int) ($_POST['id'] ?? 0);
    $st = $db->prepare('SELECT COUNT(*) FROM order_items WHERE product_id = ?');
    $st->execute([$id]);
    if ((int) $st->fetchColumn() > 0) {
        mff_flash('Cannot delete: this product exists in orders. Deactivate it instead.', 'danger');
    } else {
        $p = $db->query('SELECT name, sku FROM products WHERE id = ' . $id)->fetch();
        $db->prepare('DELETE FROM products WHERE id = ?')->execute([$id]);
        mff_audit('product.delete', 'products', $id, $p, null);
        mff_flash('Product deleted.');
    }
    redirect('products.php');
}

// --- CSV export ---
if (isset($_GET['export']) && $_GET['export'] === 'csv') {
    require_admin('products.export');
    $rows = $db->query(
        'SELECT p.id, p.sku, p.name, c.name AS category, p.pack_size, p.pieces_per_pack,
                p.cost_price, p.selling_price, p.discount_price, p.stock_quantity, p.is_active
         FROM products p LEFT JOIN categories c ON c.id = p.category_id ORDER BY p.name'
    )->fetchAll();
    mff_csv_download('products-' . date('Ymd') . '.csv',
        ['ID', 'SKU', 'Name', 'Category', 'Pack size', 'Pieces', 'Cost', 'Price', 'Discount price', 'Stock', 'Active'],
        array_map(fn($r) => [$r['id'], $r['sku'], $r['name'], $r['category'], $r['pack_size'], $r['pieces_per_pack'], $r['cost_price'], $r['selling_price'], $r['discount_price'], $r['stock_quantity'], $r['is_active']], $rows));
}

// --- Filters ---
$q = trim($_GET['q'] ?? '');
$cat = (int) ($_GET['category'] ?? 0);
$active = $_GET['active'] ?? 'all';
$sort = $_GET['sort'] ?? 'newest';
$sorts = ['newest' => 'p.id DESC', 'name' => 'p.name ASC', 'price_asc' => 'p.selling_price ASC', 'price_desc' => 'p.selling_price DESC', 'stock' => 'p.stock_quantity ASC'];
$orderBy = $sorts[$sort] ?? $sorts['newest'];

$where = [];
$params = [];
if ($q !== '') {
    $where[] = '(p.name LIKE ? OR p.sku LIKE ?)';
    $params[] = "%$q%";
    $params[] = "%$q%";
}
if ($cat > 0) {
    $where[] = 'p.category_id = ?';
    $params[] = $cat;
}
if ($active === '1') {
    $where[] = 'p.is_active = 1';
} elseif ($active === '0') {
    $where[] = 'p.is_active = 0';
}
$whereSql = $where ? 'WHERE ' . implode(' AND ', $where) : '';

$st = $db->prepare("SELECT COUNT(*) FROM products p $whereSql");
$st->execute($params);
$total = (int) $st->fetchColumn();
$page = max(1, (int) ($_GET['page'] ?? 1));
$per = 20;
$offset = ($page - 1) * $per;

$st = $db->prepare(
    "SELECT p.*, c.name AS category_name FROM products p
     LEFT JOIN categories c ON c.id = p.category_id
     $whereSql ORDER BY $orderBy LIMIT $per OFFSET $offset"
);
$st->execute($params);
$products = $st->fetchAll();
$categories = $db->query('SELECT id, name FROM categories ORDER BY sort_order, name')->fetchAll();

if ($canCreate) {
    $page_actions = '<a href="product-form.php" class="btn btn-sm btn-maroon">+ Add Product</a> '
        . (has_perm('products.export') ? '<a href="products.php?export=csv" class="btn btn-sm btn-outline-secondary">Export CSV</a>' : '');
}

ob_start();
?>
<div class="card mb-3"><div class="card-body">
  <form method="get" class="row g-2">
    <div class="col-md-4"><input type="text" name="q" class="form-control form-control-sm" placeholder="Search name or SKU…" value="<?= esc($q) ?>"></div>
    <div class="col-md-3"><select name="category" class="form-select form-select-sm">
      <option value="0">All categories</option>
      <?php foreach ($categories as $c): ?><option value="<?= (int) $c['id'] ?>" <?= $cat === (int) $c['id'] ? 'selected' : '' ?>><?= esc($c['name']) ?></option><?php endforeach; ?>
    </select></div>
    <div class="col-md-2"><select name="active" class="form-select form-select-sm">
      <option value="all" <?= $active === 'all' ? 'selected' : '' ?>>All statuses</option>
      <option value="1" <?= $active === '1' ? 'selected' : '' ?>>Active</option>
      <option value="0" <?= $active === '0' ? 'selected' : '' ?>>Inactive</option>
    </select></div>
    <div class="col-md-2"><select name="sort" class="form-select form-select-sm">
      <?php foreach (['newest' => 'Newest', 'name' => 'Name A–Z', 'price_asc' => 'Price ↑', 'price_desc' => 'Price ↓', 'stock' => 'Lowest stock'] as $k => $l): ?>
        <option value="<?= $k ?>" <?= $sort === $k ? 'selected' : '' ?>><?= $l ?></option>
      <?php endforeach; ?>
    </select></div>
    <div class="col-md-1"><button class="btn btn-sm btn-maroon w-100">Go</button></div>
  </form>
</div></div>

<div class="card"><div class="table-responsive"><table class="table table-sm table-hover mb-0">
  <thead><tr><th></th><th>Product</th><th>SKU</th><th>Category</th><th class="text-end">Price</th><th class="text-end">Discount</th><th class="text-end">Stock</th><th>Flags</th><th></th></tr></thead>
  <tbody>
  <?php if (!$products): ?><tr><td colspan="9" class="text-center text-muted py-4">No products found.</td></tr><?php endif; ?>
  <?php foreach ($products as $p): ?>
    <tr class="<?= (int) $p['stock_quantity'] <= (int) $p['low_stock_threshold'] ? 'low-stock' : '' ?>">
      <td><?php if ($p['image']): ?><img class="thumb" src="../<?= esc($p['image']) ?>" alt=""><?php endif; ?></td>
      <td><strong><?= esc($p['name']) ?></strong><br><small class="text-muted"><?= esc($p['pack_size'] ?? '') ?><?= $p['pieces_per_pack'] ? ' · ' . (int) $p['pieces_per_pack'] . ' pcs' : '' ?></small></td>
      <td class="small"><?= esc($p['sku']) ?></td>
      <td class="small"><?= esc($p['category_name'] ?? '—') ?></td>
      <td class="text-end"><?= esc(rs((int) $p['selling_price'])) ?></td>
      <td class="text-end"><?= $p['discount_price'] ? esc(rs((int) $p['discount_price'])) : '—' ?></td>
      <td class="text-end fw-bold <?= (int) $p['stock_quantity'] <= (int) $p['low_stock_threshold'] ? 'text-danger' : '' ?>"><?= (int) $p['stock_quantity'] ?></td>
      <td>
        <?php foreach (['is_featured' => '⭐', 'is_bestseller' => '🏆', 'is_active' => '✅'] as $f => $icon): ?>
          <?php if ($canEdit): ?>
            <form method="post" class="d-inline" title="<?= $f ?>">
              <input type="hidden" name="csrf" value="<?= esc(csrf_token()) ?>">
              <input type="hidden" name="action" value="toggle"><input type="hidden" name="id" value="<?= (int) $p['id'] ?>"><input type="hidden" name="field" value="<?= $f ?>">
              <button class="btn btn-sm <?= $p[$f] ? 'btn-gold' : 'btn-outline-secondary' ?> py-0 px-1" title="<?= $f ?>"><?= $icon ?></button>
            </form>
          <?php else: ?><?= $p[$f] ? $icon : '' ?><?php endif; ?>
        <?php endforeach; ?>
      </td>
      <td class="text-nowrap">
        <?php if ($canEdit): ?><a href="product-form.php?id=<?= (int) $p['id'] ?>" class="btn btn-sm btn-outline-secondary">Edit</a><?php endif; ?>
        <?php if ($canDelete): ?>
          <form method="post" class="d-inline" onsubmit="return confirm('Delete this product?')">
            <input type="hidden" name="csrf" value="<?= esc(csrf_token()) ?>">
            <input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?= (int) $p['id'] ?>">
            <button class="btn btn-sm btn-outline-danger">Delete</button>
          </form>
        <?php endif; ?>
      </td>
    </tr>
  <?php endforeach; ?>
  </tbody>
</table></div></div>
<div class="mt-2"><?= mff_pagination($total, $page, $per, 'products.php', ['q' => $q, 'category' => $cat, 'active' => $active, 'sort' => $sort]) ?></div>
<?php
$content = ob_get_clean();
include __DIR__ . '/_layout.php';
