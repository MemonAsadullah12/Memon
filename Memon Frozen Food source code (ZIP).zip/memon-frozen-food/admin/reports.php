<?php
// Business reports. Every figure comes from live SQL — no hardcoded numbers.
require_once __DIR__ . '/../includes/auth.php';
require_admin('reports.view');
require_once __DIR__ . '/_helpers.php';
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/helpers.php';

$db = db();
$page_title = 'Reports';
$canExport = has_perm('reports.export');

$tabs = [
    'daily' => 'Daily sales',
    'weekly' => 'Weekly sales',
    'monthly' => 'Monthly sales',
    'annual' => 'Annual sales',
    'products' => 'Product sales',
    'best_sellers' => 'Best sellers',
    'slow_movers' => 'Slow movers',
    'inventory_valuation' => 'Inventory valuation',
    'low_stock' => 'Low stock',
    'payment_collection' => 'Payment collection',
    'outstanding' => 'Outstanding payments',
    'delivery_performance' => 'Delivery performance',
    'discount_usage' => 'Discount usage',
    'expenses' => 'Expenses',
    'profit_loss' => 'Profit & loss',
    'cancelled_returned' => 'Cancelled & returned',
];
$tab = $_GET['tab'] ?? 'daily';
if (!isset($tabs[$tab])) {
    $tab = 'daily';
}

// ---------- Filters ----------
$from = $_GET['from'] ?? date('Y-m-d', strtotime('-29 days'));
$to = $_GET['to'] ?? date('Y-m-d');
$statusF = $_GET['status'] ?? 'active'; // active = exclude cancelled/returned
$productF = (int) ($_GET['product_id'] ?? 0);
$categoryF = (int) ($_GET['category_id'] ?? 0);
$slowThreshold = max(1, (int) ($_GET['threshold'] ?? 5));

if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $from)) {
    $from = date('Y-m-d', strtotime('-29 days'));
}
if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $to)) {
    $to = date('Y-m-d');
}
if ($from > $to) {
    [$from, $to] = [$to, $from];
}

// Order-status predicate for sales queries.
$statusSql = '';
$statusParams = [];
if ($statusF === 'active') {
    $statusSql = " AND o.order_status NOT IN ('cancelled','returned')";
} elseif ($statusF !== 'all' && isset(mff_statuses()[$statusF])) {
    $statusSql = ' AND o.order_status = ?';
    $statusParams[] = $statusF;
}

// ---------- Report builders: each returns [title, headers, rows, note] ----------
$build = function () use ($db, $tab, $from, $to, $statusSql, $statusParams, $productF, $categoryF, $slowThreshold) {
    $between = 'DATE(o.created_at) BETWEEN ? AND ?';
    $dp = array_merge([$from, $to], $statusParams);

    switch ($tab) {
        case 'daily':
        case 'weekly':
        case 'monthly':
        case 'annual':
            $fmt = ['daily' => "DATE(o.created_at)", 'weekly' => "YEARWEEK(o.created_at, 1)",
                    'monthly' => "DATE_FORMAT(o.created_at, '%Y-%m')", 'annual' => "YEAR(o.created_at)"][$tab];
            $lbl = ['daily' => "DATE_FORMAT(o.created_at, '%d %b %Y')", 'weekly' => "CONCAT('Week ', WEEK(o.created_at, 1), ' · ', YEAR(o.created_at))",
                    'monthly' => "DATE_FORMAT(o.created_at, '%b %Y')", 'annual' => "YEAR(o.created_at)"][$tab];
            $rows = $db->prepare(
                "SELECT $lbl AS period, COUNT(*) AS orders, COALESCE(SUM(total_amount),0) AS revenue,
                        COALESCE(SUM(discount_amount),0) AS discounts, COALESCE(SUM(delivery_fee),0) AS delivery_fees
                 FROM orders o WHERE $between $statusSql GROUP BY $fmt ORDER BY MIN(o.created_at)"
            );
            $rows->execute($dp);
            $out = [];
            foreach ($rows->fetchAll() as $r) {
                $out[] = [$r['period'], (int) $r['orders'], rs((int) $r['revenue']), rs((int) $r['discounts']),
                          rs((int) $r['delivery_fees']), rs($r['orders'] ? (int) round($r['revenue'] / $r['orders']) : 0)];
            }
            return ['Sales by ' . $tabs[$tab], ['Period', 'Orders', 'Revenue', 'Discounts given', 'Delivery fees', 'Avg order value'], $out, ''];

        case 'products':
        case 'best_sellers':
        case 'slow_movers': {
            $extra = '';
            $xp = [];
            if ($productF > 0) {
                $extra .= ' AND oi.product_id = ?';
                $xp[] = $productF;
            }
            if ($categoryF > 0) {
                $extra .= ' AND p.category_id = ?';
                $xp[] = $categoryF;
            }
            if ($tab === 'slow_movers') {
                $rows = $db->prepare(
                    "SELECT p.name, p.sku, c.name AS cat, p.stock_quantity,
                            COALESCE(SUM(CASE WHEN $between $statusSql THEN oi.quantity ELSE 0 END),0) AS sold,
                            COALESCE(SUM(CASE WHEN $between $statusSql THEN oi.line_total ELSE 0 END),0) AS revenue
                     FROM products p LEFT JOIN categories c ON c.id = p.category_id
                     LEFT JOIN order_items oi ON oi.product_id = p.id
                     LEFT JOIN orders o ON o.id = oi.order_id
                     WHERE p.is_active = 1 $extra
                     GROUP BY p.id HAVING sold < ? ORDER BY sold ASC"
                );
                $rows->execute(array_merge([$from, $to], $statusParams, [$from, $to], $statusParams, $xp, [$slowThreshold]));
                $out = [];
                foreach ($rows->fetchAll() as $r) {
                    $out[] = [$r['name'], $r['sku'], $r['cat'] ?? '—', (int) $r['sold'], rs((int) $r['revenue']), (int) $r['stock_quantity']];
                }
                return ['Slow movers (sold < ' . $slowThreshold . ' in range)', ['Product', 'SKU', 'Category', 'Qty sold', 'Revenue', 'In stock'],
                        $out, 'Includes products with zero sales in the selected period.'];
            }
            $rows = $db->prepare(
                "SELECT p.name, p.sku, c.name AS cat, SUM(oi.quantity) AS sold, SUM(oi.line_total) AS revenue
                 FROM order_items oi JOIN orders o ON o.id = oi.order_id
                 LEFT JOIN products p ON p.id = oi.product_id LEFT JOIN categories c ON c.id = p.category_id
                 WHERE $between $statusSql $extra
                 GROUP BY oi.product_id ORDER BY " . ($tab === 'best_sellers' ? 'sold DESC LIMIT 20' : 'sold DESC')
            );
            $rows->execute(array_merge($dp, $xp));
            $out = [];
            foreach ($rows->fetchAll() as $r) {
                $out[] = [$r['name'] ?? '—', $r['sku'] ?? '—', $r['cat'] ?? '—', (int) $r['sold'], rs((int) $r['revenue'])];
            }
            return [$tabs[$tab], ['Product', 'SKU', 'Category', 'Qty sold', 'Revenue'], $out, ''];
        }

        case 'inventory_valuation': {
            $rows = $db->query(
                'SELECT name, sku, stock_quantity, cost_price FROM products WHERE is_active = 1 ORDER BY name'
            )->fetchAll();
            $out = [];
            $total = 0;
            $missing = 0;
            foreach ($rows as $r) {
                $val = $r['cost_price'] === null ? null : (int) $r['stock_quantity'] * (int) $r['cost_price'];
                if ($val === null) {
                    $missing++;
                } else {
                    $total += $val;
                }
                $out[] = [$r['name'], $r['sku'], (int) $r['stock_quantity'],
                          $r['cost_price'] === null ? '—' : rs((int) $r['cost_price']),
                          $val === null ? '—' : rs($val)];
            }
            $note = 'Total inventory value: ' . rs($total) . '.'
                . ($missing ? " $missing product(s) have no cost price set and are excluded from the total." : ' All active products have a cost price.');
            return ['Inventory valuation', ['Product', 'SKU', 'In stock', 'Cost price', 'Stock value'], $out, $note];
        }

        case 'low_stock': {
            $rows = $db->query(
                'SELECT p.name, p.sku, c.name AS cat, p.stock_quantity, p.low_stock_threshold
                 FROM products p LEFT JOIN categories c ON c.id = p.category_id
                 WHERE p.is_active = 1 AND p.stock_quantity <= p.low_stock_threshold
                 ORDER BY p.stock_quantity ASC'
            )->fetchAll();
            $out = array_map(fn($r) => [$r['name'], $r['sku'], $r['cat'] ?? '—', (int) $r['stock_quantity'], (int) $r['low_stock_threshold']], $rows);
            return ['Low stock', ['Product', 'SKU', 'Category', 'In stock', 'Threshold'], $out, ''];
        }

        case 'payment_collection': {
            $rows = $db->prepare(
                "SELECT method, COUNT(*) AS n, COALESCE(SUM(amount),0) AS total
                 FROM payments WHERE DATE(received_at) BETWEEN ? AND ? AND status = 'received'
                 GROUP BY method ORDER BY total DESC"
            );
            $rows->execute([$from, $to]);
            $all = $rows->fetchAll();
            $grand = array_sum(array_column($all, 'total'));
            $out = array_map(fn($r) => [$r['method'], (int) $r['n'], rs((int) $r['total'])], $all);
            return ['Payment collection', ['Method', 'Payments', 'Collected'], $out, 'Total collected in range: ' . rs((int) $grand) . '.'];
        }

        case 'outstanding': {
            $rows = $db->prepare(
                "SELECT o.order_number, o.customer_name, o.customer_phone, o.total_amount, o.order_status,
                        COALESCE((SELECT SUM(amount) FROM payments WHERE order_id = o.id AND status IN ('received','pending')),0) AS paid
                 FROM orders o WHERE $between AND o.order_status NOT IN ('cancelled','returned')
                 HAVING (o.total_amount - paid) > 0 ORDER BY o.id DESC"
            );
            $rows->execute([$from, $to]);
            $out = [];
            $grand = 0;
            foreach ($rows->fetchAll() as $r) {
                $bal = (int) $r['total_amount'] - (int) $r['paid'];
                $grand += $bal;
                $out[] = [$r['order_number'], $r['customer_name'], $r['customer_phone'], rs((int) $r['total_amount']),
                          rs((int) $r['paid']), rs($bal), mff_status_label($r['order_status'])];
            }
            return ['Outstanding payments', ['Order', 'Customer', 'Phone', 'Total', 'Paid', 'Outstanding', 'Status'], $out,
                    'Total outstanding in range: ' . rs($grand) . '.'];
        }

        case 'delivery_performance': {
            $agg = $db->prepare(
                "SELECT COUNT(*) AS n,
                        AVG(TIMESTAMPDIFF(MINUTE, o.created_at, d.dispatched_at))/60 AS hrs_to_dispatch,
                        AVG(TIMESTAMPDIFF(MINUTE, d.dispatched_at, d.delivered_at))/60 AS hrs_to_deliver
                 FROM delivery_assignments d JOIN orders o ON o.id = d.order_id
                 WHERE DATE(o.created_at) BETWEEN ? AND ? AND d.dispatched_at IS NOT NULL"
            );
            $agg->execute([$from, $to]);
            $a = $agg->fetch();
            $byStatus = $db->prepare(
                'SELECT d.status, COUNT(*) AS n FROM delivery_assignments d JOIN orders o ON o.id = d.order_id
                 WHERE DATE(o.created_at) BETWEEN ? AND ? GROUP BY d.status'
            );
            $byStatus->execute([$from, $to]);
            $st2 = $db->prepare(
                'SELECT COUNT(*) FROM delivery_attempts a JOIN delivery_assignments d ON d.id = a.assignment_id
                 JOIN orders o ON o.id = d.order_id WHERE DATE(o.created_at) BETWEEN ? AND ?'
            );
            $st2->execute([$from, $to]);
            $failed = (int) $st2->fetchColumn();
            $out = [
                ['Assignments dispatched', (int) $a['n'], ''],
                ['Avg. hours: order placed → dispatched', $a['hrs_to_dispatch'] === null ? '—' : number_format((float) $a['hrs_to_dispatch'], 1), ''],
                ['Avg. hours: dispatched → delivered', $a['hrs_to_deliver'] === null ? '—' : number_format((float) $a['hrs_to_deliver'], 1), ''],
                ['Delivery attempts logged', $failed, ''],
            ];
            foreach ($byStatus->fetchAll() as $s) {
                $out[] = ['Assignments: ' . ucfirst($s['status']), (int) $s['n'], ''];
            }
            return ['Delivery performance', ['Metric', 'Value', ''], $out,
                    'Averages are computed only from assignments that reached the relevant stage.'];
        }

        case 'discount_usage': {
            $rows = $db->prepare(
                "SELECT c.code, COUNT(*) AS n, COALESCE(SUM(r.discount_amount),0) AS total
                 FROM coupon_redemptions r JOIN coupons c ON c.id = r.coupon_id
                 LEFT JOIN orders o ON o.id = r.order_id
                 WHERE o.id IS NULL OR DATE(o.created_at) BETWEEN ? AND ?
                 GROUP BY c.id ORDER BY total DESC"
            );
            $rows->execute([$from, $to]);
            $out = [];
            $grand = 0;
            foreach ($rows->fetchAll() as $r) {
                $grand += (int) $r['total'];
                $out[] = [$r['code'], (int) $r['n'], rs((int) $r['total'])];
            }
            return ['Discount usage', ['Coupon', 'Redemptions', 'Discount given'], $out,
                    'Total discounts in range: ' . rs($grand) . '.'];
        }

        case 'expenses': {
            $rows = $db->prepare(
                'SELECT c.name AS cat, COUNT(*) AS n, COALESCE(SUM(e.amount),0) AS total
                 FROM expenses e JOIN expense_categories c ON c.id = e.category_id
                 WHERE e.expense_date BETWEEN ? AND ? GROUP BY c.id ORDER BY total DESC'
            );
            $rows->execute([$from, $to]);
            $all = $rows->fetchAll();
            $grand = array_sum(array_column($all, 'total'));
            $out = array_map(fn($r) => [$r['cat'], (int) $r['n'], rs((int) $r['total'])], $all);
            return ['Expenses by category', ['Category', 'Entries', 'Total'], $out, 'Total expenses in range: ' . rs((int) $grand) . '.'];
        }

        case 'profit_loss': {
            $rev = $db->prepare("SELECT COALESCE(SUM(total_amount),0) FROM orders o WHERE $between $statusSql");
            $rev->execute($dp);
            $revenue = (int) $rev->fetchColumn();
            $exp = $db->prepare('SELECT COALESCE(SUM(amount),0) FROM expenses WHERE expense_date BETWEEN ? AND ?');
            $exp->execute([$from, $to]);
            $expenses = (int) $exp->fetchColumn();
            $cogs = $db->prepare(
                "SELECT COALESCE(SUM(oi.quantity * p.cost_price),0),
                        SUM(CASE WHEN p.cost_price IS NULL THEN oi.quantity ELSE 0 END)
                 FROM order_items oi JOIN orders o ON o.id = oi.order_id
                 LEFT JOIN products p ON p.id = oi.product_id
                 WHERE $between $statusSql"
            );
            $cogs->execute($dp);
            [$cogsVal, $noCostQty] = $cogs->fetch(PDO::FETCH_NUM);
            $cogsVal = (int) $cogsVal;
            $noCostQty = (int) $noCostQty;
            $gross = $revenue - $cogsVal;
            $net = $revenue - $expenses;
            $out = [
                ['Revenue (orders)', rs($revenue)],
                ['Cost of goods sold', rs($cogsVal)],
                ['Gross profit (revenue − COGS)', rs($gross)],
                ['Operating expenses', rs($expenses)],
                ['Net profit (revenue − expenses)', rs($net)],
            ];
            $note = $noCostQty > 0
                ? "Note: $noCostQty sold unit(s) have no cost price set, so COGS and gross profit are understated."
                : 'All sold items have cost prices set, so gross profit is complete.';
            return ['Profit & loss', ['Line', 'Amount (Rs)'], $out, $note];
        }

        case 'cancelled_returned': {
            $rows = $db->prepare(
                "SELECT o.order_number, o.customer_name, o.customer_phone, o.total_amount, o.order_status, o.created_at
                 FROM orders o WHERE $between AND o.order_status IN ('cancelled','returned') ORDER BY o.id DESC"
            );
            $rows->execute([$from, $to]);
            $out = [];
            foreach ($rows->fetchAll() as $r) {
                $out[] = [$r['order_number'], $r['customer_name'], $r['customer_phone'], rs((int) $r['total_amount']),
                          mff_status_label($r['order_status']), mff_date($r['created_at'], false)];
            }
            return ['Cancelled & returned orders', ['Order', 'Customer', 'Phone', 'Total', 'Status', 'Date'], $out, ''];
        }
    }
    return ['Report', [], [], ''];
};

[$title, $headers, $rows, $note] = $build();

// ---------- CSV export ----------
if (isset($_GET['export']) && $_GET['export'] === 'csv') {
    if (!$canExport) {
        mff_flash('You do not have permission to export reports.', 'danger');
        redirect('reports.php?tab=' . $tab);
    }
    mff_csv_download('report-' . $tab . '-' . $from . '-to-' . $to . '.csv', $headers, $rows);
}

$products = $db->query('SELECT id, name FROM products ORDER BY name')->fetchAll();
$categories = $db->query('SELECT id, name FROM categories ORDER BY name')->fetchAll();
$page_actions = '<button class="btn btn-sm btn-outline-secondary" onclick="window.print()">🖨️ Print / Save as PDF</button>'
    . ($canExport ? ' <a class="btn btn-sm btn-maroon" href="reports.php?' . http_build_query(array_merge($_GET, ['export' => 'csv'])) . '">Export CSV</a>' : '');

ob_start();
?>
<style>
@media print {
  .topbar, #adminSidebar, .no-print, footer { display:none !important; }
  body { background:#fff; }
  .card { box-shadow:none; }
}
.report-tabs { display:flex; flex-wrap:wrap; gap:.3rem; }
</style>

<div class="card mb-3 no-print"><div class="card-body">
  <div class="report-tabs mb-3">
    <?php foreach ($tabs as $k => $lbl): ?>
      <a href="reports.php?tab=<?= $k ?>" class="btn btn-sm <?= $tab === $k ? 'btn-maroon' : 'btn-outline-secondary' ?>"><?= esc($lbl) ?></a>
    <?php endforeach; ?>
  </div>
  <form method="get" class="row g-2">
    <input type="hidden" name="tab" value="<?= esc($tab) ?>">
    <div class="col-md-2"><label class="form-label">From</label><input type="date" name="from" class="form-control form-control-sm" value="<?= esc($from) ?>"></div>
    <div class="col-md-2"><label class="form-label">To</label><input type="date" name="to" class="form-control form-control-sm" value="<?= esc($to) ?>"></div>
    <?php if (in_array($tab, ['daily', 'weekly', 'monthly', 'annual', 'products', 'profit_loss'], true)): ?>
      <div class="col-md-2"><label class="form-label">Order status</label>
        <select name="status" class="form-select form-select-sm">
          <option value="active" <?= $statusF === 'active' ? 'selected' : '' ?>>Non-cancelled</option>
          <option value="all" <?= $statusF === 'all' ? 'selected' : '' ?>>All</option>
          <?php foreach (mff_statuses() as $code => $lbl): ?><option value="<?= $code ?>" <?= $statusF === $code ? 'selected' : '' ?>><?= esc($lbl) ?></option><?php endforeach; ?>
        </select></div>
    <?php endif; ?>
    <?php if (in_array($tab, ['products', 'best_sellers'], true)): ?>
      <div class="col-md-2"><label class="form-label">Product</label>
        <select name="product_id" class="form-select form-select-sm"><option value="0">All</option>
        <?php foreach ($products as $pr): ?><option value="<?= (int) $pr['id'] ?>" <?= $productF === (int) $pr['id'] ? 'selected' : '' ?>><?= esc($pr['name']) ?></option><?php endforeach; ?></select></div>
      <div class="col-md-2"><label class="form-label">Category</label>
        <select name="category_id" class="form-select form-select-sm"><option value="0">All</option>
        <?php foreach ($categories as $ct): ?><option value="<?= (int) $ct['id'] ?>" <?= $categoryF === (int) $ct['id'] ? 'selected' : '' ?>><?= esc($ct['name']) ?></option><?php endforeach; ?></select></div>
    <?php endif; ?>
    <?php if ($tab === 'slow_movers'): ?>
      <div class="col-md-2"><label class="form-label">Sold less than</label><input type="number" name="threshold" class="form-control form-control-sm" min="1" value="<?= $slowThreshold ?>"></div>
    <?php endif; ?>
    <div class="col-md-2 d-flex align-items-end"><button class="btn btn-sm btn-maroon w-100">Apply</button></div>
  </form>
</div></div>

<div class="card">
  <div class="card-header d-flex justify-content-between align-items-center">
    <span><?= esc($title) ?></span>
    <small class="text-muted"><?= esc($from) ?> → <?= esc($to) ?> · <?= count($rows) ?> row(s)</small>
  </div>
  <?php if ($note): ?><div class="card-body py-2"><p class="small text-muted mb-0">ℹ️ <?= esc($note) ?></p></div><?php endif; ?>
  <div class="table-responsive"><table class="table table-sm table-striped mb-0">
    <thead><tr><?php foreach ($headers as $h): ?><th><?= esc($h) ?></th><?php endforeach; ?></tr></thead>
    <tbody>
    <?php if (!$rows): ?><tr><td colspan="<?= max(1, count($headers)) ?>" class="text-center text-muted py-4">No data for the selected filters.</td></tr><?php endif; ?>
    <?php foreach ($rows as $r): ?><tr><?php foreach ($r as $cell): ?><td><?= esc((string) $cell) ?></td><?php endforeach; ?></tr><?php endforeach; ?>
    </tbody>
  </table></div>
</div>
<?php
$content = ob_get_clean();
include __DIR__ . '/_layout.php';
