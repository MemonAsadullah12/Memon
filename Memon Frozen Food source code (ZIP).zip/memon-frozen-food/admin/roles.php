<?php
require_once __DIR__ . '/../includes/auth.php';
require_admin('users.manage');
require_once __DIR__ . '/_helpers.php';
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/helpers.php';

$db = db();
$page_title = 'Roles & Permissions';

// The 30 permission codes from the shared contract (exact).
$permissions = [
    'dashboard.view' => 'View dashboard',
    'products.view' => 'View products',
    'products.create' => 'Create products',
    'products.edit' => 'Edit products',
    'products.delete' => 'Delete products',
    'products.export' => 'Export products',
    'categories.manage' => 'Manage categories',
    'orders.view' => 'View orders',
    'orders.edit' => 'Edit orders / change status',
    'orders.print' => 'Print orders',
    'inventory.view' => 'View inventory',
    'inventory.edit' => 'Adjust inventory',
    'customers.view' => 'View customers',
    'customers.edit' => 'Edit customers',
    'customers.export' => 'Export customers',
    'deliveries.view' => 'View deliveries',
    'deliveries.edit' => 'Manage deliveries',
    'coupons.manage' => 'Manage coupons',
    'payments.view' => 'View payments',
    'payments.edit' => 'Record payments',
    'expenses.view' => 'View expenses',
    'expenses.edit' => 'Manage expenses',
    'reports.view' => 'View reports',
    'reports.export' => 'Export reports',
    'notifications.view' => 'View notifications',
    'settings.edit' => 'Edit settings',
    'content.edit' => 'Edit content',
    'users.manage' => 'Manage users & roles',
    'backups.run' => 'Run backups',
    'audit.view' => 'View audit logs',
];

$roles = $db->query('SELECT * FROM roles ORDER BY id')->fetchAll();
$permIds = $db->query('SELECT id, code FROM permissions')->fetchAll(PDO::FETCH_KEY_PAIR); // code => id
$grants = [];
foreach ($db->query('SELECT rp.role_id, p.code FROM role_permissions rp JOIN permissions p ON p.id = rp.permission_id') as $row) {
    $grants[$row['role_id']][$row['code']] = true;
}
$superRoleId = null;
foreach ($roles as $r) {
    if ($r['name'] === 'Super Admin') {
        $superRoleId = (int) $r['id'];
    }
}

// --- Save matrix ---
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $posted = $_POST['perm'] ?? [];
    try {
        $db->beginTransaction();
        foreach ($roles as $r) {
            $rid = (int) $r['id'];
            if ($rid === $superRoleId) {
                continue; // Super Admin is locked to all permissions
            }
            $db->prepare('DELETE FROM role_permissions WHERE role_id = ?')->execute([$rid]);
            $ins = $db->prepare('INSERT INTO role_permissions (role_id, permission_id) VALUES (?,?)');
            foreach (array_keys($permissions) as $code) {
                if (!empty($posted[$rid][$code]) && isset($permIds[$code])) {
                    $ins->execute([$rid, $permIds[$code]]);
                }
            }
        }
        $db->commit();
        mff_audit('roles.update', 'role_permissions', null, null, 'permission matrix saved');
        mff_flash('Permissions saved.');
    } catch (Throwable $e) {
        if ($db->inTransaction()) {
            $db->rollBack();
        }
        mff_flash($e->getMessage(), 'danger');
    }
    redirect('roles.php');
}

ob_start();
?>
<div class="alert alert-warning">The <strong>Super Admin</strong> role always has every permission and is locked. There are <?= count($permissions) ?> permission codes.</div>
<form method="post">
<input type="hidden" name="csrf" value="<?= esc(csrf_token()) ?>">
<div class="card"><div class="table-responsive"><table class="table table-sm mb-0">
  <thead><tr><th style="min-width:220px;">Permission</th>
    <?php foreach ($roles as $r): ?><th class="text-center"><?= esc($r['name']) ?><?= (int) $r['id'] === $superRoleId ? '<br><small class="text-muted">locked</small>' : '' ?></th><?php endforeach; ?>
  </tr></thead>
  <tbody>
  <?php foreach ($permissions as $code => $label): ?>
    <tr>
      <td><?= esc($label) ?><br><small class="text-muted"><code><?= esc($code) ?></code></small></td>
      <?php foreach ($roles as $r): $rid = (int) $r['id']; $locked = $rid === $superRoleId; ?>
        <td class="text-center">
          <input type="checkbox" class="form-check-input" name="perm[<?= $rid ?>][<?= esc($code) ?>]" value="1"
            <?= $locked || !empty($grants[$rid][$code]) ? 'checked' : '' ?> <?= $locked ? 'disabled' : '' ?>>
        </td>
      <?php endforeach; ?>
    </tr>
  <?php endforeach; ?>
  </tbody>
</table></div></div>
<div class="mt-3"><button class="btn btn-maroon">Save permissions</button></div>
</form>
<?php
$content = ob_get_clean();
include __DIR__ . '/_layout.php';
