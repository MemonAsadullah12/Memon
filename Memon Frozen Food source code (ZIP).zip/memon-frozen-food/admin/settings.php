<?php
require_once __DIR__ . '/../includes/auth.php';
require_admin('settings.edit');
require_once __DIR__ . '/_helpers.php';
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/helpers.php';

$db = db();
$page_title = 'Settings';

$groups = [
    'Store information' => [
        'site_name' => ['label' => 'Site name', 'type' => 'text'],
        'tagline' => ['label' => 'Tagline', 'type' => 'text'],
        'tagline2' => ['label' => 'Tagline 2', 'type' => 'text'],
        'order_phone' => ['label' => 'Order phone', 'type' => 'text'],
        'whatsapp_number' => ['label' => 'WhatsApp number', 'type' => 'text'],
        'city' => ['label' => 'City', 'type' => 'text'],
        'currency' => ['label' => 'Currency', 'type' => 'text'],
    ],
    'Orders & delivery' => [
        'delivery_fee' => ['label' => 'Default delivery fee (Rs)', 'type' => 'number'],
        'min_order' => ['label' => 'Minimum order (Rs)', 'type' => 'number'],
        'free_delivery_above' => ['label' => 'Free delivery above (Rs)', 'type' => 'number'],
        'announcement_text' => ['label' => 'Announcement banner text', 'type' => 'textarea'],
    ],
    'Payment methods (1 = enabled)' => [
        'payment_cod' => ['label' => 'Cash on Delivery', 'type' => 'checkbox'],
        'payment_bank' => ['label' => 'Bank transfer', 'type' => 'checkbox'],
        'payment_easypaisa' => ['label' => 'Easypaisa', 'type' => 'checkbox'],
        'payment_jazzcash' => ['label' => 'JazzCash', 'type' => 'checkbox'],
    ],
    'Maintenance' => [
        'maintenance_mode' => ['label' => 'Maintenance mode (1 = site offline)', 'type' => 'checkbox'],
    ],
];
$defaults = [
    'site_name' => 'Memon Frozen Food', 'tagline' => 'Hygienic Taste', 'tagline2' => 'Fresh & Hygienic Frozen Foods',
    'order_phone' => '0300-3130608', 'whatsapp_number' => '923003130608', 'city' => 'Khairpur Mirs', 'currency' => 'Rs.',
    'delivery_fee' => '0', 'min_order' => '0', 'free_delivery_above' => '', 'announcement_text' => '',
    'payment_cod' => '1', 'payment_bank' => '0', 'payment_easypaisa' => '0', 'payment_jazzcash' => '0',
    'maintenance_mode' => '0',
];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $changes = [];
    foreach ($groups as $fields) {
        foreach ($fields as $key => $meta) {
            $new = $meta['type'] === 'checkbox' ? (isset($_POST[$key]) ? '1' : '0') : trim($_POST[$key] ?? '');
            $old = (string) mff_setting($key, $defaults[$key] ?? '');
            if ($new !== $old) {
                $db->prepare('INSERT INTO business_settings (setting_key, setting_value) VALUES (?, ?) ON DUPLICATE KEY UPDATE setting_value = ?')
                    ->execute([$key, $new, $new]);
                $changes[$key] = ['old' => $old, 'new' => $new];
            }
        }
    }
    if ($changes) {
        mff_audit('settings.update', 'business_settings', null, $changes, null);
        mff_flash(count($changes) . ' setting(s) updated.');
    } else {
        mff_flash('No changes to save.', 'info');
    }
    redirect('settings.php');
}

$values = [];
foreach ($groups as $fields) {
    foreach ($fields as $key => $meta) {
        $values[$key] = mff_setting($key, $defaults[$key] ?? '');
    }
}

ob_start();
?>
<form method="post">
<input type="hidden" name="csrf" value="<?= esc(csrf_token()) ?>">
<div class="row g-3">
  <?php foreach ($groups as $gname => $fields): ?>
    <div class="col-lg-6">
      <div class="card h-100"><div class="card-header"><?= esc($gname) ?></div><div class="card-body">
        <?php foreach ($fields as $key => $meta): ?>
          <?php if ($meta['type'] === 'checkbox'): ?>
            <div class="form-check mb-2">
              <input type="checkbox" name="<?= esc($key) ?>" id="s_<?= esc($key) ?>" class="form-check-input" value="1" <?= $values[$key] === '1' ? 'checked' : '' ?>>
              <label class="form-check-label" for="s_<?= esc($key) ?>"><?= esc($meta['label']) ?></label>
            </div>
          <?php elseif ($meta['type'] === 'textarea'): ?>
            <div class="mb-2"><label class="form-label"><?= esc($meta['label']) ?></label>
              <textarea name="<?= esc($key) ?>" class="form-control form-control-sm" rows="2"><?= esc($values[$key]) ?></textarea></div>
          <?php else: ?>
            <div class="mb-2"><label class="form-label"><?= esc($meta['label']) ?></label>
              <input type="<?= $meta['type'] ?>" name="<?= esc($key) ?>" class="form-control form-control-sm" value="<?= esc($values[$key]) ?>"></div>
          <?php endif; ?>
        <?php endforeach; ?>
      </div></div>
    </div>
  <?php endforeach; ?>
</div>
<div class="mt-3"><button class="btn btn-maroon">Save settings</button></div>
</form>
<?php
$content = ob_get_clean();
include __DIR__ . '/_layout.php';
