<?php
require_once __DIR__ . '/../includes/auth.php';
require_admin('inventory.view');
require_once __DIR__ . '/_helpers.php';
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/helpers.php';

$db = db();
$page_title = 'Stock Movements';

$pid = (int) ($_GET['product_id'] ?? 0);
$type = $_GET['type'] ?? '';
$dfrom = $_GET['dfrom'] ?? '';
$dto = $_GET['dto'] ?? '';

$where = [];
$params = [];
if ($pid > 0) {
    $where[] = 'sm.product_id = ?';
    $params[] = $pid;
}
if ($type !== '') {
    $where[] = 'sm.movement_type = ?';
    $params[] = $type;
}
if ($dfrom !== '') {
    $where[] = 'DATE(sm.created_at) >= ?';
    $params[] = $dfrom;
}
if ($dto !== '') {
    $where[] = 'DATE(sm.created_at) <= ?';
    $params[] = $dto;
}
$whereSql = $where ? 'WHERE ' . implode(' AND ', $where) : '';

$st = $db->prepare("SELECT COUNT(*) FROM stock_movements sm $whereSql");
$st->execute($params);
$total = (int) $st->fetchColumn();
$page = max(1, (int) ($_GET['page'] ?? 1));
$per = 25;
$offset = ($page - 1) * $per;

$st = $db->prepare(
    "SELECT sm.*, p.name AS product_name, p.sku, u.name AS admin_name
     FROM stock_movements sm
     JOIN products p ON p.id = sm.product_id
     LEFT JOIN users u ON u.id = sm.admin_id
     $whereSql ORDER BY sm.id DESC LIMIT $per OFFSET $offset"
);
$st->execute($params);
$rows = $st->fetchAll();
$products = $db->query('SELECT id, name FROM products ORDER BY name')->fetchAll();
$types = ['received', 'adjustment', 'damaged', 'expired', 'returned', 'sale'];

ob_start();
?>
<div class="card mb-3"><div class="card-body">
  <form method="get" class="row g-2">
    <div class="col-md-3"><select name="product_id" class="form-select form-select-sm">
      <option value="0">All products</option>
      <?php foreach ($products as $p): ?><option value="<?= (int) $p['id'] ?>" <?= $pid === (int) $p['id'] ? 'selected' : '' ?>><?= esc($p['name']) ?></option><?php endforeach; ?>
    </select></div>
    <div class="col-md-2"><select name="type" class="form-select form-select-sm">
      <option value="">All types</option>
      <?php foreach ($types as $t): ?><option <?= $type === $t ? 'selected' : '' ?>><?= $t ?></option><?php endforeach; ?>
    </select></div>
    <div class="col-md-2"><input type="date" name="dfrom" class="form-control form-control-sm" value="<?= esc($dfrom) ?>"></div>
    <div class="col-md-2"><input type="date" name="dto" class="form-control form-control-sm" value="<?= esc($dto) ?>"></div>
    <div class="col-md-1"><button class="btn btn-sm btn-maroon w-100">Go</button></div>
  </form>
</div></div>

<div class="card"><div class="table-responsive"><table class="table table-sm mb-0">
  <thead><tr><th>Date</th><th>Product</th><th>Type</th><th class="text-end">Change</th><th>Reference</th><th>Notes</th><th>By</th></tr></thead>
  <tbody>
  <?php if (!$rows): ?><tr><td colspan="7" class="text-center text-muted py-4">No movements found.</td></tr><?php endif; ?>
  <?php foreach ($rows as $r): ?>
    <tr>
      <td class="small"><?= esc(mff_date($r['created_at'])) ?></td>
      <td><?= esc($r['product_name']) ?><br><small class="text-muted"><?= esc($r['sku']) ?></small></td>
      <td><span class="badge bg-secondary"><?= esc($r['movement_type']) ?></span></td>
      <td class="text-end fw-bold <?= (int) $r['change_qty'] < 0 ? 'text-danger' : 'text-success' ?>">
        <?= (int) $r['change_qty'] > 0 ? '+' : '' ?><?= (int) $r['change_qty'] ?></td>
      <td class="small"><?= esc($r['reference_type'] ?? '') ?><?= $r['reference_id'] ? ' #' . (int) $r['reference_id'] : '' ?></td>
      <td class="small"><?= esc($r['notes'] ?? '—') ?></td>
      <td class="small"><?= esc($r['admin_name'] ?? 'system') ?></td>
    </tr>
  <?php endforeach; ?>
  </tbody>
</table></div></div>
<div class="mt-2"><?= mff_pagination($total, $page, $per, 'stock-movements.php', ['product_id' => $pid, 'type' => $type, 'dfrom' => $dfrom, 'dto' => $dto]) ?></div>
<?php
$content = ob_get_clean();
include __DIR__ . '/_layout.php';
