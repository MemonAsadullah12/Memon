<?php
require_once __DIR__ . '/../includes/auth.php';
require_admin('users.manage');
require_once __DIR__ . '/_helpers.php';
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/helpers.php';

$db = db();
$page_title = 'Admin Users';
$me = current_admin();

$superRoleId = (int) $db->query("SELECT id FROM roles WHERE name = 'Super Admin' LIMIT 1")->fetchColumn();
$roles = $db->query('SELECT id, name FROM roles ORDER BY id')->fetchAll();

$superCount = $superRoleId
    ? (int) $db->query('SELECT COUNT(*) FROM users WHERE role_id = ' . $superRoleId . ' AND is_active = 1')->fetchColumn()
    : 0;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $action = $_POST['action'] ?? '';
    $id = (int) ($_POST['id'] ?? 0);
    $target = $id ? $db->query('SELECT * FROM users WHERE id = ' . $id)->fetch() : null;

    if ($action === 'save') {
        $name = trim($_POST['name'] ?? '');
        $email = trim($_POST['email'] ?? '');
        $roleId = (int) ($_POST['role_id'] ?? 0);
        $active = isset($_POST['is_active']) ? 1 : 0;
        $pw = $_POST['password'] ?? '';
        try {
            if ($name === '' || !filter_var($email, FILTER_VALIDATE_EMAIL) || $roleId <= 0) {
                throw new RuntimeException('Name, a valid email and a role are required.');
            }
            $st = $db->prepare('SELECT id FROM users WHERE email = ?' . ($id ? ' AND id <> ' . $id : '') . ' LIMIT 1');
            $st->execute([$email]);
            if ($st->fetch()) {
                throw new RuntimeException('Email already exists.');
            }
            if ($pw !== '' && strlen($pw) < 8) {
                throw new RuntimeException('Password must be at least 8 characters.');
            }
            // Self-demotion / self-deactivation lockout
            if ($target && (int) $target['id'] === (int) $me['id']) {
                if ($roleId !== (int) $target['role_id']) {
                    throw new RuntimeException('You cannot change your own role.');
                }
                if (!$active) {
                    throw new RuntimeException('You cannot deactivate your own account.');
                }
            }
            // Never strand the system without an active Super Admin
            if ($target && (int) $target['role_id'] === $superRoleId && $superCount <= 1) {
                if ($roleId !== $superRoleId || !$active) {
                    throw new RuntimeException('Cannot demote or deactivate the last active Super Admin.');
                }
            }
            if ($id && $target) {
                $sql = 'UPDATE users SET name=?, email=?, role_id=?, is_active=?' . ($pw !== '' ? ', password_hash=?' : '') . ' WHERE id=?';
                $params = [$name, $email, $roleId, $active];
                if ($pw !== '') {
                    $params[] = password_hash($pw, PASSWORD_DEFAULT);
                }
                $params[] = $id;
                $db->prepare($sql)->execute($params);
                mff_audit('user.update', 'users', $id, $target['email'], $email);
                mff_flash('User updated.' . ($pw !== '' ? ' Password changed.' : ''));
            } else {
                if ($pw === '') {
                    throw new RuntimeException('A password (min 8 characters) is required for new users.');
                }
                $db->prepare('INSERT INTO users (role_id, name, email, password_hash, is_active) VALUES (?,?,?,?,?)')
                    ->execute([$roleId, $name, $email, password_hash($pw, PASSWORD_DEFAULT), $active]);
                mff_audit('user.create', 'users', (int) $db->lastInsertId(), null, $email);
                mff_flash('User created.');
            }
        } catch (Throwable $e) {
            mff_flash($e->getMessage(), 'danger');
        }
        redirect('users.php');
    }

    if ($action === 'delete' && $target) {
        try {
            if ((int) $target['id'] === (int) $me['id']) {
                throw new RuntimeException('You cannot delete your own account.');
            }
            if ((int) $target['role_id'] === $superRoleId && $superCount <= 1) {
                throw new RuntimeException('Cannot delete the last active Super Admin.');
            }
            $db->prepare('DELETE FROM users WHERE id = ?')->execute([$id]);
            mff_audit('user.delete', 'users', $id, $target['email'], null);
            mff_flash('User deleted.');
        } catch (Throwable $e) {
            mff_flash($e->getMessage(), 'danger');
        }
        redirect('users.php');
    }
}

$editId = (int) ($_GET['edit'] ?? 0);
$editRow = $editId ? $db->query('SELECT * FROM users WHERE id = ' . $editId)->fetch() : null;
$users = $db->query(
    'SELECT u.*, r.name AS role_name FROM users u LEFT JOIN roles r ON r.id = u.role_id ORDER BY u.id'
)->fetchAll();

ob_start();
?>
<div class="row g-3">
  <div class="col-lg-4">
    <div class="card"><div class="card-header"><?= $editRow ? 'Edit User' : 'Add User' ?></div><div class="card-body">
      <form method="post">
        <input type="hidden" name="csrf" value="<?= esc(csrf_token()) ?>">
        <input type="hidden" name="action" value="save">
        <input type="hidden" name="id" value="<?= (int) ($editRow['id'] ?? 0) ?>">
        <div class="mb-2"><label class="form-label required">Name</label>
          <input type="text" name="name" class="form-control" required value="<?= esc($editRow['name'] ?? '') ?>"></div>
        <div class="mb-2"><label class="form-label required">Email</label>
          <input type="email" name="email" class="form-control" required value="<?= esc($editRow['email'] ?? '') ?>"></div>
        <div class="mb-2"><label class="form-label required">Role</label>
          <select name="role_id" class="form-select" required>
            <?php foreach ($roles as $r): ?><option value="<?= (int) $r['id'] ?>" <?= (int) ($editRow['role_id'] ?? 0) === (int) $r['id'] ? 'selected' : '' ?>><?= esc($r['name']) ?></option><?php endforeach; ?>
          </select></div>
        <div class="mb-2"><label class="form-label"><?= $editRow ? 'New password (blank = keep)' : 'Password (min 8)' ?></label>
          <input type="password" name="password" class="form-control" minlength="8" <?= $editRow ? '' : 'required' ?>></div>
        <div class="form-check mb-3"><input type="checkbox" name="is_active" id="uActive" class="form-check-input" <?= ($editRow['is_active'] ?? 1) ? 'checked' : '' ?>>
          <label class="form-check-label" for="uActive">Active</label></div>
        <button class="btn btn-maroon"><?= $editRow ? 'Save changes' : 'Add user' ?></button>
        <?php if ($editRow): ?><a href="users.php" class="btn btn-outline-secondary">Cancel</a><?php endif; ?>
      </form>
    </div></div>
  </div>
  <div class="col-lg-8">
    <div class="card"><div class="table-responsive"><table class="table table-sm mb-0">
      <thead><tr><th>Name</th><th>Email</th><th>Role</th><th>Status</th><th></th></tr></thead><tbody>
      <?php foreach ($users as $u): ?>
        <tr>
          <td><?= esc($u['name']) ?> <?= (int) $u['id'] === (int) $me['id'] ? '<span class="badge bg-info text-dark">you</span>' : '' ?></td>
          <td><?= esc($u['email']) ?></td>
          <td><span class="badge bg-secondary"><?= esc($u['role_name'] ?? '—') ?></span></td>
          <td><?= $u['is_active'] ? '<span class="badge bg-success">Active</span>' : '<span class="badge bg-danger">Inactive</span>' ?></td>
          <td class="text-nowrap">
            <a href="users.php?edit=<?= (int) $u['id'] ?>" class="btn btn-sm btn-outline-secondary">Edit</a>
            <form method="post" class="d-inline" onsubmit="return confirm('Delete this user?')">
              <input type="hidden" name="csrf" value="<?= esc(csrf_token()) ?>">
              <input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?= (int) $u['id'] ?>">
              <button class="btn btn-sm btn-outline-danger">Delete</button>
            </form>
          </td>
        </tr>
      <?php endforeach; ?>
      </tbody></table></div></div>
  </div>
</div>
<?php
$content = ob_get_clean();
include __DIR__ . '/_layout.php';
