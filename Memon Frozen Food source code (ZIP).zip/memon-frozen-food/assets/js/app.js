// Memon Frozen Food — vanilla JS (no framework).
(function () {
  'use strict';
  var root = (window.MFF && window.MFF.root) || '';

  // Mobile menu toggle.
  var toggle = document.getElementById('menuToggle');
  var mobileNav = document.getElementById('mobileNav');
  if (toggle && mobileNav) {
    toggle.addEventListener('click', function () { mobileNav.classList.toggle('open'); });
  }

  // Refresh header cart counter.
  function refreshCartCount() {
    var el = document.getElementById('cartCount');
    if (!el) return;
    fetch(root + 'cart.php?ajax=count', { credentials: 'same-origin' })
      .then(function (r) { return r.json(); })
      .then(function (d) { el.textContent = d.count || 0; })
      .catch(function () { /* keep stale count */ });
  }
  refreshCartCount();

  // Quantity steppers on cart page: adjust input, then submit the form.
  document.querySelectorAll('.qty-form').forEach(function (form) {
    var input = form.querySelector('.qty-input');
    form.querySelectorAll('.qty-btn').forEach(function (btn) {
      btn.addEventListener('click', function () {
        var step = parseInt(btn.getAttribute('data-step'), 10) || 0;
        var min = parseInt(input.getAttribute('min'), 10) || 1;
        var max = parseInt(input.getAttribute('max'), 10) || 999;
        var v = (parseInt(input.value, 10) || 1) + step;
        v = Math.max(min, Math.min(max, v));
        input.value = v;
        form.submit();
      });
    });
    input.addEventListener('change', function () { form.submit(); });
  });

  // Dismissible flash messages (also auto-fade after 6s).
  document.querySelectorAll('.flash-msg').forEach(function (el) {
    setTimeout(function () {
      if (el.classList.contains('show')) {
        var c = bootstrap && bootstrap.Alert ? bootstrap.Alert.getOrCreateInstance(el) : null;
        if (c) c.close(); else el.remove();
      }
    }, 6000);
  });

  // Keep search input focused UX: pressing "/" focuses the desktop search box.
  document.addEventListener('keydown', function (e) {
    if (e.key === '/' && !/INPUT|TEXTAREA|SELECT/.test(document.activeElement.tagName)) {
      var s = document.querySelector('.search-form input[type="search"]');
      if (s) { e.preventDefault(); s.focus(); }
    }
  });
})();
