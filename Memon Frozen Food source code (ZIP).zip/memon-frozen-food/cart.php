<?php
// Cart: add / update qty / remove. ?ajax=count returns JSON cart count.
//
// The AJAX branch runs BEFORE the layout include so the response is pure JSON.
if (isset($_GET['ajax']) && $_GET['ajax'] === 'count') {
    if (session_status() === PHP_SESSION_NONE) session_start();
    require_once __DIR__ . '/includes/config.php';
    require_once __DIR__ . '/includes/db.php';
    require_once __DIR__ . '/includes/helpers.php';
    require_once __DIR__ . '/includes/auth.php';
    require_once __DIR__ . '/includes/cart-lib.php';
    header('Content-Type: application/json');
    echo json_encode(['count' => cart_count(), 'subtotal' => cart_subtotal()]);
    exit;
}

$page_title = 'Your Cart';
require_once __DIR__ . '/includes/header.php';

if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST') {
    csrf_check();
    $action = $_POST['action'] ?? '';
    $pid = (int)($_POST['pid'] ?? 0);
    if ($action === 'add') {
        $msg = cart_add($pid, (int)($_POST['qty'] ?? 1));
        flash($msg !== '' ? $msg : 'Added to cart.');
    } elseif ($action === 'set') {
        cart_set_qty($pid, (int)($_POST['qty'] ?? 1));
    } elseif ($action === 'remove') {
        cart_remove($pid);
        flash('Item removed.', 'info');
    } elseif ($action === 'coupon') {
        $_SESSION['coupon_code'] = strtoupper(trim($_POST['coupon'] ?? ''));
        flash('Coupon applied — it will be verified at checkout.', 'info');
    } elseif ($action === 'coupon_remove') {
        unset($_SESSION['coupon_code']);
    }
    redirect('cart.php');
}

$items = cart_items();
$subtotal = cart_subtotal();
?>

<h1 class="page-heading">Your Cart</h1>

<?php if (!$items): ?>
  <div class="alert alert-info">Your cart is empty. <a href="products.php">Browse products</a> to add some delicious frozen food.</div>
<?php else: ?>
  <div class="table-responsive">
    <table class="table align-middle">
      <thead><tr><th>Product</th><th>Price</th><th style="width:130px">Qty</th><th>Total</th><th></th></tr></thead>
      <tbody>
      <?php foreach ($items as $i): ?>
        <tr>
          <td><a href="product.php?slug=<?= esc($i['slug']) ?>"><?= esc($i['name']) ?></a><br>
              <small class="text-muted"><?= esc($i['pack_size'] ?? '') ?></small></td>
          <td><?= rs($i['eff_price']) ?></td>
          <td>
            <form method="post" class="qty-form d-flex gap-1">
              <?= csrf_field() ?>
              <input type="hidden" name="action" value="set">
              <input type="hidden" name="pid" value="<?= (int)$i['id'] ?>">
              <button class="btn btn-sm btn-outline-maroon qty-btn" type="button" data-step="-1">−</button>
              <input type="number" name="qty" value="<?= (int)$i['qty'] ?>" min="1" max="<?= (int)$i['stock_quantity'] ?>" class="form-control form-control-sm qty-input text-center">
              <button class="btn btn-sm btn-outline-maroon qty-btn" type="button" data-step="1">+</button>
            </form>
          </td>
          <td><strong><?= rs($i['line_total']) ?></strong></td>
          <td>
            <form method="post" class="d-inline">
              <?= csrf_field() ?>
              <input type="hidden" name="action" value="remove">
              <input type="hidden" name="pid" value="<?= (int)$i['id'] ?>">
              <button class="btn btn-sm btn-outline-danger" type="submit" aria-label="Remove"><i class="bi bi-trash"></i></button>
            </form>
          </td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>

  <div class="row">
    <div class="col-md-6 mb-3">
      <form method="post" class="d-flex gap-2">
        <?= csrf_field() ?>
        <input type="hidden" name="action" value="<?= isset($_SESSION['coupon_code']) ? 'coupon_remove' : 'coupon' ?>">
        <input class="form-control" name="coupon" placeholder="Coupon code"
               value="<?= esc($_SESSION['coupon_code'] ?? '') ?>" <?= isset($_SESSION['coupon_code']) ? 'disabled' : '' ?>>
        <button class="btn btn-outline-maroon" type="submit"><?= isset($_SESSION['coupon_code']) ? 'Remove' : 'Apply' ?></button>
      </form>
    </div>
    <div class="col-md-6">
      <div class="card"><div class="card-body">
        <p class="d-flex justify-content-between mb-1"><span>Subtotal</span><strong><?= rs($subtotal) ?></strong></p>
        <p class="small text-muted">Delivery fee &amp; discounts are calculated at checkout.</p>
        <a href="checkout.php" class="btn btn-maroon w-100 btn-lg">Proceed to Checkout</a>
        <a href="products.php" class="btn btn-link w-100">Continue shopping</a>
      </div></div>
    </div>
  </div>
<?php endif; ?>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
