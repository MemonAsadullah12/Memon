<?php
// Checkout — guest by default, account optional.
// All business rules (zone, prices, stock, coupon) are re-validated server-side
// inside ONE database transaction. Payment is never marked paid from this form.
$page_title = 'Checkout';
require_once __DIR__ . '/includes/header.php';
$pdo = db();

$items = cart_items();
if (!$items) { flash('Your cart is empty.', 'info'); redirect('products.php'); }
$customer = current_customer();

// Payment methods: COD always; bank / Easypaisa / JazzCash only when the
// matching business_settings flag is enabled (seeded as payment_bank etc.).
$payMethods = ['cod' => 'Cash on Delivery'];
if (pay_enabled('payment_bank'))     $payMethods['bank']      = 'Bank Transfer';
if (pay_enabled('payment_easypaisa')) $payMethods['easypaisa'] = 'Easypaisa';
if (pay_enabled('payment_jazzcash'))  $payMethods['jazzcash']  = 'JazzCash';

// Thrown when a generated order number collides (rare race); the caller retries.
class OrderConflict extends Exception {}

/**
 * Validates everything and creates the order inside a single transaction.
 * Returns an error message string, or null on success (success redirects away).
 */
function place_order(PDO $pdo, array $d, array $items): ?string {
    $pdo->beginTransaction();
    try {
        // --- (2) Delivery zone: active zone whose `areas` mentions the area/city,
        // --- else the first active zone. City must be covered by some zone or be the home city.
        $zones = $pdo->query("SELECT * FROM delivery_zones WHERE is_active = 1 ORDER BY id")->fetchAll();
        $zone = null;
        foreach ($zones as $z) {
            $areas = $z['areas'] ?? '';
            if (stripos($areas, $d['area']) !== false || stripos($areas, $d['city']) !== false) { $zone = $z; break; }
        }
        if (!$zone) $zone = $zones[0] ?? null;
        $covered = $zone !== null && (
            strcasecmp(trim($d['city']), CITY) === 0 ||
            array_reduce($zones, fn($c, $z) => $c || stripos($z['areas'] ?? '', $d['city']) !== false, false)
        );
        if (!$covered)          { $pdo->rollBack(); return 'Sorry, we currently deliver only within ' . CITY . '.'; }
        if ($zone === null)     { $pdo->rollBack(); return 'Delivery zones are not configured. Please call ' . ORDER_PHONE . '.'; }

        // --- (3) Recheck prices + stock with row locks.
        $lines = []; $subtotal = 0;
        $lock = $pdo->prepare("SELECT * FROM products WHERE id = ? AND is_active = 1 FOR UPDATE");
        foreach ($items as $ci) {
            $lock->execute([(int)$ci['id']]);
            $p = $lock->fetch();
            if (!$p) { $pdo->rollBack(); return 'A product in your cart is no longer available.'; }
            $qty = (int)$ci['qty'];
            if ((int)$p['stock_quantity'] < $qty) {
                $pdo->rollBack();
                return '"' . $p['name'] . '" only has ' . (int)$p['stock_quantity'] . ' pack(s) left.';
            }
            $price = product_price($p);
            $lines[] = ['p' => $p, 'qty' => $qty, 'price' => $price];
            $subtotal += $price * $qty;
        }

        // --- (4) Coupon validation (server-side only; never trust the session value).
        $couponId = null; $discount = 0;
        if ($d['coupon'] !== '') {
            $st = $pdo->prepare("SELECT * FROM coupons WHERE code = ? LIMIT 1");
            $st->execute([$d['coupon']]);
            $cp = $st->fetch();
            $now = date('Y-m-d H:i:s');
            if (!$cp || !(int)$cp['is_active']) {
                $pdo->rollBack(); return 'Coupon code is invalid.';
            } elseif ($cp['starts_at'] && $cp['starts_at'] > $now) {
                $pdo->rollBack(); return 'This coupon is not active yet.';
            } elseif ($cp['ends_at'] && $cp['ends_at'] < $now) {
                $pdo->rollBack(); return 'This coupon has expired.';
            } elseif ($subtotal < (int)$cp['min_order']) {
                $pdo->rollBack(); return 'This coupon needs a minimum order of ' . rs((int)$cp['min_order']) . '.';
            }
            if ((int)$cp['usage_limit'] > 0) {
                $u = $pdo->prepare("SELECT COUNT(*) FROM coupon_redemptions WHERE coupon_id = ?");
                $u->execute([(int)$cp['id']]);
                if ((int)$u->fetchColumn() >= (int)$cp['usage_limit']) {
                    $pdo->rollBack(); return 'This coupon has reached its usage limit.';
                }
            }
            if ((int)$cp['per_customer_limit'] > 0) {
                $u = $pdo->prepare("SELECT COUNT(*) FROM coupon_redemptions WHERE coupon_id = ? AND customer_phone = ?");
                $u->execute([(int)$cp['id'], $d['phone']]);
                if ((int)$u->fetchColumn() >= (int)$cp['per_customer_limit']) {
                    $pdo->rollBack(); return 'You have already used this coupon the maximum times allowed.';
                }
            }
            // Product / category restrictions.
            $rp = $pdo->prepare("SELECT product_id FROM coupon_products WHERE coupon_id = ?");
            $rp->execute([(int)$cp['id']]);
            $onlyP = $rp->fetchAll(PDO::FETCH_COLUMN);
            $rc = $pdo->prepare("SELECT category_id FROM coupon_categories WHERE coupon_id = ?");
            $rc->execute([(int)$cp['id']]);
            $onlyC = $rc->fetchAll(PDO::FETCH_COLUMN);
            if ($onlyP || $onlyC) {
                $ok = false;
                foreach ($lines as $ln) {
                    if (in_array((int)$ln['p']['id'], array_map('intval', $onlyP), true)
                        || in_array($ln['p']['category_id'], array_map('intval', $onlyC), true)) { $ok = true; break; }
                }
                if (!$ok) { $pdo->rollBack(); return 'This coupon does not apply to the items in your cart.'; }
            }
            $couponId = (int)$cp['id'];
            if ($cp['discount_type'] === 'percent') {
                $discount = (int)floor($subtotal * (float)$cp['discount_value'] / 100);
                if ((int)$cp['max_discount'] > 0) $discount = min($discount, (int)$cp['max_discount']);
            } else {
                $discount = min((int)$cp['discount_value'], $subtotal);
            }
        }

        // --- (2b) Minimum order + delivery fee (free when net subtotal >= free_above).
        if ($subtotal < (int)$zone['min_order']) {
            $pdo->rollBack();
            return 'Minimum order for ' . $zone['name'] . ' is ' . rs((int)$zone['min_order']) . '.';
        }
        $freeAbove = (int)($zone['free_above'] ?? 0);
        $fee = ($freeAbove > 0 && ($subtotal - $discount) >= $freeAbove) ? 0 : (int)$zone['delivery_fee'];

        // --- (5) Create order + items + history, decrement stock, record everything.
        $total = $subtotal - $discount + $fee;
        try {
            $orderNo = order_no($pdo);
            $token = bin2hex(random_bytes(16)); // 32 chars, matches tracking_token CHAR(32)
            $st = $pdo->prepare(
                "INSERT INTO orders (order_number, customer_id, customer_name, customer_phone, whatsapp_number,
                 delivery_address, area, city, landmark, delivery_zone_id, subtotal, discount_amount, delivery_fee,
                 tax_amount, total_amount, payment_method, payment_status, order_status, customer_notes, tracking_token, created_at)
                 VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?, ?,NOW())"
            );
            // NOTE: payment_status stays 'pending' — non-COD payments are NEVER
            // marked paid from this form; the team verifies them manually.
            $st->execute([
                $orderNo, $d['customer_id'], $d['name'], $d['phone'], $d['whatsapp'] ?: null,
                $d['address'], $d['area'], $d['city'], $d['landmark'] ?: null, (int)$zone['id'],
                $subtotal, $discount, $fee, 0, $total, $d['pay'], 'pending', 'received',
                $d['notes'] ?: null, $token,
            ]);
            $oid = (int)$pdo->lastInsertId();

            $it = $pdo->prepare(
                "INSERT INTO order_items (order_id, product_id, product_name_snapshot, sku_snapshot,
                 pack_size_snapshot, quantity, unit_price, discount_amount, line_total)
                 VALUES (?,?,?,?,?,?,?,?,?)"
            );
            $decP = $pdo->prepare("UPDATE products SET stock_quantity = stock_quantity - ? WHERE id = ?");
            $decI = $pdo->prepare("UPDATE inventory SET quantity = quantity - ? WHERE product_id = ?");
            $mv = $pdo->prepare(
                "INSERT INTO stock_movements (product_id, change_qty, movement_type, reference_type, reference_id, notes, admin_id, created_at)
                 VALUES (?,?, 'sold', 'order', ?, ?, NULL, NOW())"
            );
            foreach ($lines as $ln) {
                $p = $ln['p']; $qty = $ln['qty']; $price = $ln['price'];
                $it->execute([$oid, (int)$p['id'], $p['name'], $p['sku'], $p['pack_size'], $qty, $price, 0, $price * $qty]);
                $decP->execute([$qty, (int)$p['id']]);
                $decI->execute([$qty, (int)$p['id']]);
                $mv->execute([(int)$p['id'], -$qty, $oid, 'Order ' . $orderNo]);
            }

            $pdo->prepare(
                "INSERT INTO order_status_history (order_id, old_status, new_status, note, admin_id, created_at)
                 VALUES (?, NULL, 'received', 'Order placed', NULL, NOW())"
            )->execute([$oid]);

            if ($couponId) {
                $pdo->prepare(
                    "INSERT INTO coupon_redemptions (coupon_id, order_id, customer_phone, discount_amount)
                     VALUES (?,?,?,?)"
                )->execute([$couponId, $oid, $d['phone'], $discount]);
            }

            $pdo->prepare(
                "INSERT INTO notifications (type, title, message, link, is_read, created_at)
                 VALUES ('order', ?, ?, 'orders.php', 0, NOW())"
            )->execute(['New order ' . $orderNo, $d['name'] . ' (' . $d['phone'] . ') — ' . rs($total)]);
        } catch (PDOException $e) {
            if ($pdo->inTransaction()) $pdo->rollBack();
            // Unique order_number collision under concurrency → caller retries with a fresh number.
            if ($e->getCode() === '23000') throw new OrderConflict();
            throw $e;
        }

        $pdo->commit();
        cart_clear();
        redirect('order-success.php?o=' . urlencode($orderNo) . '&t=' . $token);
        return null; // unreachable
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        throw $e;
    }
}

// ---------- POST handling ----------
$err = '';
$old = $_POST;

if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST') {
    csrf_check();
    // (1) Validate customer details first — no DB transaction needed for this.
    $d = [
        'customer_id' => $customer['id'] ?? null,
        'name'     => trim($_POST['name'] ?? ''),
        'phone'    => clean_phone($_POST['phone'] ?? ''),
        'whatsapp' => clean_phone($_POST['whatsapp'] ?? ''),
        'address'  => trim($_POST['address'] ?? ''),
        'area'     => trim($_POST['area'] ?? ''),
        'city'     => trim($_POST['city'] ?? ''),
        'landmark' => trim($_POST['landmark'] ?? ''),
        'notes'    => trim($_POST['notes'] ?? ''),
        'pay'      => $_POST['payment_method'] ?? 'cod',
        'coupon'   => strtoupper(trim($_POST['coupon'] ?? ($_SESSION['coupon_code'] ?? ''))),
    ];
    if ($d['name'] === '' || mb_strlen($d['name']) < 3)       $err = 'Please enter your full name.';
    elseif (!valid_mobile($d['phone']))                      $err = 'Please enter a valid 10–11 digit mobile number.';
    elseif ($d['address'] === '' || mb_strlen($d['address']) < 5) $err = 'Please enter your complete delivery address.';
    elseif ($d['area'] === '')                                $err = 'Please enter your area / mohalla.';
    elseif ($d['city'] === '')                                $err = 'Please enter your city.';
    elseif (!isset($payMethods[$d['pay']]))                   $err = 'Invalid payment method.';

    if ($err === '') {
        $attempts = 0;
        while ($attempts < 3) {
            $attempts++;
            try {
                $err = place_order($pdo, $d, $items) ?? '';
                break;
            } catch (OrderConflict $e) {
                continue; // retry with a freshly generated order number
            } catch (Throwable $e) {
                error_log('Checkout failed: ' . $e->getMessage());
                $err = 'Something went wrong while placing your order. Please try again or call ' . ORDER_PHONE . '.';
                break;
            }
        }
    }
}
?>

<h1 class="page-heading">Checkout</h1>
<?php if ($err): ?><div class="alert alert-danger"><?= esc($err) ?></div><?php endif; ?>

<div class="row">
  <div class="col-md-7">
    <form method="post" id="checkoutForm">
      <?= csrf_field() ?>
      <div class="card mb-3"><div class="card-body">
        <h5>Delivery Details</h5>
        <div class="row g-2">
          <div class="col-md-6"><label class="form-label">Full Name *</label>
            <input class="form-control" name="name" required maxlength="100" value="<?= esc($old['name'] ?? $customer['name'] ?? '') ?>"></div>
          <div class="col-md-6"><label class="form-label">Mobile Number *</label>
            <input class="form-control" name="phone" required maxlength="13" placeholder="03xx-xxxxxxx" value="<?= esc($old['phone'] ?? $customer['phone'] ?? '') ?>"></div>
          <div class="col-md-6"><label class="form-label">WhatsApp (optional)</label>
            <input class="form-control" name="whatsapp" maxlength="13" value="<?= esc($old['whatsapp'] ?? $customer['whatsapp_number'] ?? '') ?>"></div>
          <div class="col-md-6"><label class="form-label">City *</label>
            <input class="form-control" name="city" required maxlength="60" value="<?= esc($old['city'] ?? CITY) ?>"></div>
          <div class="col-md-6"><label class="form-label">Area / Mohalla *</label>
            <input class="form-control" name="area" required maxlength="80" value="<?= esc($old['area'] ?? '') ?>"></div>
          <div class="col-md-6"><label class="form-label">Landmark (optional)</label>
            <input class="form-control" name="landmark" maxlength="100" value="<?= esc($old['landmark'] ?? '') ?>"></div>
          <div class="col-12"><label class="form-label">Complete Address *</label>
            <textarea class="form-control" name="address" rows="2" required><?= esc($old['address'] ?? '') ?></textarea></div>
          <div class="col-12"><label class="form-label">Order Notes (optional)</label>
            <textarea class="form-control" name="notes" rows="2"><?= esc($old['notes'] ?? '') ?></textarea></div>
        </div>
      </div></div>

      <div class="card mb-3"><div class="card-body">
        <h5>Payment Method</h5>
        <?php foreach ($payMethods as $k => $label): ?>
          <div class="form-check">
            <input class="form-check-input" type="radio" name="payment_method" id="pm_<?= esc($k) ?>" value="<?= esc($k) ?>"
                   <?= (($old['payment_method'] ?? 'cod') === $k) ? 'checked' : '' ?>>
            <label class="form-check-label" for="pm_<?= esc($k) ?>"><?= esc($label) ?></label>
          </div>
        <?php endforeach; ?>
        <p class="small text-muted mt-2">Pay cash when your order arrives. Online payments are confirmed by our team after verification.</p>
      </div></div>

      <div class="card mb-3"><div class="card-body">
        <h5>Coupon</h5>
        <input class="form-control" name="coupon" placeholder="Coupon code (optional)" value="<?= esc($_SESSION['coupon_code'] ?? '') ?>">
      </div></div>

      <button class="btn btn-maroon btn-lg w-100 mb-3" type="submit">Place Order</button>
    </form>
  </div>
  <div class="col-md-5">
    <div class="card"><div class="card-body">
      <h5>Order Summary</h5>
      <?php foreach ($items as $i): ?>
        <p class="d-flex justify-content-between small mb-1">
          <span><?= esc($i['name']) ?> × <?= (int)$i['qty'] ?></span><span><?= rs($i['line_total']) ?></span>
        </p>
      <?php endforeach; ?>
      <hr>
      <p class="d-flex justify-content-between"><span>Subtotal</span><strong><?= rs(cart_subtotal()) ?></strong></p>
      <p class="small text-muted">Delivery fee &amp; coupon discount are calculated when you place the order.</p>
    </div></div>
  </div>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
