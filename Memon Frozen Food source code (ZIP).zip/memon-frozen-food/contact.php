<?php
// Contact: form saves a notification for the admin + offers WhatsApp click-to-chat.
// We never pretend the message was auto-sent.
$page_title = 'Contact Us';
require_once __DIR__ . '/includes/header.php';

if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST') {
    csrf_check();
    $name = trim($_POST['name'] ?? '');
    $phone = clean_phone($_POST['phone'] ?? '');
    $msg = trim($_POST['message'] ?? '');
    if ($name === '' || !valid_mobile($phone) || $msg === '') {
        flash('Please fill in your name, a valid mobile number and your message.', 'danger');
    } else {
        try {
            $st = db()->prepare("INSERT INTO notifications (type, title, message, link, is_read, created_at)
                                 VALUES ('contact', ?, ?, NULL, 0, NOW())");
            $st->execute(['Contact: ' . $name . ' (' . $phone . ')', $msg]);
            flash('Thank you! Your message has been saved — our team will get back to you soon. For a faster reply, message us on WhatsApp below.');
        } catch (Throwable $e) {
            flash('Could not save your message right now. Please WhatsApp us instead.', 'danger');
        }
    }
    redirect('contact.php');
}
?>

<h1 class="page-heading">Contact Us</h1>
<div class="row">
  <div class="col-md-6 mb-3">
    <div class="card"><div class="card-body">
      <h5>Send us a message</h5>
      <form method="post">
        <?= csrf_field() ?>
        <div class="mb-2"><label class="form-label">Your Name *</label>
          <input class="form-control" name="name" required maxlength="100"></div>
        <div class="mb-2"><label class="form-label">Mobile Number *</label>
          <input class="form-control" name="phone" required maxlength="13" placeholder="03xx-xxxxxxx"></div>
        <div class="mb-2"><label class="form-label">Message *</label>
          <textarea class="form-control" name="message" rows="4" required></textarea></div>
        <button class="btn btn-maroon" type="submit">Send Message</button>
      </form>
    </div></div>
  </div>
  <div class="col-md-6">
    <div class="card"><div class="card-body">
      <h5>Reach us directly</h5>
      <p><i class="bi bi-telephone"></i> <strong><?= esc(ORDER_PHONE) ?></strong></p>
      <p><i class="bi bi-geo-alt"></i> <?= esc(CITY) ?> (delivery within city only)</p>
      <a class="btn btn-success" target="_blank" rel="noopener"
         href="<?= whatsapp_link('Assalam-o-Alaikum! I have a question for Memon Frozen Food.') ?>">
        <i class="bi bi-whatsapp"></i> Chat on WhatsApp
      </a>
    </div></div>
  </div>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
