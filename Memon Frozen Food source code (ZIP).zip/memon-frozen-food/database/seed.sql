-- =============================================================
-- Memon Frozen Food - Seed Data
-- Run AFTER schema.sql. Every statement ends with ";" + newline.
-- Uses INSERT IGNORE / NOT EXISTS guards so the file is safe to
-- run more than once. No user accounts are seeded here - the
-- installer (install.php) creates the first Super Admin.
-- =============================================================

-- ---------- Business settings ----------
INSERT IGNORE INTO `business_settings` (`setting_key`, `setting_value`) VALUES
('site_name', 'Memon Frozen Food'),
('tagline', 'Hygienic Taste'),
('tagline2', 'Fresh & Hygienic Frozen Foods'),
('order_phone', '0300-3130608'),
('whatsapp_number', '923003130608'),
('city', 'Khairpur Mirs'),
('currency', 'Rs.'),
('delivery_fee', '150'),
('min_order', '500'),
('free_delivery_above', '3000'),
('payment_cod', '1'),
('payment_bank', '0'),
('payment_easypaisa', '0'),
('payment_jazzcash', '0'),
('maintenance_mode', '0'),
('announcement_text', '');

-- ---------- Roles ----------
INSERT IGNORE INTO `roles` (`name`, `description`) VALUES
('Super Admin', 'Full access to every part of the system'),
('Store Manager', 'Manages day to day store operations except users and backups'),
('Order Manager', 'Handles orders, deliveries and customers'),
('Inventory Manager', 'Manages products and stock'),
('Delivery Manager', 'Manages deliveries and riders'),
('Accountant', 'Handles payments, expenses and reports'),
('Content Manager', 'Manages products, categories and website content');

-- ---------- Permissions (30 codes) ----------
INSERT IGNORE INTO `permissions` (`code`, `description`) VALUES
('dashboard.view', 'View the admin dashboard'),
('products.view', 'View products'),
('products.create', 'Create new products'),
('products.edit', 'Edit products'),
('products.delete', 'Delete products'),
('products.export', 'Export products'),
('categories.manage', 'Manage product categories'),
('orders.view', 'View orders'),
('orders.edit', 'Edit and update orders'),
('orders.print', 'Print order invoices and receipts'),
('inventory.view', 'View inventory and stock levels'),
('inventory.edit', 'Adjust inventory and stock'),
('customers.view', 'View customers'),
('customers.edit', 'Edit customer records'),
('customers.export', 'Export customers'),
('deliveries.view', 'View deliveries'),
('deliveries.edit', 'Manage delivery assignments'),
('coupons.manage', 'Manage discount coupons'),
('payments.view', 'View payments'),
('payments.edit', 'Record and edit payments'),
('expenses.view', 'View expenses'),
('expenses.edit', 'Record and edit expenses'),
('reports.view', 'View business reports'),
('reports.export', 'Export reports'),
('notifications.view', 'View notifications'),
('settings.edit', 'Edit business settings'),
('content.edit', 'Edit website content pages and banners'),
('users.manage', 'Manage admin users and roles'),
('backups.run', 'Run database backups'),
('audit.view', 'View audit logs');

-- ---------- Role -> permission mapping ----------
INSERT IGNORE INTO `role_permissions` (`role_id`, `permission_id`)
SELECT r.id, p.id FROM `roles` r CROSS JOIN `permissions` p WHERE r.name = 'Super Admin';

INSERT IGNORE INTO `role_permissions` (`role_id`, `permission_id`)
SELECT r.id, p.id FROM `roles` r CROSS JOIN `permissions` p
WHERE r.name = 'Store Manager' AND p.code NOT IN ('users.manage', 'backups.run');

INSERT IGNORE INTO `role_permissions` (`role_id`, `permission_id`)
SELECT r.id, p.id FROM `roles` r JOIN `permissions` p
ON p.code IN ('dashboard.view', 'orders.view', 'orders.edit', 'orders.print', 'deliveries.view', 'deliveries.edit', 'customers.view', 'notifications.view')
WHERE r.name = 'Order Manager';

INSERT IGNORE INTO `role_permissions` (`role_id`, `permission_id`)
SELECT r.id, p.id FROM `roles` r JOIN `permissions` p
ON p.code IN ('dashboard.view', 'products.view', 'inventory.view', 'inventory.edit', 'notifications.view')
WHERE r.name = 'Inventory Manager';

INSERT IGNORE INTO `role_permissions` (`role_id`, `permission_id`)
SELECT r.id, p.id FROM `roles` r JOIN `permissions` p
ON p.code IN ('dashboard.view', 'orders.view', 'deliveries.view', 'deliveries.edit', 'notifications.view')
WHERE r.name = 'Delivery Manager';

INSERT IGNORE INTO `role_permissions` (`role_id`, `permission_id`)
SELECT r.id, p.id FROM `roles` r JOIN `permissions` p
ON p.code IN ('dashboard.view', 'orders.view', 'payments.view', 'payments.edit', 'expenses.view', 'expenses.edit', 'reports.view', 'reports.export')
WHERE r.name = 'Accountant';

INSERT IGNORE INTO `role_permissions` (`role_id`, `permission_id`)
SELECT r.id, p.id FROM `roles` r JOIN `permissions` p
ON p.code IN ('dashboard.view', 'products.view', 'categories.manage', 'content.edit', 'notifications.view')
WHERE r.name = 'Content Manager';

-- ---------- Categories ----------
INSERT IGNORE INTO `categories` (`name`, `slug`, `description`, `sort_order`, `is_active`) VALUES
('Chicken Snacks', 'chicken-snacks', 'Crispy and tasty chicken snacks for the whole family', 1, 1),
('Kababs', 'kababs', 'Juicy kababs made from minced chicken and spices', 2, 1),
('Nuggets', 'nuggets', 'Golden crispy nuggets that kids love', 3, 1),
('Rolls', 'rolls', 'Crispy rolls with delicious fillings', 4, 1),
('Kofta & Meatballs', 'kofta-meatballs', 'Soft and flavourful koftas for curries and BBQ', 5, 1),
('Family Deals', 'family-deals', 'Value packs for the whole family', 6, 1);

-- ---------- Products (all Rs. 1000) ----------
INSERT IGNORE INTO `products`
(`sku`, `category_id`, `name`, `slug`, `description`, `ingredients`, `allergen_information`, `pack_size`, `pieces_per_pack`, `cost_price`, `selling_price`, `discount_price`, `stock_quantity`, `low_stock_threshold`, `is_featured`, `is_bestseller`, `is_active`)
VALUES
('MFF-SK-001', (SELECT id FROM `categories` WHERE `slug` = 'kababs'), 'Chicken Shami Kabab', 'chicken-shami-kabab',
'Juicy chicken shami kababs made from finely minced chicken, black lentils and traditional spices. A family favourite for tea-time, lunch boxes and quick dinners. Storage: keep frozen at -18C. To prepare: shallow-fry from frozen until golden on both sides. Do not refreeze after thawing.',
'Chicken, black lentils, onion, green chillies, ginger, garlic, coriander, traditional spices, salt, cooking oil',
'Contains lentils. Prepared in a kitchen that also handles wheat and egg.',
'Family Pack', 40, 800, 1000, NULL, 100, 10, 1, 1, 1);

INSERT IGNORE INTO `products`
(`sku`, `category_id`, `name`, `slug`, `description`, `ingredients`, `allergen_information`, `pack_size`, `pieces_per_pack`, `cost_price`, `selling_price`, `discount_price`, `stock_quantity`, `low_stock_threshold`, `is_featured`, `is_bestseller`, `is_active`)
VALUES
('MFF-CK-002', (SELECT id FROM `categories` WHERE `slug` = 'kofta-meatballs'), 'Chicken Kofta', 'chicken-kofta',
'Tender chicken koftas seasoned with fresh herbs and mild spices. Perfect for rich curries or served BBQ-style with naan. Storage: keep frozen at -18C. To prepare: cook from frozen in your favourite curry or pan-fry until cooked through. Do not refreeze after thawing.',
'Chicken, onion, green chillies, ginger, garlic, coriander, mint, traditional spices, salt',
'Prepared in a kitchen that also handles wheat and egg.',
'Family Pack', 20, 800, 1000, NULL, 100, 10, 1, 1, 1);

INSERT IGNORE INTO `products`
(`sku`, `category_id`, `name`, `slug`, `description`, `ingredients`, `allergen_information`, `pack_size`, `pieces_per_pack`, `cost_price`, `selling_price`, `discount_price`, `stock_quantity`, `low_stock_threshold`, `is_featured`, `is_bestseller`, `is_active`)
VALUES
('MFF-CN-003', (SELECT id FROM `categories` WHERE `slug` = 'nuggets'), 'Chicken Nuggets', 'chicken-nuggets',
'Crispy on the outside and juicy inside, our chicken nuggets are a hit with kids and adults alike. Storage: keep frozen at -18C. To prepare: deep-fry, air-fry or bake from frozen until golden and hot through. Do not refreeze after thawing.',
'Chicken, breadcrumbs, flour, corn starch, spices, salt, cooking oil',
'Contains wheat (gluten). Prepared in a kitchen that also handles egg.',
'Family Pack', 30, 800, 1000, NULL, 100, 10, 1, 1, 1);

INSERT IGNORE INTO `products`
(`sku`, `category_id`, `name`, `slug`, `description`, `ingredients`, `allergen_information`, `pack_size`, `pieces_per_pack`, `cost_price`, `selling_price`, `discount_price`, `stock_quantity`, `low_stock_threshold`, `is_featured`, `is_bestseller`, `is_active`)
VALUES
('MFF-SR-004', (SELECT id FROM `categories` WHERE `slug` = 'rolls'), 'Chicken Spring Roll', 'chicken-spring-roll',
'Delicious spring rolls filled with savoury chicken and vegetables, wrapped in a thin crispy shell. Storage: keep frozen at -18C. To prepare: deep-fry or air-fry from frozen until crisp and golden. Do not refreeze after thawing.',
'Chicken, cabbage, carrot, spring onion, flour sheets, soy sauce, spices, salt, cooking oil',
'Contains wheat (gluten) and soy. Prepared in a kitchen that also handles egg.',
'Family Pack', 30, 800, 1000, NULL, 100, 10, 1, 1, 1);

-- ---------- Inventory (mirrors product stock) ----------
INSERT IGNORE INTO `inventory` (`product_id`, `quantity`)
SELECT id, 100 FROM `products` WHERE `sku` = 'MFF-SK-001';

INSERT IGNORE INTO `inventory` (`product_id`, `quantity`)
SELECT id, 100 FROM `products` WHERE `sku` = 'MFF-CK-002';

INSERT IGNORE INTO `inventory` (`product_id`, `quantity`)
SELECT id, 100 FROM `products` WHERE `sku` = 'MFF-CN-003';

INSERT IGNORE INTO `inventory` (`product_id`, `quantity`)
SELECT id, 100 FROM `products` WHERE `sku` = 'MFF-SR-004';

-- ---------- Delivery zone ----------
INSERT INTO `delivery_zones` (`name`, `areas`, `delivery_fee`, `min_order`, `free_above`, `is_active`)
SELECT 'Khairpur Mirs', 'Khairpur Mirs', 150, 500, 3000, 1 FROM DUAL
WHERE NOT EXISTS (SELECT 1 FROM `delivery_zones` WHERE `name` = 'Khairpur Mirs');

-- ---------- Expense categories ----------
INSERT IGNORE INTO `expense_categories` (`name`) VALUES
('Rent'), ('Utilities'), ('Salaries'), ('Packaging'), ('Transport'), ('Marketing'), ('Other');

-- ---------- FAQs ----------
INSERT INTO `faqs` (`question`, `answer`, `sort_order`, `is_active`)
SELECT 'Which areas do you deliver to?', 'We currently deliver within Khairpur Mirs city only. Delivery fee is Rs. 150, and delivery is free on orders above Rs. 3000.', 1, 1 FROM DUAL
WHERE NOT EXISTS (SELECT 1 FROM `faqs` WHERE `question` = 'Which areas do you deliver to?');

INSERT INTO `faqs` (`question`, `answer`, `sort_order`, `is_active`)
SELECT 'How do I place an order?', 'Browse our products, add them to your cart and check out on this website as a guest. You can also call or WhatsApp us on 0300-3130608 and we will take your order.', 2, 1 FROM DUAL
WHERE NOT EXISTS (SELECT 1 FROM `faqs` WHERE `question` = 'How do I place an order?');

INSERT INTO `faqs` (`question`, `answer`, `sort_order`, `is_active`)
SELECT 'What payment methods do you accept?', 'We accept Cash on Delivery. Please keep the order amount ready when our rider arrives.', 3, 1 FROM DUAL
WHERE NOT EXISTS (SELECT 1 FROM `faqs` WHERE `question` = 'What payment methods do you accept?');

INSERT INTO `faqs` (`question`, `answer`, `sort_order`, `is_active`)
SELECT 'How should I store the frozen food?', 'Keep all products frozen at -18C until you are ready to cook. Cook from frozen as instructed on the pack, and do not refreeze after thawing.', 4, 1 FROM DUAL
WHERE NOT EXISTS (SELECT 1 FROM `faqs` WHERE `question` = 'How should I store the frozen food?');

-- ---------- Pages ----------
INSERT INTO `pages` (`slug`, `title`, `content`, `is_active`)
SELECT 'about-us', 'About Us', 'Memon Frozen Food (Hygienic Taste) is a family-run frozen food business in Khairpur Mirs, Pakistan. We prepare fresh and hygienic frozen foods including shami kababs, koftas, nuggets and spring rolls in small batches, and deliver them to your doorstep within Khairpur Mirs. Our promise is simple: delicious, ready-to-cook food your family will love. To order, call or WhatsApp 0300-3130608.', 1 FROM DUAL
WHERE NOT EXISTS (SELECT 1 FROM `pages` WHERE `slug` = 'about-us');

INSERT INTO `pages` (`slug`, `title`, `content`, `is_active`)
SELECT 'delivery-policy', 'Delivery Policy', 'We deliver within Khairpur Mirs city only. Delivery fee is Rs. 150 per order and delivery is free on orders above Rs. 3000. The minimum order is Rs. 500. Orders are usually delivered the same day or the next day. Please make sure your phone is reachable so our rider can find your address easily.', 1 FROM DUAL
WHERE NOT EXISTS (SELECT 1 FROM `pages` WHERE `slug` = 'delivery-policy');

INSERT INTO `pages` (`slug`, `title`, `content`, `is_active`)
SELECT 'privacy-policy', 'Privacy Policy', 'We collect your name, phone number and delivery address only so we can process and deliver your order. We never sell or share your personal information with anyone except the delivery staff who need it to reach you. You can ask us to update or delete your information at any time by calling 0300-3130608.', 1 FROM DUAL
WHERE NOT EXISTS (SELECT 1 FROM `pages` WHERE `slug` = 'privacy-policy');

INSERT INTO `pages` (`slug`, `title`, `content`, `is_active`)
SELECT 'terms', 'Terms of Service', 'All prices are in Pakistani Rupees and include no hidden charges. Payment is Cash on Delivery. Once an order is confirmed and being prepared, it cannot be changed or cancelled, but you may refuse a delivery at your door before accepting it. We reserve the right to refuse service or cancel orders in case of incorrect pricing or unavailable stock, in which case you will be informed by phone.', 1 FROM DUAL
WHERE NOT EXISTS (SELECT 1 FROM `pages` WHERE `slug` = 'terms');

INSERT INTO `pages` (`slug`, `title`, `content`, `is_active`)
SELECT 'refund-policy', 'Refund Policy', 'Because our products are perishable frozen foods, we cannot accept returns of thawed items. If your order arrives damaged, melted or incorrect, please contact us on 0300-3130608 within 24 hours with photos of the items, and we will replace them or refund the amount.', 1 FROM DUAL
WHERE NOT EXISTS (SELECT 1 FROM `pages` WHERE `slug` = 'refund-policy');

-- ---------- Banner ----------
INSERT INTO `banners` (`title`, `image`, `link_url`, `sort_order`, `is_active`)
SELECT 'Fresh & Hygienic Frozen Foods', NULL, 'products.php', 0, 1 FROM DUAL
WHERE NOT EXISTS (SELECT 1 FROM `banners` WHERE `title` = 'Fresh & Hygienic Frozen Foods');
