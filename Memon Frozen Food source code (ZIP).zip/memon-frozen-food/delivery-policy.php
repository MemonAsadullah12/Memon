<?php
$page_title = 'Delivery Policy';
require_once __DIR__ . '/includes/header.php';
?>
<h1 class="page-heading">Delivery Policy</h1>
<ul>
  <li>We deliver <strong>within <?= esc(CITY) ?> only</strong>.</li>
  <li>Delivery fees and free-delivery thresholds are set per delivery zone and shown at checkout before you place the order.</li>
  <li>Orders are delivered frozen in sealed packs. Please be available at the delivery address and store the products in your freezer immediately.</li>
  <li>Delivery times depend on your zone and order volume — our team confirms the time when they call to confirm your order.</li>
  <li>Minimum order values may apply per zone and are shown at checkout.</li>
  <li>If no one is available to receive the order, we will try to contact you on the number provided; repeated failed attempts may lead to cancellation.</li>
</ul>
<p>Questions? Call <strong><?= esc(ORDER_PHONE) ?></strong>.</p>
<?php require_once __DIR__ . '/includes/footer.php'; ?>
