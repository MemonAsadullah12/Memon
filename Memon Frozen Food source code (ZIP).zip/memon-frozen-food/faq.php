<?php
// FAQs — from `faqs` table, static fallback.
$page_title = 'FAQs';
require_once __DIR__ . '/includes/header.php';
$faqs = [];
try {
    $faqs = db()->query("SELECT question, answer FROM faqs WHERE is_active = 1 ORDER BY sort_order, id")->fetchAll();
} catch (Throwable $e) {}
if (!$faqs) {
    $faqs = [
        ['question' => 'Where do you deliver?', 'answer' => 'We deliver within ' . CITY . ' only.'],
        ['question' => 'How do I pay?', 'answer' => 'Cash on Delivery is available on every order. Online payment options (if shown at checkout) are confirmed by our team after verification.'],
        ['question' => 'How should I store the products?', 'answer' => 'Keep all packs frozen at -18°C or below and cook directly from frozen unless the pack says otherwise.'],
        ['question' => 'How can I track my order?', 'answer' => 'Use the Track Your Order page with your order number and phone number.'],
        ['question' => 'What if something is wrong with my order?', 'answer' => 'Contact us immediately on ' . ORDER_PHONE . ' or WhatsApp and we will make it right — see our Refund Policy.'],
    ];
}
?>
<h1 class="page-heading">Frequently Asked Questions</h1>
<div class="accordion" id="faqAcc">
  <?php foreach ($faqs as $i => $f): ?>
    <div class="accordion-item">
      <h2 class="accordion-header">
        <button class="accordion-button <?= $i ? 'collapsed' : '' ?>" type="button" data-bs-toggle="collapse" data-bs-target="#fq<?= $i ?>">
          <?= esc($f['question']) ?>
        </button>
      </h2>
      <div id="fq<?= $i ?>" class="accordion-collapse collapse <?= $i ? '' : 'show' ?>" data-bs-parent="#faqAcc">
        <div class="accordion-body"><?= nl2br(esc($f['answer'])) ?></div>
      </div>
    </div>
  <?php endforeach; ?>
</div>
<?php require_once __DIR__ . '/includes/footer.php'; ?>
