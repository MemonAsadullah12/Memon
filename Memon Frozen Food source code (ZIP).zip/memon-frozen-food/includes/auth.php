<?php
// Authentication: admins (users JOIN roles) + customers.
//
// Self-sufficient bootstrap: admin pages call require_admin() as their very
// first statement, so this file loads its own dependencies (db, helpers)
// and ensures a session is active. require_once guards make this safe when
// pages also include these files later (e.g. via header.php).
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/helpers.php';
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// ---------- Admin ----------
function admin_login(string $email, string $password): array {
    // Rate limit: max 5 failures per 15 min per IP (session-tracked + audited).
    $ip = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
    $key = 'admin_fail_' . md5($ip);
    $fails = $_SESSION[$key] ?? ['n' => 0, 't' => 0];
    if ($fails['n'] >= 5 && (time() - $fails['t']) < 900) {
        return ['ok' => false, 'msg' => 'Too many failed attempts. Please wait 15 minutes and try again.'];
    }
    // NOTE: users table has no username column — admins sign in with email.
    $st = db()->prepare(
        "SELECT u.*, r.name AS role_name FROM users u LEFT JOIN roles r ON r.id = u.role_id
         WHERE u.email = ? AND u.is_active = 1 LIMIT 1"
    );
    $st->execute([trim($email)]);
    $u = $st->fetch();
    if ($u && password_verify($password, $u['password_hash'])) {
        unset($_SESSION[$key]);
        session_regenerate_id(true);
        $_SESSION['admin_id'] = (int)$u['id'];
        audit((int)$u['id'], 'admin_login', 'user', (int)$u['id']);
        return ['ok' => true, 'user' => $u];
    }
    $fails['n']++; $fails['t'] = time();
    $_SESSION[$key] = $fails;
    audit(null, 'admin_login_failed', null, null, null, ['ip' => $ip, 'email' => $email]);
    return ['ok' => false, 'msg' => 'Invalid email or password.'];
}

function admin_logout(): void {
    unset($_SESSION['admin_id']);
    session_regenerate_id(true);
}

function current_admin(): ?array {
    $id = $_SESSION['admin_id'] ?? 0;
    if (!$id) return null;
    static $cache = null;
    if ($cache === null) {
        $st = db()->prepare(
            "SELECT u.*, r.name AS role_name FROM users u LEFT JOIN roles r ON r.id = u.role_id WHERE u.id = ? LIMIT 1"
        );
        $st->execute([$id]);
        $cache = $st->fetch() ?: null;
    }
    return $cache;
}

function has_perm(string $code): bool {
    $a = current_admin();
    if (!$a) return false;
    static $perms = null;
    if ($perms === null) {
        $perms = [];
        try {
            $st = db()->prepare(
                "SELECT p.code FROM role_permissions rp JOIN permissions p ON p.id = rp.permission_id WHERE rp.role_id = ?"
            );
            $st->execute([(int)$a['role_id']]);
            $perms = $st->fetchAll(PDO::FETCH_COLUMN);
        } catch (Throwable $e) { /* permissions tables optional */ }
    }
    return in_array($code, $perms, true);
}

function require_admin(?string $perm = null): void {
    if (!current_admin()) redirect('login.php');
    if ($perm && !has_perm($perm)) {
        http_response_code(403);
        exit('Access denied: missing permission.');
    }
}

// ---------- Customer ----------
function customer_login(string $phone, string $password): array {
    $st = db()->prepare("SELECT * FROM customers WHERE phone = ? AND is_active = 1 LIMIT 1");
    $st->execute([clean_phone($phone)]);
    $c = $st->fetch();
    if ($c && password_verify($password, $c['password_hash'])) {
        session_regenerate_id(true);
        $_SESSION['customer_id'] = (int)$c['id'];
        return ['ok' => true, 'customer' => $c];
    }
    return ['ok' => false, 'msg' => 'Invalid phone number or password.'];
}

function current_customer(): ?array {
    $id = $_SESSION['customer_id'] ?? 0;
    if (!$id) return null;
    static $cache = null;
    if ($cache === null) {
        $st = db()->prepare("SELECT * FROM customers WHERE id = ? AND is_active = 1 LIMIT 1");
        $st->execute([$id]);
        $cache = $st->fetch() ?: null;
    }
    return $cache;
}

function require_customer(): void {
    if (!current_customer()) redirect('login.php');
}
