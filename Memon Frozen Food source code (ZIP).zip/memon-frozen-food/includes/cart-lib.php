<?php
// Session cart: $_SESSION['cart'] = [product_id => qty]. Coupon code: $_SESSION['coupon_code'].

function cart_raw(): array {
    return $_SESSION['cart'] ?? [];
}

// Effective selling price: discount_price when set and positive, else selling_price.
function product_price(array $p): int {
    $dp = $p['discount_price'] ?? null;
    if ($dp !== null && (float)$dp > 0) return (int)$dp;
    return (int)$p['selling_price'];
}

// Enriched rows (active products only); effective price = discount_price ?? selling_price.
function cart_items(): array {
    $raw = cart_raw();
    if (!$raw) return [];
    $ids = array_map('intval', array_keys($raw));
    $ph  = implode(',', array_fill(0, count($ids), '?'));
    $st  = db()->prepare("SELECT * FROM products WHERE id IN ($ph) AND is_active = 1");
    $st->execute($ids);
    $rows = [];
    foreach ($st->fetchAll() as $p) {
        $qty = min((int)$raw[$p['id']], max(0, (int)$p['stock_quantity']));
        if ($qty < 1) continue;
        $price = product_price($p);
        $p['qty'] = $qty;
        $p['eff_price'] = $price;
        $p['line_total'] = $price * $qty;
        $rows[] = $p;
    }
    return $rows;
}

function cart_add(int $pid, int $qty): string {
    $st = db()->prepare("SELECT id, stock_quantity FROM products WHERE id = ? AND is_active = 1 LIMIT 1");
    $st->execute([$pid]);
    $p = $st->fetch();
    if (!$p) return 'Product not available.';
    if ($qty < 1) return 'Quantity must be at least 1.';
    $have = (int)($_SESSION['cart'][$pid] ?? 0);
    $new  = min($have + $qty, (int)$p['stock_quantity']);
    if ($new < 1) return 'Out of stock.';
    $_SESSION['cart'][$pid] = $new;
    return $have + $qty > (int)$p['stock_quantity'] ? 'Only ' . (int)$p['stock_quantity'] . ' in stock.' : '';
}

function cart_set_qty(int $pid, int $qty): void {
    if ($qty < 1) { cart_remove($pid); return; }
    $st = db()->prepare("SELECT stock_quantity FROM products WHERE id = ? AND is_active = 1 LIMIT 1");
    $st->execute([$pid]);
    $p = $st->fetch();
    if (!$p) { cart_remove($pid); return; }
    $_SESSION['cart'][$pid] = min($qty, (int)$p['stock_quantity']);
}

function cart_remove(int $pid): void {
    unset($_SESSION['cart'][$pid]);
}

function cart_count(): int {
    return array_sum(cart_raw());
}

function cart_subtotal(): int {
    $t = 0;
    foreach (cart_items() as $i) $t += $i['line_total'];
    return $t;
}

function cart_clear(): void {
    unset($_SESSION['cart'], $_SESSION['coupon_code']);
}
