<?php
// Memon Frozen Food — site configuration.
// Public constants (safe). DB credentials come from config.local.php (written by installer / owner).

define('SITE_NAME',  'Memon Frozen Food');
define('TAGLINE',    'Hygienic Taste');
define('TAGLINE2',   'Fresh & Hygienic Frozen Foods');
define('ORDER_PHONE','0300-3130608');
define('WHATSAPP',   '923003130608');   // wa.me number (no +)
define('CITY',       'Khairpur Mirs');
define('CURRENCY',   'Rs.');

// Fallback DB defaults — only used when config.local.php is absent (dev / fresh XAMPP).
if (!defined('DB_HOST')) define('DB_HOST', 'localhost');
if (!defined('DB_NAME')) define('DB_NAME', 'memon_frozen_food');
if (!defined('DB_USER')) define('DB_USER', 'root');
if (!defined('DB_PASS')) define('DB_PASS', '');

// Real credentials live here (created by install.php or manually on shared hosting).
if (file_exists(__DIR__ . '/config.local.php')) {
    require __DIR__ . '/config.local.php';
}
