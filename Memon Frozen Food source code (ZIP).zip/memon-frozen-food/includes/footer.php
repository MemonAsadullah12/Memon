<?php // Public layout footer. $ROOT mirrors header.php. ?>
</main>

<section class="quality-strip">
  <div class="container">
    <div class="row text-center g-2">
      <div class="col-6 col-md-3"><i class="bi bi-shield-check"></i><span>100% Hygienic</span></div>
      <div class="col-6 col-md-3"><i class="bi bi-award"></i><span>Quality Frozen</span></div>
      <div class="col-6 col-md-3"><i class="bi bi-truck"></i><span>Fast &amp; Reliable Delivery</span></div>
      <div class="col-6 col-md-3"><i class="bi bi-heart"></i><span>Healthy Food for Your Family</span></div>
    </div>
  </div>
</section>

<footer class="site-footer">
  <div class="container py-4">
    <div class="row g-3">
      <div class="col-md-4">
        <h6><?= esc(SITE_NAME) ?></h6>
        <p class="small mb-1"><?= esc(TAGLINE2) ?> — <?= esc(TAGLINE) ?>.</p>
        <p class="small mb-1"><i class="bi bi-geo-alt"></i> Delivery only within <?= esc(CITY) ?></p>
        <p class="small mb-1"><i class="bi bi-telephone"></i> Order: <a href="tel:<?= esc(str_replace('-','',ORDER_PHONE)) ?>"><?= esc(ORDER_PHONE) ?></a></p>
        <a class="btn btn-success btn-sm mt-1" href="<?= whatsapp_link('Assalam-o-Alaikum! I want to order from Memon Frozen Food.') ?>" target="_blank" rel="noopener">
          <i class="bi bi-whatsapp"></i> WhatsApp Us
        </a>
      </div>
      <div class="col-md-4">
        <h6>Quick Links</h6>
        <ul class="list-unstyled small">
          <li><a href="<?= $ROOT ?>products.php">All Products</a></li>
          <li><a href="<?= $ROOT ?>track-order.php">Track Your Order</a></li>
          <li><a href="<?= $ROOT ?>delivery-policy.php">Delivery Policy</a></li>
          <li><a href="<?= $ROOT ?>refund-policy.php">Refund Policy</a></li>
          <li><a href="<?= $ROOT ?>privacy-policy.php">Privacy Policy</a></li>
          <li><a href="<?= $ROOT ?>terms.php">Terms &amp; Conditions</a></li>
          <li><a href="<?= $ROOT ?>faq.php">FAQs</a></li>
        </ul>
      </div>
      <div class="col-md-4">
        <h6>Offers &amp; Updates</h6>
        <form method="post" action="" class="d-flex gap-1">
          <?= csrf_field() ?>
          <input type="email" name="newsletter_email" class="form-control form-control-sm" placeholder="Your email" required>
          <button class="btn btn-sm btn-gold" type="submit">Join</button>
        </form>
        <p class="small mt-2">Get new products and family deals first.</p>
      </div>
    </div>
    <hr>
    <p class="text-center small mb-0">&copy; <?= date('Y') ?> <?= esc(SITE_NAME) ?>, <?= esc(CITY) ?>. All rights reserved.</p>
  </div>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
window.MFF = { root: <?= json_encode($ROOT) ?> };
</script>
<script src="<?= $ROOT ?>assets/js/app.js"></script>
</body>
</html>
