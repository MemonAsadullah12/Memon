<?php
// Public layout header. Pages set $page_title and (inside account/) $ROOT='../' before including.
// Output buffering: lets redirect() work even after a page has started rendering.
ob_start();
if (session_status() === PHP_SESSION_NONE) {
    session_set_cookie_params([
        'lifetime' => 0,
        'path'     => '/',
        'httponly' => true,
        'samesite' => 'Lax',
    ]);
    session_start();
}
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/helpers.php';
require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/cart-lib.php';

$ROOT = $ROOT ?? '';
$title = ($page_title ?? SITE_NAME) . ' | ' . SITE_NAME;

// Newsletter signup (footer form posts back to the same URL with this field).
if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST' && isset($_POST['newsletter_email'])) {
    csrf_check();
    $em = trim($_POST['newsletter_email'] ?? '');
    if (filter_var($em, FILTER_VALIDATE_EMAIL)) {
        try {
            $st = db()->prepare("INSERT IGNORE INTO newsletter_subscribers (email, is_active) VALUES (?, 1)");
            $st->execute([$em]);
            flash('Subscribed! You will get our latest offers.');
        } catch (Throwable $e) { flash('Could not subscribe right now.', 'danger'); }
    } else {
        flash('Please enter a valid email address.', 'danger');
    }
    redirect($_SERVER['REQUEST_URI'] ?? ($ROOT . 'index.php'));
}

$flashes = $_SESSION['flashes'] ?? [];
unset($_SESSION['flashes']);
$customer = current_customer();
$cartN = cart_count();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= esc($title) ?></title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
<link rel="stylesheet" href="<?= $ROOT ?>assets/css/style.css">
</head>
<body>
<header class="site-header">
  <div class="container d-flex align-items-center gap-2 py-2">
    <a href="<?= $ROOT ?>index.php" class="brand d-flex align-items-center text-decoration-none">
      <span class="logo-circle">MFF</span>
      <span class="ms-2">
        <span class="brand-name">MEMON FROZEN FOOD</span>
        <span class="brand-tag"><?= esc(TAGLINE) ?></span>
      </span>
    </a>
    <button class="btn btn-outline-light ms-auto d-lg-none" id="menuToggle" aria-label="Menu">
      <i class="bi bi-list"></i>
    </button>
    <nav class="main-nav d-none d-lg-flex ms-3" id="mainNav">
      <a href="<?= $ROOT ?>index.php">Home</a>
      <a href="<?= $ROOT ?>products.php">Products</a>
      <a href="<?= $ROOT ?>about.php">About Us</a>
      <a href="<?= $ROOT ?>contact.php">Contact</a>
    </nav>
    <form class="search-form d-none d-md-flex ms-auto" action="<?= $ROOT ?>products.php" method="get" role="search">
      <input class="form-control form-control-sm" type="search" name="q" placeholder="Search products…"
             value="<?= esc($_GET['q'] ?? '') ?>" aria-label="Search products">
      <button class="btn btn-sm btn-gold" type="submit"><i class="bi bi-search"></i></button>
    </form>
    <a href="<?= $ROOT ?>cart.php" class="cart-link ms-2" aria-label="Cart">
      <i class="bi bi-cart3"></i>
      <span class="cart-count" id="cartCount"><?= (int)$cartN ?></span>
    </a>
    <?php if ($customer): ?>
      <a href="<?= $ROOT ?>account/dashboard.php" class="btn btn-sm btn-gold ms-2 d-none d-md-inline-block">
        <i class="bi bi-person-circle"></i> <?= esc($customer['name']) ?>
      </a>
    <?php else: ?>
      <a href="<?= $ROOT ?>account/login.php" class="btn btn-sm btn-gold ms-2 d-none d-md-inline-block">
        <i class="bi bi-person"></i> Login
      </a>
    <?php endif; ?>
  </div>
  <nav class="mobile-nav d-lg-none" id="mobileNav">
    <a href="<?= $ROOT ?>index.php">Home</a>
    <a href="<?= $ROOT ?>products.php">Products</a>
    <a href="<?= $ROOT ?>about.php">About Us</a>
    <a href="<?= $ROOT ?>contact.php">Contact</a>
    <form action="<?= $ROOT ?>products.php" method="get" class="d-flex gap-1 px-2 pb-2">
      <input class="form-control form-control-sm" type="search" name="q" placeholder="Search products…">
      <button class="btn btn-sm btn-gold" type="submit"><i class="bi bi-search"></i></button>
    </form>
    <?php if ($customer): ?>
      <a href="<?= $ROOT ?>account/dashboard.php"><i class="bi bi-person-circle"></i> My Account</a>
    <?php else: ?>
      <a href="<?= $ROOT ?>account/login.php"><i class="bi bi-person"></i> Login / Register</a>
    <?php endif; ?>
  </nav>
</header>

<div class="container mt-3" id="flashWrap">
  <?php foreach ($flashes as $f): ?>
    <div class="alert alert-<?= esc($f['type']) ?> alert-dismissible fade show flash-msg" role="alert">
      <?= esc($f['msg']) ?>
      <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
  <?php endforeach; ?>
</div>

<main class="container my-3">
