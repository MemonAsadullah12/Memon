<?php
// Shared helpers: escaping, CSRF, flash, formatting, settings, order workflow, links.

function esc(?string $s): string {
    return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8');
}

// ---- CSRF ----
function csrf_token(): string {
    if (empty($_SESSION['csrf'])) {
        $_SESSION['csrf'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf'];
}
function csrf_field(): string {
    return '<input type="hidden" name="csrf" value="' . esc(csrf_token()) . '">';
}
function csrf_check(): void {
    $t = $_POST['csrf'] ?? '';
    if (!$t || !hash_equals($_SESSION['csrf'] ?? '', $t)) {
        http_response_code(419);
        exit('Invalid request (bad CSRF token). Please go back and try again.');
    }
}

// ---- Redirect / flash ----
// Discards any buffered output first so redirects work even if a page
// already started rendering (header.php enables output buffering).
function redirect(string $url): void {
    while (ob_get_level() > 0) { ob_end_clean(); }
    header('Location: ' . $url);
    exit;
}
function flash(string $msg, string $type = 'success'): void {
    $_SESSION['flashes'][] = ['msg' => $msg, 'type' => $type];
}

// ---- Money ----
function rs(int|float $n): string {
    return CURRENCY . ' ' . number_format((int)round($n));
}

// ---- Order number: MFF-YYYYMMDD-#### (count of today's orders + 1) ----
function order_no(PDO $db): string {
    $n = (int)$db->query("SELECT COUNT(*) FROM orders WHERE DATE(created_at) = CURDATE()")->fetchColumn();
    return 'MFF-' . date('Ymd') . '-' . str_pad($n + 1, 4, '0', STR_PAD_LEFT);
}

// ---- Business settings (cached) ----
function get_setting(string $k, $default = null) {
    static $cache = null;
    if ($cache === null) {
        $cache = [];
        try {
            foreach (db()->query("SELECT setting_key, setting_value FROM business_settings") as $r) {
                $cache[$r['setting_key']] = $r['setting_value'];
            }
        } catch (Throwable $e) { /* table may not exist yet */ }
    }
    return $cache[$k] ?? $default;
}

// ---- Order workflow ----
const ORDER_STATUSES = ['received','confirmed','preparing','ready','out_for_delivery','delivered','cancelled','returned'];

const ORDER_TRANSITIONS = [
    'received'         => ['confirmed','cancelled'],
    'confirmed'        => ['preparing','cancelled'],
    'preparing'        => ['ready','cancelled'],
    'ready'            => ['out_for_delivery','cancelled'],
    'out_for_delivery' => ['delivered','cancelled'],
    'delivered'        => ['returned'],
    'cancelled'        => [],
    'returned'         => [],
];

function can_transition(string $from, string $to): bool {
    return in_array($to, ORDER_TRANSITIONS[$from] ?? [], true);
}

function status_label(string $s): string {
    return ucwords(str_replace('_', ' ', $s));
}

// ---- WhatsApp ----
function whatsapp_link(string $text): string {
    return 'https://wa.me/' . WHATSAPP . '?text=' . urlencode($text);
}

// ---- Audit log (best-effort; never breaks the page) ----
function audit(?int $adminId, string $action, ?string $type = null, ?int $rid = null, $old = null, $new = null): void {
    try {
        $st = db()->prepare(
            "INSERT INTO audit_logs (admin_id, action, record_type, record_id, old_value, new_value, ip_address, created_at)
             VALUES (?,?,?,?,?,?,?,NOW())"
        );
        $st->execute([
            $adminId, $action, $type, $rid,
            $old === null ? null : (is_string($old) ? $old : json_encode($old)),
            $new === null ? null : (is_string($new) ? $new : json_encode($new)),
            $_SERVER['REMOTE_ADDR'] ?? null,
        ]);
    } catch (Throwable $e) { /* audit table optional */ }
}

// ---- Bootstrap pagination HTML ----
function paginate(int $total, int $per, int $page, string $url): string {
    $pages = (int)ceil($total / max(1, $per));
    if ($pages <= 1) return '';
    $sep = str_contains($url, '?') ? '&' : '?';
    $h = '<nav><ul class="pagination justify-content-center">';
    for ($i = 1; $i <= $pages; $i++) {
        $h .= '<li class="page-item' . ($i === $page ? ' active' : '') . '">'
            . '<a class="page-link" href="' . esc($url . $sep . 'page=' . $i) . '">' . $i . '</a></li>';
    }
    return $h . '</ul></nav>';
}

// ---- Phone helpers ----
function clean_phone(string $p): string {
    return preg_replace('/\D+/', '', $p);
}
function valid_mobile(string $p): bool {
    // Accepts 10-11 digit Pakistani mobiles: 3003130608, 03003130608, or 923003130608.
    $d = clean_phone($p);
    return (bool)preg_match('/^(0?\d{10}|92\d{10})$/', $d);
}

// Payment method enabled? Keys match the seeded business_settings flags.
function pay_enabled(string $key): bool {
    return (string)get_setting($key, '0') === '1';
}
