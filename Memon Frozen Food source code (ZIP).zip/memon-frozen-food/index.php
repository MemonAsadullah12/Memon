<?php
// Homepage: hero, categories, featured/bestseller products.
$page_title = 'Fresh & Hygienic Frozen Foods';
require_once __DIR__ . '/includes/header.php';
$pdo = db();

$cats = $pdo->query("SELECT * FROM categories WHERE is_active = 1 ORDER BY sort_order, name LIMIT 8")->fetchAll();

$feat = $pdo->query(
    "SELECT * FROM products WHERE is_active = 1 AND is_featured = 1 ORDER BY created_at DESC LIMIT 8"
)->fetchAll();

$best = $pdo->query(
    "SELECT * FROM products WHERE is_active = 1 AND is_bestseller = 1 ORDER BY created_at DESC LIMIT 8"
)->fetchAll();

function product_card(array $p, string $ROOT): string {
    $price = product_price($p);
    $img = $p['image'] ? esc($p['image']) : '';
    $h = '<div class="col-6 col-md-3 mb-3"><div class="card product-card h-100">';
    $h .= $img ? '<img src="' . $img . '" class="card-img-top" alt="' . esc($p['name']) . '" loading="lazy">'
               : '<div class="card-img-top img-ph"><i class="bi bi-image"></i></div>';
    $h .= '<div class="card-body d-flex flex-column">';
    $h .= '<h6 class="card-title"><a href="' . $ROOT . 'product.php?slug=' . esc($p['slug']) . '">' . esc($p['name']) . '</a></h6>';
    if (!empty($p['pack_size'])) $h .= '<p class="text-muted small mb-1">' . esc($p['pack_size']) . '</p>';
    $h .= '<div class="mt-auto d-flex align-items-center justify-content-between">';
    $h .= '<span class="price-badge">' . rs($price) . '</span>';
    $h .= '<a class="btn btn-sm btn-maroon" href="' . $ROOT . 'product.php?slug=' . esc($p['slug']) . '">View</a>';
    $h .= '</div></div></div></div>';
    return $h;
}
?>

<section class="hero rounded-3 p-4 p-md-5 mb-4 text-center">
  <h1 class="display-6 fw-bold"><?= esc(TAGLINE2) ?></h1>
  <p class="lead mb-3">Delicious &bull; Healthy &bull; Ready to Cook</p>
  <a href="products.php" class="btn btn-maroon btn-lg">Order Now</a>
  <p class="mt-2 small">Delivery within <?= esc(CITY) ?> &nbsp;|&nbsp; Call <?= esc(ORDER_PHONE) ?></p>
</section>

<?php if ($cats): ?>
<h2 class="section-title">Shop by Category</h2>
<div class="row mb-4">
  <?php foreach ($cats as $c): ?>
    <div class="col-6 col-md-3 mb-2">
      <a class="cat-tile" href="products.php?cat=<?= esc($c['slug']) ?>"><?= esc($c['name']) ?></a>
    </div>
  <?php endforeach; ?>
</div>
<?php endif; ?>

<?php if ($feat): ?>
<h2 class="section-title">Featured Products</h2>
<div class="row"><?php foreach ($feat as $p) echo product_card($p, $ROOT); ?></div>
<?php endif; ?>

<?php if ($best): ?>
<h2 class="section-title">Bestsellers</h2>
<div class="row"><?php foreach ($best as $p) echo product_card($p, $ROOT); ?></div>
<?php endif; ?>

<?php
require_once __DIR__ . '/includes/footer.php';
