<?php
/* =====================================================================
 * Memon Frozen Food - Web Installer
 * Run once in the browser (e.g. http://localhost/memon-frozen-food/install.php)
 * then DELETE or rename this file.
 *
 * Standalone: implements its own tiny CSRF + escaping helpers and does
 * NOT require any file from includes/ (they do not exist yet).
 * Uses PDO + prepared statements everywhere. No plaintext passwords.
 * ===================================================================== */
session_start();

/* ---------- tiny inline helpers (standalone) ---------- */
function inst_esc($s): string {
    return htmlspecialchars((string)$s, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}
function inst_csrf_token(): string {
    if (empty($_SESSION['install_csrf'])) {
        $_SESSION['install_csrf'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['install_csrf'];
}
function inst_csrf_check(): void {
    $sent = $_POST['csrf'] ?? '';
    $good = $_SESSION['install_csrf'] ?? '';
    if ($good === '' || !hash_equals($good, (string)$sent)) {
        http_response_code(403);
        inst_page('Security check failed',
            '<div class="alert error">Invalid request (possible CSRF). Please go back and try again.</div>'
            . '<a class="btn" href="install.php">Restart installer</a>');
        exit;
    }
}

/* ---------- page renderer with minimal brand CSS ---------- */
function inst_page(string $title, string $body, int $step = 0): void {
    $steps = ['Check', 'Database', 'Config', 'Admin', 'Done'];
    $nav = '<div class="steps">';
    foreach ($steps as $i => $label) {
        $cls = $i < $step ? 'done' : ($i === $step ? 'current' : '');
        $nav .= '<span class="step ' . $cls . '">' . ($i + 1) . '. ' . inst_esc($label) . '</span>';
    }
    $nav .= '</div>';
    echo '<!DOCTYPE html><html lang="en"><head><meta charset="utf-8">'
        . '<meta name="viewport" content="width=device-width, initial-scale=1">'
        . '<title>' . inst_esc($title) . ' - Memon Frozen Food Installer</title>'
        . '<style>
        *{box-sizing:border-box}body{margin:0;font-family:system-ui,-apple-system,"Segoe UI",Roboto,sans-serif;background:#FFF8E9;color:#222}
        .wrap{max-width:680px;margin:0 auto;padding:24px 16px}
        .brand{background:#970D0D;color:#fff;border-radius:12px;padding:20px;text-align:center;margin-bottom:16px}
        .brand h1{margin:0;font-size:26px}.brand p{margin:6px 0 0;color:#FFD54A;letter-spacing:2px;font-weight:700;font-size:13px}
        .card{background:#fff;border:1px solid #e5d9bd;border-radius:12px;padding:20px;margin-bottom:16px}
        .card h2{margin:0 0 12px;color:#970D0D;font-size:20px}
        .steps{display:flex;gap:6px;flex-wrap:wrap;margin-bottom:16px}
        .step{background:#fff;border:1px solid #e5d9bd;border-radius:20px;padding:5px 12px;font-size:12px;color:#777}
        .step.current{background:#970D0D;color:#fff;border-color:#970D0D;font-weight:700}
        .step.done{background:#228B52;color:#fff;border-color:#228B52}
        label{display:block;font-weight:600;margin:12px 0 4px}
        input[type=text],input[type=password],input[type=email]{width:100%;padding:10px;border:1px solid #ccc;border-radius:8px;font-size:15px}
        .btn{display:inline-block;background:#FFD54A;color:#5c0a0a;font-weight:700;border:none;border-radius:8px;padding:12px 22px;font-size:15px;cursor:pointer;text-decoration:none;margin-top:14px}
        .btn:hover{background:#f5c63b}.btn.secondary{background:#970D0D;color:#fff}
        .alert{border-radius:8px;padding:12px;margin:12px 0}
        .alert.error{background:#fdecea;color:#790808;border:1px solid #f5c2c0}
        .alert.success{background:#e6f6ec;color:#1a6b40;border:1px solid #bfe3cd}
        .alert.warn{background:#fff4d6;color:#7a4d00;border:2px solid #E9A23B}
        .check{display:flex;justify-content:space-between;gap:10px;padding:10px 0;border-bottom:1px solid #f0e7d2}
        .pass{color:#228B52;font-weight:700}.fail{color:#790808;font-weight:700}
        .hint{color:#777;font-size:13px}.muted{color:#777;font-size:13px}
        pre{background:#2b2b2b;color:#ffe9a8;border-radius:8px;padding:14px;overflow:auto;font-size:13px;white-space:pre-wrap}
        code{background:#f3ecd9;padding:2px 6px;border-radius:4px}
        </style></head><body><div class="wrap">'
        . '<div class="brand"><h1>Memon Frozen Food</h1><p>HYGIENIC TASTE &mdash; INSTALLER</p></div>'
        . $nav
        . '<div class="card"><h2>' . inst_esc($title) . '</h2>' . $body . '</div>'
        . '<p class="muted" style="text-align:center">After installation finishes, delete or rename <code>install.php</code>.</p>'
        . '</div></body></html>';
}

/* ---------- run one SQL file, statements split on ";\n" ---------- */
function inst_run_sql_file(PDO $pdo, string $path): array {
    $sql = @file_get_contents($path);
    if ($sql === false) {
        return ['ok' => false, 'error' => 'Could not read ' . basename($path) . '. Make sure the database/ folder was uploaded.', 'count' => 0];
    }
    $sql = str_replace(["\r\n", "\r"], "\n", $sql);
    $count = 0;
    foreach (explode(";\n", $sql) as $chunk) {
        $stmt = trim($chunk);
        if ($stmt === '') {
            continue;
        }
        try {
            $pdo->exec($stmt);
            $count++;
        } catch (PDOException $e) {
            return [
                'ok' => false,
                'error' => 'Error in ' . basename($path) . ': ' . $e->getMessage()
                    . "\nNear: " . mb_substr($stmt, 0, 160),
                'count' => $count,
            ];
        }
    }
    return ['ok' => true, 'count' => $count];
}

function inst_connect_db(string $host, string $db, string $user, string $pass): PDO {
    $pdo = new PDO(
        'mysql:host=' . $host . ';charset=utf8mb4',
        $user,
        $pass,
        [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC]
    );
    $pdo->exec('CREATE DATABASE IF NOT EXISTS `' . $db . '` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci');
    $pdo->exec('USE `' . $db . '`');
    return $pdo;
}

/* ---------- routing ---------- */
$step = isset($_GET['step']) ? max(0, min(4, (int)$_GET['step'])) : 0;
$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';

/* ================= STEP 0 - environment check ================= */
if ($step === 0) {
    $checks = [
        ['label' => 'PHP version 8.2 or newer', 'pass' => version_compare(PHP_VERSION, '8.2.0', '>='), 'hint' => 'Found PHP ' . PHP_VERSION . '.'],
        ['label' => 'PDO MySQL extension (pdo_mysql)', 'pass' => extension_loaded('pdo_mysql'), 'hint' => 'Needed to talk to the database.'],
        ['label' => 'mbstring extension', 'pass' => extension_loaded('mbstring'), 'hint' => 'Needed for safe text handling.'],
        ['label' => 'database/schema.sql found', 'pass' => is_file(__DIR__ . '/database/schema.sql'), 'hint' => 'Upload the whole project folder, including database/.'],
        ['label' => 'database/seed.sql found', 'pass' => is_file(__DIR__ . '/database/seed.sql'), 'hint' => 'Upload the whole project folder, including database/.'],
        ['label' => 'Sessions working', 'pass' => session_status() === PHP_SESSION_ACTIVE, 'hint' => 'The installer keeps its progress in a session.'],
    ];
    $allOk = true;
    $rows = '';
    foreach ($checks as $c) {
        $allOk = $allOk && $c['pass'];
        $rows .= '<div class="check"><div><strong>' . inst_esc($c['label']) . '</strong><br><span class="hint">' . inst_esc($c['hint']) . '</span></div>'
            . '<div class="' . ($c['pass'] ? 'pass' : 'fail') . '">' . ($c['pass'] ? 'PASS' : 'FAIL') . '</div></div>';
    }
    $_SESSION['env_ok'] = $allOk;
    $body = $rows;
    if ($allOk) {
        $body .= '<div class="alert success">All checks passed. You can continue.</div>'
            . '<a class="btn" href="install.php?step=1">Continue: Database Setup</a>';
    } else {
        $body .= '<div class="alert error">One or more checks failed. Fix the failed items above, then <a href="install.php?step=0">re-run this check</a>.</div>';
    }
    inst_page('Step 0 - Environment Check', $body, 0);
    exit;
}

if (empty($_SESSION['env_ok'])) {
    header('Location: install.php?step=0');
    exit;
}

/* ================= STEP 1 - database credentials + import ================= */
if ($step === 1) {
    if ($method === 'POST') {
        inst_csrf_check();
        $host = trim($_POST['db_host'] ?? 'localhost');
        $db   = trim($_POST['db_name'] ?? 'memon_frozen_food');
        $user = trim($_POST['db_user'] ?? 'root');
        $pass = (string)($_POST['db_pass'] ?? '');

        if ($host === '' || !preg_match('/^[A-Za-z0-9_.\-]+$/', $host)) {
            $err = 'Invalid database host.';
        } elseif (!preg_match('/^[A-Za-z0-9_]+$/', $db)) {
            $err = 'Database name may only contain letters, numbers and underscores.';
        } elseif ($user === '' || !preg_match('/^[A-Za-z0-9_.\-@]+$/', $user)) {
            $err = 'Invalid database username.';
        } else {
            $err = null;
        }

        if ($err === null) {
            try {
                $pdo = inst_connect_db($host, $db, $user, $pass);
            } catch (PDOException $e) {
                $err = 'Could not connect to MySQL: ' . $e->getMessage()
                    . ' (Check that MySQL is running and the username/password are correct.)';
            }
        }

        if ($err === null) {
            $r1 = inst_run_sql_file($pdo, __DIR__ . '/database/schema.sql');
            if (!$r1['ok']) {
                $err = 'Schema import failed after ' . $r1['count'] . ' statements. ' . $r1['error'];
            } else {
                $r2 = inst_run_sql_file($pdo, __DIR__ . '/database/seed.sql');
                if (!$r2['ok']) {
                    $err = 'Seed import failed after ' . $r2['count'] . ' statements. ' . $r2['error'];
                }
            }
        }

        if ($err !== null) {
            inst_page('Step 1 - Database Setup',
                '<div class="alert error">' . nl2br(inst_esc($err)) . '</div>'
                . '<a class="btn secondary" href="install.php?step=1">Go back and try again</a>', 1);
            exit;
        }

        $_SESSION['db'] = ['host' => $host, 'name' => $db, 'user' => $user, 'pass' => $pass];
        $_SESSION['db_ok'] = true;
        header('Location: install.php?step=2');
        exit;
    }

    $body = '<p>Enter your MySQL connection details. On XAMPP the defaults usually work as-is.</p>'
        . '<form method="post" action="install.php?step=1">'
        . '<input type="hidden" name="csrf" value="' . inst_esc(inst_csrf_token()) . '">'
        . '<label for="db_host">Database host</label><input type="text" id="db_host" name="db_host" value="localhost" required>'
        . '<label for="db_name">Database name</label><input type="text" id="db_name" name="db_name" value="memon_frozen_food" required>'
        . '<label for="db_user">Database username</label><input type="text" id="db_user" name="db_user" value="root" required>'
        . '<label for="db_pass">Database password</label><input type="password" id="db_pass" name="db_pass" value="" autocomplete="new-password">'
        . '<p class="muted">The installer will create the database if it does not exist, then import the tables and starter data.</p>'
        . '<button class="btn" type="submit">Create Database &amp; Import</button></form>';
    inst_page('Step 1 - Database Setup', $body, 1);
    exit;
}

/* steps 2+ require step 1 to be done */
if (empty($_SESSION['db_ok']) || empty($_SESSION['db'])) {
    header('Location: install.php?step=1');
    exit;
}
$dbCreds = $_SESSION['db'];

/* ================= STEP 2 - write includes/config.local.php ================= */
if ($step === 2) {
    $configCode = "<?php\n"
        . "// Memon Frozen Food - local database configuration.\n"
        . "// Generated by install.php on " . date('Y-m-d H:i:s') . ". Keep this file private.\n"
        . "define('DB_HOST', " . var_export($dbCreds['host'], true) . ");\n"
        . "define('DB_NAME', " . var_export($dbCreds['name'], true) . ");\n"
        . "define('DB_USER', " . var_export($dbCreds['user'], true) . ");\n"
        . "define('DB_PASS', " . var_export($dbCreds['pass'], true) . ");\n";

    $dir = __DIR__ . '/includes';
    $written = false;
    if (!is_dir($dir)) {
        @mkdir($dir, 0755, true);
    }
    if (is_dir($dir) && is_writable($dir)) {
        $written = @file_put_contents($dir . '/config.local.php', $configCode) !== false;
    }

    if ($written) {
        $_SESSION['config_written'] = true;
        $body = '<div class="alert success">Configuration saved to <code>includes/config.local.php</code>.</div>'
            . '<p class="muted">Host: <code>' . inst_esc($dbCreds['host']) . '</code> &nbsp; Database: <code>' . inst_esc($dbCreds['name']) . '</code> &nbsp; User: <code>' . inst_esc($dbCreds['user']) . '</code></p>'
            . '<a class="btn" href="install.php?step=3">Continue: Create Admin Account</a>';
    } else {
        $body = '<div class="alert error">The installer could not write to the <code>includes/</code> folder (permissions).'
            . ' Please create the file <code>includes/config.local.php</code> manually with exactly this content, then continue:</div>'
            . '<pre>' . inst_esc($configCode) . '</pre>'
            . '<a class="btn" href="install.php?step=3">I created the file - Continue</a>';
    }
    inst_page('Step 2 - Save Configuration', $body, 2);
    exit;
}

/* ================= STEP 3 - first Super Admin ================= */
if ($step === 3) {
    if ($method === 'POST') {
        inst_csrf_check();
        $name = trim($_POST['name'] ?? '');
        $email = trim($_POST['email'] ?? '');
        $pw1 = (string)($_POST['password'] ?? '');
        $pw2 = (string)($_POST['password2'] ?? '');

        if ($name === '') {
            $err = 'Please enter your full name.';
        } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $err = 'Please enter a valid email address.';
        } elseif (mb_strlen($pw1) < 8) {
            $err = 'Password must be at least 8 characters.';
        } elseif ($pw1 !== $pw2) {
            $err = 'The two passwords do not match.';
        } else {
            $err = null;
        }

        if ($err === null) {
            try {
                $pdo = inst_connect_db($dbCreds['host'], $dbCreds['name'], $dbCreds['user'], $dbCreds['pass']);
                $role = $pdo->query("SELECT id FROM roles WHERE name = 'Super Admin'")->fetch();
                if (!$role) {
                    $err = 'Super Admin role not found. Please re-run Step 1 (database import).';
                } else {
                    $chk = $pdo->prepare('SELECT id FROM users WHERE email = :email');
                    $chk->execute([':email' => $email]);
                    if ($chk->fetch()) {
                        $err = 'An admin with this email already exists. Use a different email.';
                    } else {
                        $ins = $pdo->prepare('INSERT INTO users (role_id, name, email, password_hash, is_active) VALUES (:role_id, :name, :email, :hash, 1)');
                        $ins->execute([
                            ':role_id' => $role['id'],
                            ':name' => $name,
                            ':email' => $email,
                            ':hash' => password_hash($pw1, PASSWORD_DEFAULT),
                        ]);
                    }
                }
            } catch (PDOException $e) {
                $err = 'Database error: ' . $e->getMessage();
            }
        }

        if ($err !== null) {
            inst_page('Step 3 - Create Admin Account',
                '<div class="alert error">' . inst_esc($err) . '</div>'
                . '<a class="btn secondary" href="install.php?step=3">Go back</a>', 3);
            exit;
        }

        session_regenerate_id(true);
        unset($_SESSION['db']); // drop credentials from the session
        $_SESSION['admin_created'] = true;
        $_SESSION['admin_name'] = $name;
        header('Location: install.php?step=4');
        exit;
    }

    $body = '<p>Create the first administrator account. There are <strong>no default passwords</strong> - choose your own strong password.</p>'
        . '<form method="post" action="install.php?step=3">'
        . '<input type="hidden" name="csrf" value="' . inst_esc(inst_csrf_token()) . '">'
        . '<label for="name">Full name</label><input type="text" id="name" name="name" required maxlength="120">'
        . '<label for="email">Email</label><input type="email" id="email" name="email" required maxlength="160">'
        . '<label for="password">Password (min 8 characters)</label><input type="password" id="password" name="password" required minlength="8" autocomplete="new-password">'
        . '<label for="password2">Confirm password</label><input type="password" id="password2" name="password2" required minlength="8" autocomplete="new-password">'
        . '<button class="btn" type="submit">Create Admin Account</button></form>';
    inst_page('Step 3 - Create Admin Account', $body, 3);
    exit;
}

/* ================= STEP 4 - done ================= */
if (empty($_SESSION['admin_created'])) {
    header('Location: install.php?step=3');
    exit;
}
$name = $_SESSION['admin_name'] ?? 'Admin';
$body = '<div class="alert success">Installation complete! Welcome, ' . inst_esc($name) . '.</div>'
    . '<ul><li>Database tables and starter data were imported.</li>'
    . '<li>Your configuration was saved to <code>includes/config.local.php</code>.</li>'
    . '<li>Your Super Admin account is ready.</li></ul>'
    . '<div class="alert warn"><strong>IMPORTANT:</strong> Delete or rename <code>install.php</code> now, so nobody can re-run the installer.</div>'
    . '<a class="btn" href="./">Open the Website</a> '
    . '<a class="btn secondary" href="admin/login.php">Open Admin Login</a>';
inst_page('Installation Complete', $body, 4);
