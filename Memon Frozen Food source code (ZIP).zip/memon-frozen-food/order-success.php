<?php
// Order confirmation: reached only with a valid tracking token from checkout.
$page_title = 'Order Placed';
require_once __DIR__ . '/includes/header.php';
$pdo = db();

$no = trim($_GET['o'] ?? '');
$token = trim($_GET['t'] ?? '');
$st = $pdo->prepare("SELECT * FROM orders WHERE order_number = ? AND tracking_token = ? LIMIT 1");
$st->execute([$no, $token]);
$o = $st->fetch();
if (!$o) {
    echo '<div class="alert alert-warning">Order not found. <a href="track-order.php">Track your order</a> or <a href="products.php">continue shopping</a>.</div>';
    require __DIR__ . '/includes/footer.php';
    exit;
}
$it = $pdo->prepare("SELECT * FROM order_items WHERE order_id = ?");
$it->execute([(int)$o['id']]);
$lines = $it->fetchAll();

$waMsg = "Assalam-o-Alaikum! I just placed order {$o['order_number']} on Memon Frozen Food. Please confirm my order. Thank you!";
?>

<div class="text-center my-4">
  <i class="bi bi-check-circle-fill text-success" style="font-size:3rem"></i>
  <h1 class="mt-2">Thank you, <?= esc($o['customer_name']) ?>!</h1>
  <p class="lead">Your order <strong><?= esc($o['order_number']) ?></strong> has been received.</p>
  <p class="text-muted">We will call you on <?= esc($o['customer_phone']) ?> to confirm. You can follow your order below.</p>
</div>

<div class="row justify-content-center">
  <div class="col-md-7">
    <div class="card mb-3"><div class="card-body">
      <h5>Order Summary</h5>
      <?php foreach ($lines as $l): ?>
        <p class="d-flex justify-content-between small mb-1">
          <span><?= esc($l['product_name_snapshot']) ?> × <?= (int)$l['quantity'] ?></span>
          <span><?= rs((int)$l['line_total']) ?></span>
        </p>
      <?php endforeach; ?>
      <hr>
      <p class="d-flex justify-content-between mb-1"><span>Subtotal</span><span><?= rs((int)$o['subtotal']) ?></span></p>
      <?php if ((int)$o['discount_amount'] > 0): ?>
        <p class="d-flex justify-content-between mb-1 text-success"><span>Discount</span><span>− <?= rs((int)$o['discount_amount']) ?></span></p>
      <?php endif; ?>
      <p class="d-flex justify-content-between mb-1"><span>Delivery Fee</span><span><?= (int)$o['delivery_fee'] ? rs((int)$o['delivery_fee']) : 'FREE' ?></span></p>
      <p class="d-flex justify-content-between"><span><strong>Total</strong></span><span><strong><?= rs((int)$o['total_amount']) ?></strong></span></p>
      <p class="small text-muted mb-0">Payment: <?= esc(ucwords(str_replace('_', ' ', $o['payment_method']))) ?> · Status: <?= esc(status_label($o['order_status'])) ?></p>
      <p class="small text-muted">Deliver to: <?= esc($o['delivery_address']) ?>, <?= esc($o['area']) ?>, <?= esc($o['city']) ?></p>
    </div></div>

    <div class="d-flex gap-2 flex-wrap justify-content-center mb-4">
      <a class="btn btn-success" target="_blank" rel="noopener" href="<?= whatsapp_link($waMsg) ?>">
        <i class="bi bi-whatsapp"></i> Confirm on WhatsApp
      </a>
      <a class="btn btn-outline-maroon" href="track-order.php?o=<?= urlencode($o['order_number']) ?>">
        <i class="bi bi-truck"></i> Track Order
      </a>
      <a class="btn btn-maroon" href="products.php">Continue Shopping</a>
    </div>
    <p class="text-center small text-muted">Your order is now <strong>Received</strong> → Confirmed → Preparing → Ready → Out for Delivery → Delivered.</p>
  </div>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
