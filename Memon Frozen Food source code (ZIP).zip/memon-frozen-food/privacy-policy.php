<?php
$page_title = 'Privacy Policy';
require_once __DIR__ . '/includes/header.php';
?>
<h1 class="page-heading">Privacy Policy</h1>
<p>We collect only what we need to run your order: your name, phone/WhatsApp number, delivery address, and order details.</p>
<ul>
  <li>Your information is used to process, deliver and support your orders, and to send offers you subscribed to.</li>
  <li>We do not sell your personal information to anyone.</li>
  <li>We never store card numbers or CVVs — online payments, where offered, are handled and verified by our team directly.</li>
  <li>Account passwords are stored securely (hashed) and never in readable form.</li>
  <li>You may ask us to correct or delete your information by contacting us on <?= esc(ORDER_PHONE) ?>.</li>
</ul>
<?php require_once __DIR__ . '/includes/footer.php'; ?>
