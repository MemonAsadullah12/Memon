<?php
// Product detail + add to cart + reviews.
$page_title = 'Product';
require_once __DIR__ . '/includes/header.php';
$pdo = db();

$slug = trim($_GET['slug'] ?? '');
$st = $pdo->prepare(
    "SELECT p.*, c.name AS cat_name, c.slug AS cat_slug FROM products p
     LEFT JOIN categories c ON c.id = p.category_id
     WHERE p.slug = ? AND p.is_active = 1 LIMIT 1"
);
$st->execute([$slug]);
$p = $st->fetch();
if (!$p) { http_response_code(404); echo '<div class="alert alert-warning">Product not found.</div>'; require __DIR__.'/includes/footer.php'; exit; }
$page_title = $p['name'];

// Review submission (held for approval).
if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST' && isset($_POST['review'])) {
    csrf_check();
    $nm = trim($_POST['rname'] ?? '');
    $rt = min(5, max(1, (int)($_POST['rating'] ?? 5)));
    $tx = trim($_POST['rtext'] ?? '');
    if ($nm !== '' && $tx !== '') {
        $st = $pdo->prepare("INSERT INTO reviews (product_id, customer_name, rating, review_text, is_approved) VALUES (?,?,?,?,0)");
        $st->execute([(int)$p['id'], $nm, $rt, $tx]);
        flash('Thank you! Your review was submitted for approval.');
        redirect('product.php?slug=' . urlencode($slug));
    } else {
        flash('Please fill in your name and review.', 'danger');
    }
}

// Extra images.
$imgs = [];
try {
    $st = $pdo->prepare("SELECT image FROM product_images WHERE product_id = ? ORDER BY sort_order");
    $st->execute([(int)$p['id']]);
    $imgs = $st->fetchAll(PDO::FETCH_COLUMN);
} catch (Throwable $e) {}

$price = product_price($p);
$mainImg = $p['image'] ?: ($imgs[0] ?? '');

$reviews = $pdo->prepare("SELECT * FROM reviews WHERE product_id = ? AND is_approved = 1 ORDER BY id DESC LIMIT 20");
$reviews->execute([(int)$p['id']]);
$reviews = $reviews->fetchAll();

// Related.
$rel = $pdo->prepare("SELECT * FROM products WHERE is_active = 1 AND category_id = ? AND id <> ? LIMIT 4");
$rel->execute([(int)$p['category_id'], (int)$p['id']]);
$rel = $rel->fetchAll();
?>
<nav aria-label="breadcrumb"><ol class="breadcrumb">
  <li class="breadcrumb-item"><a href="index.php">Home</a></li>
  <li class="breadcrumb-item"><a href="products.php">Products</a></li>
  <?php if ($p['cat_name']): ?><li class="breadcrumb-item"><a href="products.php?cat=<?= esc($p['cat_slug']) ?>"><?= esc($p['cat_name']) ?></a></li><?php endif; ?>
  <li class="breadcrumb-item active"><?= esc($p['name']) ?></li>
</ol></nav>

<div class="row">
  <div class="col-md-5 mb-3">
    <?= $mainImg ? '<img src="'.esc($mainImg).'" class="img-fluid rounded product-main-img" alt="'.esc($p['name']).'">' : '<div class="img-ph img-ph-lg"><i class="bi bi-image"></i></div>' ?>
    <?php if (count($imgs) > 1): ?>
      <div class="d-flex gap-2 mt-2">
        <?php foreach (array_slice($imgs, 0, 4) as $im): ?>
          <img src="<?= esc($im) ?>" class="thumb" alt="" loading="lazy">
        <?php endforeach; ?>
      </div>
    <?php endif; ?>
  </div>
  <div class="col-md-7">
    <h1 class="h3"><?= esc($p['name']) ?></h1>
    <?php if ($p['pack_size']): ?><p class="text-muted"><?= esc($p['pack_size']) ?><?= $p['pieces_per_pack'] ? ' · ' . (int)$p['pieces_per_pack'] . ' pieces per pack' : '' ?></p><?php endif; ?>
    <p class="h4"><span class="price-badge price-lg"><?= rs($price) ?></span>
      <?php if ($price < (int)$p['selling_price']): ?><s class="text-muted small"><?= rs((int)$p['selling_price']) ?></s><?php endif; ?>
    </p>
    <p><?= nl2br(esc($p['description'])) ?></p>
    <?php if ($p['ingredients']): ?><p><strong>Ingredients:</strong> <?= esc($p['ingredients']) ?></p><?php endif; ?>
    <?php if ($p['allergen_information']): ?><p class="small text-muted"><strong>Allergen info:</strong> <?= esc($p['allergen_information']) ?></p><?php endif; ?>

    <?php if ((int)$p['stock_quantity'] > 0): ?>
      <form method="post" action="cart.php" class="d-flex gap-2 align-items-center mb-2">
        <?= csrf_field() ?>
        <input type="hidden" name="action" value="add">
        <input type="hidden" name="pid" value="<?= (int)$p['id'] ?>">
        <input type="number" name="qty" value="1" min="1" max="<?= (int)$p['stock_quantity'] ?>" class="form-control qty-input">
        <button class="btn btn-maroon" type="submit"><i class="bi bi-cart-plus"></i> Add to Cart</button>
      </form>
      <p class="small text-success"><i class="bi bi-check-circle"></i> In stock</p>
    <?php else: ?>
      <div class="alert alert-warning">Currently out of stock. Please check back soon.</div>
    <?php endif; ?>
    <p class="small text-muted">SKU: <?= esc($p['sku'] ?? '') ?></p>
  </div>
</div>

<h3 class="section-title mt-4">Customer Reviews</h3>
<?php if (!$reviews): ?><p class="text-muted">No reviews yet — be the first!</p><?php endif; ?>
<?php foreach ($reviews as $r): ?>
  <div class="card mb-2"><div class="card-body py-2">
    <strong><?= esc($r['customer_name']) ?></strong>
    <span class="text-warning"><?= str_repeat('★', (int)$r['rating']) . str_repeat('☆', 5 - (int)$r['rating']) ?></span>
    <p class="mb-0"><?= nl2br(esc($r['review_text'])) ?></p>
  </div></div>
<?php endforeach; ?>

<h4 class="mt-3">Write a Review</h4>
<form method="post" class="mb-4" style="max-width:520px">
  <?= csrf_field() ?>
  <input type="hidden" name="review" value="1">
  <div class="mb-2"><input class="form-control" name="rname" placeholder="Your name" required maxlength="80"></div>
  <div class="mb-2"><select class="form-select" name="rating"><?php for ($i=5;$i>=1;$i--) echo "<option value=\"$i\">$i star".($i>1?'s':'')."</option>"; ?></select></div>
  <div class="mb-2"><textarea class="form-control" name="rtext" rows="3" placeholder="Your review" required></textarea></div>
  <button class="btn btn-maroon" type="submit">Submit Review</button>
</form>

<?php if ($rel): ?>
<h3 class="section-title">Related Products</h3>
<div class="row">
  <?php foreach ($rel as $r):
    $rp = product_price($r); ?>
    <div class="col-6 col-md-3 mb-3">
      <div class="card product-card h-100"><div class="card-body">
        <h6 class="card-title"><a href="product.php?slug=<?= esc($r['slug']) ?>"><?= esc($r['name']) ?></a></h6>
        <span class="price-badge"><?= rs($rp) ?></span>
      </div></div>
    </div>
  <?php endforeach; ?>
</div>
<?php endif; ?>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
