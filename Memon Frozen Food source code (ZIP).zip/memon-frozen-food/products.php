<?php
// Product listing: category filter, search, pagination.
$page_title = 'Products';
require_once __DIR__ . '/includes/header.php';
$pdo = db();

$catSlug = trim($_GET['cat'] ?? '');
$q       = trim($_GET['q'] ?? '');
$page    = max(1, (int)($_GET['page'] ?? 1));
$per     = 12;

$where = ['p.is_active = 1'];
$args  = [];
$catName = '';
if ($catSlug) {
    $st = $pdo->prepare("SELECT id, name FROM categories WHERE slug = ? AND is_active = 1 LIMIT 1");
    $st->execute([$catSlug]);
    if ($c = $st->fetch()) { $where[] = 'p.category_id = ?'; $args[] = $c['id']; $catName = $c['name']; }
}
if ($q !== '') {
    $where[] = '(p.name LIKE ? OR p.description LIKE ?)';
    $args[] = "%$q%"; $args[] = "%$q%";
}
$wsql = implode(' AND ', $where);

$total = (int)(function () use ($pdo, $wsql, $args) {
    $st = $pdo->prepare("SELECT COUNT(*) FROM products p WHERE $wsql");
    $st->execute($args);
    return $st->fetchColumn();
})();

// LIMIT/OFFSET are inlined as ints (safe after casting; avoids driver quirks with bound LIMIT).
$st = $pdo->prepare(
    "SELECT p.*, c.name AS cat_name FROM products p LEFT JOIN categories c ON c.id = p.category_id
     WHERE $wsql ORDER BY p.is_featured DESC, p.name LIMIT " . (int)$per . " OFFSET " . (int)(($page - 1) * $per)
);
$st->execute($args);
$items = $st->fetchAll();

$cats = $pdo->query("SELECT name, slug FROM categories WHERE is_active = 1 ORDER BY sort_order, name")->fetchAll();
$url  = 'products.php?' . http_build_query(array_filter(['cat' => $catSlug, 'q' => $q]));
?>

<h1 class="page-heading"><?= $catName ? esc($catName) : 'All Products' ?></h1>
<?php if ($q !== ''): ?><p class="text-muted">Search results for "<?= esc($q) ?>"</p><?php endif; ?>

<div class="mb-3 d-flex flex-wrap gap-2">
  <a class="btn btn-sm <?= $catSlug ? 'btn-outline-maroon' : 'btn-maroon' ?>" href="products.php">All</a>
  <?php foreach ($cats as $c): ?>
    <a class="btn btn-sm <?= $catSlug === $c['slug'] ? 'btn-maroon' : 'btn-outline-maroon' ?>"
       href="products.php?cat=<?= esc($c['slug']) ?>"><?= esc($c['name']) ?></a>
  <?php endforeach; ?>
</div>

<?php if (!$items): ?>
  <div class="alert alert-info">No products found. Try another search or category.</div>
<?php else: ?>
  <div class="row">
    <?php foreach ($items as $p):
      $price = product_price($p);
      $img = $p['image'] ? esc($p['image']) : '';
    ?>
      <div class="col-6 col-md-3 mb-3">
        <div class="card product-card h-100">
          <?= $img ? '<img src="'.$img.'" class="card-img-top" alt="'.esc($p['name']).'" loading="lazy">' : '<div class="card-img-top img-ph"><i class="bi bi-image"></i></div>' ?>
          <div class="card-body d-flex flex-column">
            <h6 class="card-title"><a href="product.php?slug=<?= esc($p['slug']) ?>"><?= esc($p['name']) ?></a></h6>
            <?php if ($p['pack_size']): ?><p class="text-muted small mb-1"><?= esc($p['pack_size']) ?><?= $p['pieces_per_pack'] ? ' · ' . (int)$p['pieces_per_pack'] . ' pcs' : '' ?></p><?php endif; ?>
            <div class="mt-auto d-flex align-items-center justify-content-between">
              <span class="price-badge"><?= rs($price) ?></span>
              <a class="btn btn-sm btn-maroon" href="product.php?slug=<?= esc($p['slug']) ?>">View</a>
            </div>
          </div>
        </div>
      </div>
    <?php endforeach; ?>
  </div>
  <?= paginate($total, $per, $page, $url) ?>
<?php endif; ?>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
