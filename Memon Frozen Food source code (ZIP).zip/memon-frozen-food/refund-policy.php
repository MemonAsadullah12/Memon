<?php
$page_title = 'Refund Policy';
require_once __DIR__ . '/includes/header.php';
?>
<h1 class="page-heading">Refund Policy</h1>
<ul>
  <li>If your order arrives damaged, incorrect or spoiled, contact us within <strong>24 hours</strong> on <?= esc(ORDER_PHONE) ?> or WhatsApp with your order number — we will replace it or refund you.</li>
  <li>Because our products are perishable frozen food, we cannot accept returns of correctly delivered items.</li>
  <li>Cancelled orders are refunded in full for any advance payment made; Cash on Delivery orders simply owe nothing.</li>
  <li>Approved refunds are issued via the original payment method or as store credit, within 7 working days.</li>
</ul>
<?php require_once __DIR__ . '/includes/footer.php'; ?>
