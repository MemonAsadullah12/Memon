<?php
$page_title = 'Terms & Conditions';
require_once __DIR__ . '/includes/header.php';
?>
<h1 class="page-heading">Terms &amp; Conditions</h1>
<ul>
  <li>Prices are in Pakistani Rupees and include all applicable taxes unless stated otherwise.</li>
  <li>Orders are confirmed by our team via phone/WhatsApp before dispatch.</li>
  <li>Payment is Cash on Delivery unless another method shown at checkout has been verified by our team.</li>
  <li>Products are perishable frozen food: please check your order on delivery and store packs frozen immediately.</li>
  <li>We reserve the right to cancel an order (e.g. stock shortage or undeliverable address) with a full refund of any advance paid.</li>
  <li>Coupons and offers cannot be combined unless stated, and misuse may lead to cancellation.</li>
</ul>
<?php require_once __DIR__ . '/includes/footer.php'; ?>
