<?php
// Track order: order number + phone must match before details are shown.
$page_title = 'Track Your Order';
require_once __DIR__ . '/includes/header.php';
$pdo = db();

$order = null; $history = []; $err = '';
$preO = trim($_GET['o'] ?? '');

if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST') {
    csrf_check();
    $no = trim($_POST['order_number'] ?? '');
    $phone = clean_phone($_POST['phone'] ?? '');
    if ($no === '' || $phone === '') {
        $err = 'Please enter your order number and phone number.';
    } else {
        $st = $pdo->prepare("SELECT * FROM orders WHERE order_number = ? LIMIT 1");
        $st->execute([$no]);
        $o = $st->fetch();
        if (!$o || clean_phone($o['customer_phone']) !== $phone) {
            $err = 'No order found with that number and phone. Please check and try again.';
        } else {
            $order = $o;
            $h = $pdo->prepare("SELECT * FROM order_status_history WHERE order_id = ? ORDER BY created_at ASC, id ASC");
            $h->execute([(int)$o['id']]);
            $history = $h->fetchAll();
        }
    }
}
?>

<h1 class="page-heading">Track Your Order</h1>

<div class="row justify-content-center">
  <div class="col-md-6">
    <div class="card mb-3"><div class="card-body">
      <form method="post">
        <?= csrf_field() ?>
        <div class="mb-2"><label class="form-label">Order Number</label>
          <input class="form-control" name="order_number" required placeholder="MFF-YYYYMMDD-####" value="<?= esc($preO) ?>"></div>
        <div class="mb-2"><label class="form-label">Phone Number (used at checkout)</label>
          <input class="form-control" name="phone" required placeholder="03xx-xxxxxxx"></div>
        <button class="btn btn-maroon w-100" type="submit">Track</button>
      </form>
      <?php if ($err): ?><div class="alert alert-danger mt-2 mb-0"><?= esc($err) ?></div><?php endif; ?>
    </div>
  </div>
</div>

<?php if ($order): ?>
<div class="row justify-content-center"><div class="col-md-8">
  <div class="card"><div class="card-body">
    <h5>Order <?= esc($order['order_number']) ?></h5>
    <p class="small text-muted mb-2">Placed on <?= esc($order['created_at']) ?> · Total <?= rs((int)$order['total_amount']) ?></p>
    <ol class="timeline">
      <?php foreach ($history as $h): ?>
        <li>
          <strong><?= esc(status_label($h['new_status'])) ?></strong>
          <span class="text-muted small"> — <?= esc($h['created_at']) ?></span>
          <?php if ($h['note']): ?><br><span class="small"><?= esc($h['note']) ?></span><?php endif; ?>
        </li>
      <?php endforeach; ?>
    </ol>
    <?php if (in_array($order['order_status'], ['cancelled', 'returned'], true)): ?>
      <div class="alert alert-secondary mb-0">This order was <?= esc(status_label($order['order_status'])) ?>.</div>
    <?php endif; ?>
  </div></div>
</div></div>
<?php endif; ?>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
